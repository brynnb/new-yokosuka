# Lucky Break

Lucky Break is a browser-based 3D nine-ball pool game built with TypeScript,
Babylon.js, and Vite. Its table, ball set, cue, and surrounding jazz bar
come from the 1999 Dreamcast game *Shenmue*, adapted here into a dedicated
nine-ball experience. Its planned home is
[luckybreak.app](https://luckybreak.app).

## Requirements

- Node.js 20 or newer
- npm

## Development

Install dependencies and start the local development server:

```sh
npm install
npm run dev
```

Vite serves the game at `http://127.0.0.1:8001`.

## Project commands

```sh
npm run dev        # Start the development server
npm run typecheck  # Check the TypeScript project
npm test           # Run the test suite
npm run build      # Create a production build in dist/
npm run preview    # Preview the production build
npm run build:engine # Build the reusable renderer-neutral engine package
```

## Shared engine package

This repository is also the source of
`@brynnb/lucky-break-engine`. The package contains the billiards simulation,
Shenmue table collision data, nine-ball referee, shot prediction, and AI. It
does not depend on Babylon.js and does not create scenes, cameras, meshes,
audio, or UI.

The standalone Lucky Break app imports its central simulator through the same
public package entry used by New Yokosuka. The local Vite alias points that
entry at `src/pool-engine/index.ts`, while `npm run build:engine` produces the
publishable ESM bundle and declarations under `engine-dist/`.

The preferred release flow is:

```sh
npm test
npm run build
npm version minor
npm publish
```

Consumers should pin a released version or Git tag. Do not depend on the
repository's moving `main` branch for production builds.

## Project structure

```text
src/
  animation/    Tweening and animation primitives
  application/  Application state, controllers, UI, replay, and views
  assets/       Asset manifests and loading utilities
  core/         Shared infrastructure
  game/         Game data, players, rules, and referees
  math2d/       Two-dimensional geometry
  physics/      Rigid-body physics and collision handling
  pool-engine/  Stable renderer-neutral package API and game session
  platform/     Browser integration
  rendering/    Babylon.js materials, shaders, and lighting
  simulator/    Billiards simulation orchestration
  main.ts       Browser entry point

public/assets/  Models, textures, fonts, and styles served by Vite
tests/          Product tests
```

Custom lighting, materials, and billiards physics run on Babylon.js 9.
