export default class Vector2 {
    x: number;
    y: number;
    constructor(x?: number, y?: number);
    /** @param {number} x @param {number} y @returns {this} */
    set(x: number, y: number): this;
    /** @param {Vector2} other @returns {this} */
    copy(other: Vector2): this;
    /** @returns {Vector2} */
    clone(): Vector2;
    toString(): string;
    /** @returns {number} */
    lengthSq(): number;
    /** @returns {number} */
    length(): number;
    /** @returns {this} */
    normalize(): this;
    /** @param {Vector2} other @returns {this} */
    normalizeVector(other: Vector2): this;
    /** @param {Vector2} other @returns {this} */
    add(other: Vector2): this;
    /** @param {Vector2} left @param {Vector2} right @returns {this} */
    addVectors(left: Vector2, right: Vector2): this;
    /** @param {Vector2} other @param {number} scale @returns {void} */
    addScaled(other: Vector2, scale: number): void;
    /**
     * @param {Vector2} origin
     * @param {Vector2} direction
     * @param {number} ratio
     * @returns {this}
     */
    interpolate(origin: Vector2, direction: Vector2, ratio: number): this;
    /** @param {Vector2} other @returns {this} */
    sub(other: Vector2): this;
    /** @param {Vector2} left @param {Vector2} right @returns {this} */
    subVectors(left: Vector2, right: Vector2): this;
    /** @param {Vector2} other @returns {number} */
    dot(other: Vector2): number;
    /** @param {Vector2} other @returns {number} */
    distanceToSq(other: Vector2): number;
    /** @param {Vector2} other @returns {number} */
    distanceTo(other: Vector2): number;
    /** @param {number} scale @returns {this} */
    scale(scale: number): this;
    /** @param {number} scale @param {Vector2} other @returns {this} */
    scaleVector(scale: number, other: Vector2): this;
    /** @returns {boolean} */
    isZero(): boolean;
    /** @returns {boolean} */
    almostZero(): boolean;
    /** @param {Vector2} other @returns {boolean} */
    almostEquals(other: Vector2): boolean;
    /** @param {Vector2} other @param {number} ratio @returns {this} */
    lerp(other: Vector2, ratio: number): this;
}
