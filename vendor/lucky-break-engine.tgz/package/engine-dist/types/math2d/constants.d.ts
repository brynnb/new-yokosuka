export declare const GEOMETRY_2D_EPSILON = 0.000001;
