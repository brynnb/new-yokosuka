import { type AIShotFactors } from "../application/ai/AIShotPlanner";
import EventEmitter from "../core/EventEmitter";
import BilliardsSimulator from "../simulator/BilliardsSimulator";
export declare const NineBallGameEvents: Readonly<{
    BALL_POTTED: "ball-potted";
    GAME_OVER: "game-over";
    RESET: "reset";
    SHOT_ENDED: "shot-ended";
    SHOT_STARTED: "shot-started";
    STATE_CHANGED: "state-changed";
}>;
export type NineBallGamePhase = "ready" | "simulating" | "complete";
export interface NineBallPlayer {
    id: string;
    name: string;
    isAI?: boolean;
}
export interface NineBallShot {
    directionX: number;
    directionZ: number;
    power: number;
    sideSpin?: number;
    topSpin?: number;
}
export interface PoolNormalMapImageData {
    width: number;
    height: number;
    data: ArrayLike<number>;
}
export declare const ShenmueCushionNormalMapUrl: string;
export interface NineBallBallSnapshot {
    active: boolean;
    index: number;
    number: number;
    position: {
        x: number;
        y: number;
        z: number;
    };
    orientation: {
        x: number;
        y: number;
        z: number;
        w: number;
    };
}
export interface NineBallGameSnapshot {
    balls: NineBallBallSnapshot[];
    currentPlayerIndex: number;
    foul: string;
    inHand: boolean;
    openingBreak: boolean;
    phase: NineBallGamePhase;
    targetBallNumber: number | null;
    winnerIndex: number | null;
}
export interface NineBallShotResult {
    foulCode: number;
    foulDescription: string;
    nextPlayerIndex: number;
    pottedBallNumbers: number[];
    score: number;
    winnerIndex: number | null;
}
export type NineBallShotPrediction = ReturnType<BilliardsSimulator["predict"]>;
export declare const NineBallAIDifficulties: Readonly<Record<"rookie" | "steady" | "ace", AIShotFactors>>;
export declare class ShenmueNineBallGame extends EventEmitter {
    readonly players: readonly NineBallPlayer[];
    readonly simulator: BilliardsSimulator;
    private readonly meshBody;
    private readonly context;
    private readonly refereeResult;
    private readonly referee;
    private readonly playArea;
    private readonly aiPlanner;
    private accumulator;
    private currentPlayerIndex;
    private foulDescription;
    private phase;
    private winnerIndex;
    constructor(players?: NineBallPlayer[]);
    applyCushionNormalMap(imageData: PoolNormalMapImageData): void;
    reset(startingPlayerIndex?: number): NineBallGameSnapshot;
    shoot(shot: NineBallShot): boolean;
    predictShot(shot: NineBallShot, maxDistance?: number): NineBallShotPrediction | null;
    private prepareShot;
    step(deltaSeconds: number): NineBallGameSnapshot;
    placeCueBall(x: number, z: number): boolean;
    planAIShot(difficulty?: keyof typeof NineBallAIDifficulties): NineBallShot | null;
    getContext(key: "ballOn"): number;
    pointProjectionOnTable(x: number, y: number, z: number): boolean;
    snapshot(): NineBallGameSnapshot;
    private finishShot;
    private settle;
    private setPhase;
}
export default ShenmueNineBallGame;
