export type Listener = ((...args: any[]) => void) & {
    listener?: Listener;
};
type EventMap = Record<string, Listener | Listener[]>;
export default class EventEmitter {
    _events: EventMap;
    _eventsCount: number;
    emit: (eventName: string, ...args: any[]) => boolean;
    on: (eventName: string, listener: Listener) => this;
    constructor();
    /**
     * @param {string} eventName
     * @param {Listener} listener
     * @returns {this}
     */
    _on(eventName: string, listener: Listener): this;
    /**
     * @param {string} eventName
     * @param {...any} args
     * @returns {boolean}
     */
    _emit(eventName: string, ...args: any[]): boolean;
    /**
     * @param {string} [eventName]
     * @returns {this}
     */
    removeAllListeners(eventName?: string): this;
    /**
     * @param {string} eventName
     * @param {Listener} listener
     * @returns {this}
     */
    removeListener(eventName: string, listener: Listener): this;
}
export {};
