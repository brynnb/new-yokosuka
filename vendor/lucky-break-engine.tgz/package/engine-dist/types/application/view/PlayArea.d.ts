import Vec3 from "../../physics/math/Vec3";
export interface PlayAreaSize {
    w: number;
    h: number;
}
export interface Pocket {
    position: Vec3;
    normal: Vec3;
    radius: number;
    maxHalfOpen: number;
}
export type PocketLayout = [
    x: number,
    z: number,
    normalX: number,
    normalZ: number,
    radius: number,
    maxHalfOpen: number
];
export default class PlayArea {
    get diagonal(): number;
    readonly position: Vec3;
    readonly size: PlayAreaSize;
    private _diagonal;
    readonly pockets: [Pocket, Pocket, Pocket, Pocket, Pocket, Pocket];
    constructor();
    reset(x: number, y: number, z: number, width: number, height: number, pocketLayout?: [
        PocketLayout,
        PocketLayout,
        PocketLayout,
        PocketLayout,
        PocketLayout,
        PocketLayout
    ]): void;
    private static makePocket;
    static setPocket(pocket: Pocket, x: number, y: number, z: number, normalX: number, normalY: number, normalZ: number, radius: number, maxHalfOpen: number): void;
}
