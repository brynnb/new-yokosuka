export interface ShotRouteEntry {
    pkIndex: number;
    ballBIndex: number;
    dx: number;
    dy: number;
    dz: number;
    fbSpin: number;
    powerFactor: number;
    priority: number;
}
export default class ShotRoute {
    get length(): number;
    readonly routes: ShotRouteEntry[];
    private _length;
    constructor();
    getAtIndex(index: number): ShotRouteEntry;
    next(dx: number, dy: number, dz: number, fbSpin: number, powerFactor: number, priority: number): ShotRouteEntry;
    clear(): void;
    private static makeRoute;
}
export declare const sharedShotRoutes: ShotRoute;
