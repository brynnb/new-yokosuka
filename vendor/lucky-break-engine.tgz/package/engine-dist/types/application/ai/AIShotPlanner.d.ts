import Vec3 from "../../physics/math/Vec3";
import type BilliardBallBody from "../../simulator/BilliardBallBody";
import type BilliardsSimulator from "../../simulator/BilliardsSimulator";
import type PlayArea from "../view/PlayArea";
import ShotRoute, { type ShotRouteEntry } from "./ShotRoute";
export interface AIShotFactors {
    range: number;
    abf: number;
    bcf: number;
    chaoticSeed: number;
    bpm: number;
    mpm: number;
}
interface AITable {
    playArea: PlayArea;
}
interface TableProjection {
    pointProjectionOnTable(x: number, y: number, z: number): boolean;
    getContext?(key: string): unknown;
}
export default class AIShotPlanner {
    private _simEvolution;
    private readonly _ballOnindices;
    private _ballCheckIndex;
    private _pkIndex;
    private readonly _routeCache;
    private _isBreak;
    private readonly _props;
    private _currentTaskIndex;
    private readonly _tasks;
    get taskRunning(): boolean;
    constructor();
    setFactors(properties: AIShotFactors): void;
    erase(): void;
    getIsBreak(): boolean;
    checkRestart(simulator: BilliardsSimulator, referee: {
        getContext(key: "ballOn" | "nRounds"): number;
    }): boolean;
    step(table: AITable, simulator: BilliardsSimulator, projection: TableProjection): ShotRouteEntry | null;
    private static _fallbackRoute;
    private static _getPolyHorizEdge;
    private static _chaos;
    private static _sigmoid01;
    static _checkSinglePK(cueBall: BilliardBallBody, objectBall: BilliardBallBody, pocketIndex: number, playArea: PlayArea, simulator: BilliardsSimulator, projection: TableProjection, routes: ShotRoute): void;
    static _checkPassAbility(cueBall: BilliardBallBody, objectBall: BilliardBallBody, playArea: PlayArea, simulator: BilliardsSimulator, _projection: TableProjection, routes: ShotRoute, offset: number, powerScale: number, addedLength: number, targetRouteCount: number): boolean;
    private static _vRef;
    static _isSegmentSafe(origin: Vec3, direction: Vec3, length: number, radius: number, balls: BilliardBallBody[], ...excludedBalls: BilliardBallBody[]): boolean;
    private static _logRoute;
}
export {};
