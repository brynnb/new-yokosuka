/** @type {{ FIRST_KISS: string, OUT_OF_BOUNDS: string, POTTED: string, PREPOT: string }} */
declare const SimulationResultEvents: any;
export default SimulationResultEvents;
