/** @type {{ ERROR: string, SYNCHRONIZED: string, BALL_IMPACT: string }} */
declare const SimulatorEvents: any;
export default SimulatorEvents;
