import SphereBody from "../physics/dynamics/SphereBody";
import Vec3 from "../physics/math/Vec3";
export default class BilliardBallBody extends SphereBody {
    number: number;
    spot: Vec3;
    index: number;
    constructor(number: number, radius: number, mass: number, spotX: number, spotY: number, spotZ: number, index: number);
}
