/** @type {{ ERROR: number, NO_SCENE: number, LOADING: number, SYNCHRONIZED: number }} */
declare const SimulatorState: any;
export default SimulatorState;
