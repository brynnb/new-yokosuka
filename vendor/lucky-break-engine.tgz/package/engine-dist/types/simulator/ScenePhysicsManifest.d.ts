export interface ScenePhysics {
    rgb: string;
    dArea: {
        cx: number;
        cz: number;
        sx: number;
        sz: number;
    };
}
declare const ScenePhysicsManifest: Record<string, ScenePhysics>;
export default ScenePhysicsManifest;
