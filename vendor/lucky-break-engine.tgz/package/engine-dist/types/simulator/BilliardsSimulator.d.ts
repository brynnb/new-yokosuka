import EventEmitter from "../core/EventEmitter";
import { type SimulatorResult } from "../game/GameDataFactories";
import Vec3 from "../physics/math/Vec3";
import type CollisionPolygon from "../physics/mesh/CollisionPolygon";
import type PolygonGroup from "../physics/mesh/PolygonGroup";
import type PhysicsWorldClient from "../physics/world/PhysicsWorldClient";
import BilliardBallBody from "./BilliardBallBody";
interface MeshBodyCache {
    getCache(id: string): unknown;
}
export interface SimulatorSyncOptions {
    sceneId?: string;
    ballSet?: number[];
    ballRadius?: number;
    ballMass?: number;
}
export default class BilliardsSimulator extends EventEmitter {
    /** @returns {string} */
    get sceneId(): string;
    /** @returns {string} */
    get id(): string;
    /** @returns {number} */
    get state(): number;
    /** @returns {number} */
    get nAwakened(): number;
    /** @returns {CollisionPolygon | null} */
    get ground(): CollisionPolygon;
    /** @returns {PolygonGroup | null} */
    get sidePolyGroups(): PolygonGroup | null;
    /** @returns {number} */
    get ballRadius(): number;
    /** @returns {number} */
    get spotY(): number;
    /** @returns {number} */
    get evolution(): number;
    /** @returns {number} */
    get stepSize(): number;
    /** @returns {SimulatorResult} */
    get result(): SimulatorResult;
    /**
     * @param {string | number} id
     * @param {PhysicsWorldClient} world
     * @param {MeshBodyCache} meshBodyCache
     */
    private readonly _id;
    private readonly _world;
    private _sceneId;
    private readonly _mbCache;
    private _spotY;
    private readonly _syncList;
    private _nPhxAwakened;
    private _state;
    private readonly _result;
    private readonly _onTouch;
    private readonly _onOutOfBounds;
    private _checkSyncTimerId;
    private readonly _onCheckSyncTimeout;
    constructor(id: string | number, world: PhysicsWorldClient, meshBodyCache: MeshBodyCache);
    /**
     * @param {SimulatorSyncOptions} options
     * @returns {void}
     */
    sync(options: SimulatorSyncOptions): void;
    /** @returns {void} */
    private _checkSyncList;
    /**
     * @param {boolean} resetPositions
     * @param {boolean} clearResult
     * @returns {BilliardsSimulator}
     */
    reset(resetPositions: boolean, clearResult: boolean): this;
    /** @returns {BilliardBallBody[]} */
    getBalls(): BilliardBallBody[];
    /** @param {number} index @returns {BilliardBallBody} */
    getBallAtIndex(index: number): BilliardBallBody;
    /** @returns {Vec3} */
    getCueBallPosition(): Vec3;
    /**
     * @param {number} index
     * @returns {void}
     */
    respotIndexDefault(index: number): void;
    /**
     * @param {number} index
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @returns {void}
     */
    respotIndexXYZ(index: number, x: number, y: number, z: number): void;
    /**
     * @param {BilliardBallBody} ball
     * @param {Vec3 | null | undefined} position
     * @returns {void}
     */
    resetBallPosition(ball: BilliardBallBody, position: Vec3 | null | undefined): void;
    /**
     * @param {number} deltaTime
     * @returns {number}
     */
    step(deltaTime: number): number;
    /** @returns {void} */
    save(): void;
    /**
     * @param {ArrayLike<number>} tipData
     * @param {number} distance
     * @returns {ReturnType<PhysicsWorldClient["predict"]>}
     */
    predict(tipData: ArrayLike<number>, distance: number): ReturnType<PhysicsWorldClient["predict"]>;
    /** @returns {PhysicsWorldClient["predictionCtx"]} */
    getPredictionCtx(): PhysicsWorldClient["predictionCtx"];
    /**
     * @param {ArrayLike<number>} tipData
     * @returns {void}
     */
    stroke(tipData: ArrayLike<number>): void;
    /** @returns {void} */
    clearResult(): void;
    /**
     * @param {number} excludedIndex
     * @param {Vec3} position
     * @param {number} [distance]
     * @returns {boolean}
     */
    touchBalls(excludedIndex: number, position: Vec3, distance?: number): boolean;
    /**
     * @param {number} state
     * @returns {void}
     */
    private _setState;
    /**
     * @param {string} message
     * @returns {void}
     */
    private _err;
    /**
     * @param {BilliardBallBody} ball
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @returns {void}
     */
    resetBallXYZ(ball: BilliardBallBody, x: number, y: number, z: number): void;
}
export {};
