declare class PhysicsProfiler {
    readonly data: import("./metrics").PhysicsMetric[];
    private readonly metricIndices;
    private _viewer;
    constructor();
    /** @returns {void} */
    createViewer(): void;
    /** @returns {void} */
    clear(): void;
    /**
     * @param {string} name
     * @returns {void}
     */
    startTick(name: string): void;
    /**
     * @param {string} name
     * @returns {void}
     */
    stopTick(name: string): void;
    /**
     * @param {string} name
     * @param {number} amount
     * @returns {void}
     */
    count(name: string, amount: number): void;
    /** @returns {void} */
    end(): void;
}
declare const physicsProfiler: PhysicsProfiler;
export { PhysicsProfiler };
export default physicsProfiler;
