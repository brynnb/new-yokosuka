export interface PhysicsMetric {
    name: string;
    color: string;
    ceiling: number;
    digits: number;
    visible: boolean | number;
    value: number;
}
declare const metrics: PhysicsMetric[];
export default metrics;
