export default class RollingSampleRecorder {
    /** @returns {number} */
    get avg(): number;
    /** @param {number} length */
    readonly a: Float32Array;
    counter: number;
    readonly length: number;
    sum: number;
    current: number;
    peak: number;
    constructor(length: number);
    /**
     * @param {number} value
     * @returns {void}
     */
    push(value: number): void;
    /** @returns {number} */
    updatePeak(): number;
}
