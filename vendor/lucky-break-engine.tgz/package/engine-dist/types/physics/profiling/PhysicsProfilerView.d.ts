import type { PhysicsMetric } from "./metrics";
interface ProfileSource {
    data: PhysicsMetric[];
}
export default class PhysicsProfilerView {
    private startTime;
    private __viewInited;
    private readonly monitors;
    private height;
    private container;
    constructor();
    /**
     * @param {ProfileSource} profiler
     * @returns {void}
     */
    private initView;
    /**
     * @param {string} name
     * @param {string} color
     * @param {number} ceiling
     * @param {number} length
     * @param {number} digits
     * @returns {void}
     */
    private appendMonitor;
    /**
     * @param {ProfileSource} profiler
     * @returns {void}
     */
    update(profiler: ProfileSource): void;
}
export {};
