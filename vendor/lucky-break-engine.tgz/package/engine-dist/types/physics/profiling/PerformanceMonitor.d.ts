export default class PerformanceMonitor {
    private readonly recorder;
    private readonly precision;
    private readonly name;
    private readonly color;
    private readonly upperBound;
    private readonly width;
    readonly height: number;
    private readonly fpu;
    private frame;
    container: HTMLDivElement;
    private viewWidth;
    private viewHeight;
    private ctx;
    private valueLabel;
    private peakLabel;
    private avgLabel;
    /**
     * @param {string} name
     * @param {string} color
     * @param {number} upperBound
     * @param {number} [length]
     * @param {number} [precision]
     */
    constructor(name: string, color: string, upperBound: number, length?: number, precision?: number);
    /** @returns {void} */
    private initView;
    /**
     * @param {number} value
     * @returns {void}
     */
    push(value: number): void;
    /** @returns {void} */
    update(): void;
    /**
     * @param {number} top
     * @param {number} left
     * @returns {void}
     */
    setPosition(top: number, left: number): void;
}
