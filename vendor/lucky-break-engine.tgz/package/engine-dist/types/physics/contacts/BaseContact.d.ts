import Mat3 from "../math/Mat3";
import Vec3 from "../math/Vec3";
export interface ContactPool {
    freeIndex(index: number): void;
}
export interface ContactMaterial {
    uid: number;
    restitution: number;
    friction: number;
}
export interface ContactBody extends ContactMaterial {
    cdRound: number;
    position: Vec3;
    v: Vec3;
    w: Vec3;
    vChangedCount: number;
    invInertia: Mat3;
    invMass: number;
    wakeUp(): void;
}
export default class BaseContact {
    static readonly gt: Vec3;
    /** @returns {string} */
    get label(): string;
    /** @returns {number} */
    get penetration(): number;
    /** @returns {Vec3} */
    get normal(): Vec3;
    /** @returns {number} */
    get bounceThreshold(): number;
    /** @returns {Vec3} */
    get armI(): Vec3;
    /** @returns {number} */
    get armLenI(): number;
    /** @returns {Mat3} */
    get spaceTransformL2W(): Mat3;
    /** @returns {Mat3} */
    get spaceTransformW2L(): Mat3;
    /** @returns {Mat3} */
    get transformImp2LocVel(): Mat3;
    /** @returns {Mat3} */
    get transformLocVel2Imp(): Mat3;
    /**
     * @param {ContactPool | null} parentPool
     * @param {number} poolIndex
     */
    protected __weakParent: ContactPool | null;
    readonly poolIndex: number;
    inUse: boolean;
    next: BaseContact | null;
    prev: BaseContact | null;
    isSS: boolean;
    markedAsKilled: boolean;
    bi: ContactBody | null;
    bj: ContactMaterial | null;
    idi: number;
    idj: number;
    cdRoundI: number;
    restitution: number;
    friction: number;
    toi: number;
    life: number;
    protected _penetration: number;
    readonly restingCheckPosI: Vec3;
    protected normalUpdateHandler: (() => void) | null;
    protected armDirty: boolean;
    protected readonly _armI: Vec3;
    protected _armLenI: number;
    protected bounceThresholdDirty: boolean;
    protected _bounceThreshold: number;
    protected relVelDirty: boolean;
    protected _closeSpeed: number;
    readonly relativeVelW: Vec3;
    protected vChangedCountI: number;
    protected spaceTransformDirty: boolean;
    protected readonly _m_loc2Wor: Mat3;
    protected readonly _m_wor2Loc: Mat3;
    protected impulseTransformDirty: boolean;
    protected readonly _m_locVel2Imp: Mat3;
    protected readonly _m_imp2LocVel: Mat3;
    protected readonly m_imp2WorVel: Mat3;
    protected readonly skewSymmetric: Mat3;
    protected normalDirty: boolean;
    protected readonly _normal: Vec3;
    rollingFriction: number;
    constructor(parentPool: ContactPool | null, poolIndex: number);
    /** @returns {string} */
    toString(): string;
    /** @returns {void} */
    free(): void;
    /** @returns {void} */
    dispose(): void;
    /** @returns {BaseContact} */
    activate(): this;
    /** @returns {boolean} */
    isOutdated(): boolean;
    /** @returns {void} */
    startResting(): void;
    /** @returns {boolean} */
    needsUpdateResting(): boolean;
    /**
     * @param {number} penetration
     * @param {Vec3} normal
     * @returns {void}
     */
    resetRestingWithPeneNormal(penetration: number, normal: Vec3): void;
    /** @returns {void} */
    stopResting(): void;
    /**
     * @param {ContactBody} bodyI
     * @param {ContactMaterial} bodyJ
     * @returns {void}
     */
    resetWithBiBj(bodyI: ContactBody, bodyJ: ContactMaterial): void;
    /** @returns {number} */
    getCloseSpeed(): number;
    /** @returns {Vec3} */
    getRelativeVelocity(): Vec3;
    /** @returns {void} */
    updateRelVelocity(): void;
    /** @returns {void} */
    markNormalRelatedDirty(): void;
    /** @returns {void} */
    markNormalDirty(): void;
    /** @returns {void} */
    markObjectChanged(): void;
    /** @returns {void} */
    updateForceArm(): void;
    /** @returns {void} */
    updateSpaceTransform(): void;
    /** @returns {void} */
    updateImpulseTransform(): void;
}
