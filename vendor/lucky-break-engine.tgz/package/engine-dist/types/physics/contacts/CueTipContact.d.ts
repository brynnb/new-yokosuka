import Vec3 from "../math/Vec3";
import type SphereBody from "../dynamics/SphereBody";
import SphereSphereContact from "./SphereSphereContact";
export default class CueTipContact extends SphereSphereContact {
    isSS: boolean;
    restitution: number;
    friction: number;
    bi: SphereBody | null;
    _normal: Vec3;
    /** @returns {string} */
    get label(): string;
    /** @param {number} mass */
    constructor(mass: number);
    /**
     * @param {SphereBody} body
     * @param {ArrayLike<number>} tipData
     * @returns {void}
     */
    resetTip(body: SphereBody, tipData: ArrayLike<number>): void;
    /** @returns {void} */
    free(): void;
    /** @returns {void} */
    dispose(): void;
}
