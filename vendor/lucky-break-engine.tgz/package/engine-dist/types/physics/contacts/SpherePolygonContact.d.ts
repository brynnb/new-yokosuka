import Vec3 from "../math/Vec3";
import type SphereBody from "../dynamics/SphereBody";
import type CollisionPolygon from "../mesh/CollisionPolygon";
import BaseContact, { type ContactPool } from "./BaseContact";
export type ContactPolygon = CollisionPolygon & {
    hasCustomNormalHandler?: boolean;
    customNormalHandler?: (point: Vec3, result: Vec3) => void;
};
export default class SpherePolygonContact extends BaseContact {
    bi: SphereBody | null;
    bj: ContactPolygon | null;
    readonly contactPoint: Vec3;
    private readonly normalUpdateCP;
    /**
     * @param {ContactPool | null} parentPool
     * @param {number} poolIndex
     */
    constructor(parentPool: ContactPool | null, poolIndex: number);
    /**
     * @param {number} penetration
     * @param {Vec3} contactPoint
     * @returns {void}
     */
    resetRestingWithPeneCP(penetration: number, contactPoint: Vec3): void;
    /** @returns {void} */
    updateRelVelocity(): void;
    /**
     * @param {SphereBody} body
     * @param {ContactPolygon} polygon
     * @param {number} toi
     * @param {number} penetration
     * @param {Vec3} normal
     * @returns {void}
     */
    resetPendingWithToiPeneNormal(body: SphereBody, polygon: ContactPolygon, toi: number, penetration: number, normal: Vec3): void;
    /**
     * @param {SphereBody} body
     * @param {ContactPolygon} polygon
     * @param {number} toi
     * @param {number} penetration
     * @param {Vec3} contactPoint
     * @returns {void}
     */
    resetPendingWithToiPeneCP(body: SphereBody, polygon: ContactPolygon, toi: number, penetration: number, contactPoint: Vec3): void;
    /** @returns {void} */
    updateForceArm(): void;
}
