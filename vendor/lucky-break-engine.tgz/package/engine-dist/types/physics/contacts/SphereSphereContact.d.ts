import Vec3 from "../math/Vec3";
import type SphereBody from "../dynamics/SphereBody";
import BaseContact, { type ContactPool } from "./BaseContact";
export default class SphereSphereContact extends BaseContact {
    bi: SphereBody | null;
    bj: SphereBody | null;
    private cdRoundJ;
    private vChangedCountJ;
    private readonly _armJ;
    private _armLenJ;
    private readonly restingCheckPosJ;
    private readonly relVelWJ;
    private readonly m_imp2LocVel2;
    /** @returns {Vec3} */
    get armJ(): Vec3;
    /** @returns {number} */
    get armLenJ(): number;
    /**
     * @param {ContactPool | null} parentPool
     * @param {number} poolIndex
     */
    constructor(parentPool: ContactPool | null, poolIndex: number);
    /** @returns {boolean} */
    isOutdated(): boolean;
    /** @returns {void} */
    startResting(): void;
    /** @returns {boolean} */
    needsUpdateResting(): boolean;
    /**
     * @param {number} penetration
     * @param {Vec3} normal
     * @returns {void}
     */
    resetRestingWithPeneNormal(penetration: number, normal: Vec3): void;
    /**
     * @param {SphereBody} bodyI
     * @param {SphereBody} bodyJ
     * @param {number} toi
     * @param {number} penetration
     * @returns {void}
     */
    resetPendingWithToiPene(bodyI: SphereBody, bodyJ: SphereBody, toi: number, penetration: number): void;
    /** @returns {void} */
    stopResting(): void;
    /** @returns {void} */
    updateForceArm(): void;
    /** @returns {number} */
    getCloseSpeed(): number;
    /** @returns {Vec3} */
    getRelativeVelocity(): Vec3;
    /** @returns {void} */
    updateRelVelocity(): void;
    /** @returns {void} */
    updateImpulseTransform(): void;
}
