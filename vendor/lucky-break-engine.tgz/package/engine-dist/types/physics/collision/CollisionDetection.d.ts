import type BaseContact from "../contacts/BaseContact";
import SpherePolygonContact, { type ContactPolygon } from "../contacts/SpherePolygonContact";
import SphereSphereContact from "../contacts/SphereSphereContact";
import type SphereBody from "../dynamics/SphereBody";
import type ContactIsland from "../islands/ContactIsland";
import type ContactIslandManager from "../islands/ContactIslandManager";
import Vec3 from "../math/Vec3";
import type MeshBody from "../mesh/MeshBody";
import type PolygonEdge from "../mesh/PolygonEdge";
import type PolygonGroup from "../mesh/PolygonGroup";
interface ContactPool<T> {
    acquire(): T;
}
interface PendingContacts {
    add(contact: BaseContact): void;
}
declare const CollisionDetection: {
    /**
     * @param {SphereBody[]} balls
     * @param {MeshBody} meshBody
     * @param {ContactIslands} islands
     * @param {ContactPool<SphereSphereContact>} sphereSpherePool
     * @param {ContactPool<SpherePolygonContact>} spherePolygonPool
     * @returns {void}
     */
    initIslands(balls: SphereBody[], meshBody: MeshBody, islands: ContactIslandManager, sphereSpherePool: ContactPool<SphereSphereContact>, spherePolygonPool: ContactPool<SpherePolygonContact>): void;
    /**
     * @param {ContactIslands} islands
     * @param {boolean} updateAll
     * @returns {void}
     */
    updateIslands(islands: ContactIslandManager, updateAll: boolean): void;
    /**
     * @param {ContactIsland} island
     * @param {ContactIslands} islands
     * @returns {void}
     */
    updateIsland(island: ContactIsland, islands: ContactIslandManager): void;
    /**
     * @param {SphereBody} body
     * @param {SphereBody[]} balls
     * @param {ContactPool<SphereSphereContact>} pool
     * @param {ContactIslands} islands
     * @param {number[]} excludedIds
     * @param {number} maxTime
     * @param {PendingContacts} pending
     * @returns {void}
     */
    updateSSToi(body: SphereBody, balls: SphereBody[], pool: ContactPool<SphereSphereContact>, islands: ContactIslandManager, excludedIds: number[], maxTime: number, pending: PendingContacts): void;
    /**
     * @param {SphereBody} body
     * @param {MeshBody} meshBody
     * @param {ContactPool<SpherePolygonContact>} pool
     * @param {ContactIslands} islands
     * @param {PendingContacts} pending
     * @returns {void}
     */
    updateSPToi(body: SphereBody, meshBody: MeshBody, pool: ContactPool<SpherePolygonContact>, islands: ContactIslandManager, pending: PendingContacts): void;
    /**
     * @param {SphereBody} body
     * @param {PolygonGroup} group
     * @param {ContactPool<SpherePolygonContact>} pool
     * @param {ContactIslands} islands
     * @param {number} earliest
     * @param {BaseContact[]} results
     * @returns {number}
     */
    dSPB(body: SphereBody, group: PolygonGroup, pool: ContactPool<SpherePolygonContact>, islands: ContactIslandManager, earliest: number, results: BaseContact[]): number;
    /**
     * @param {SphereSphereContact} contact
     * @returns {boolean}
     */
    dcdSS(contact: SphereSphereContact): boolean;
    /**
     * @param {SpherePolygonContact} contact
     * @returns {boolean}
     */
    dcdSP(contact: SpherePolygonContact): boolean;
    /**
     * @param {SphereBody} bodyI
     * @param {SphereBody} bodyJ
     * @param {number} maxTime
     * @param {SphereSphereContact} contact
     * @returns {boolean}
     */
    ccdSS(bodyI: SphereBody, bodyJ: SphereBody, maxTime: number, contact: SphereSphereContact): boolean;
    /**
     * @param {SphereBody} body
     * @param {ContactPolygon} polygon
     * @param {number} maxTime
     * @param {SpherePolygonContact} contact
     * @returns {boolean}
     */
    ccdSP(body: SphereBody, polygon: ContactPolygon, maxTime: number, contact: SpherePolygonContact): boolean;
    /**
     * @param {number} planeDistance
     * @param {SphereBody} body
     * @param {ContactPolygon} polygon
     * @param {number} normalSpeed
     * @param {number} maxTime
     * @param {SpherePolygonContact} contact
     * @returns {boolean}
     */
    __ccdspFar(planeDistance: number, body: SphereBody, polygon: ContactPolygon, normalSpeed: number, maxTime: number, contact: SpherePolygonContact): boolean;
    /**
     * @param {number} planeDistance
     * @param {SphereBody} body
     * @param {ContactPolygon} polygon
     * @param {number} maxTime
     * @param {SpherePolygonContact} contact
     * @returns {boolean}
     */
    __ccdspNear(planeDistance: number, body: SphereBody, polygon: ContactPolygon, maxTime: number, contact: SpherePolygonContact): boolean;
    /**
     * @param {PolygonEdge[]} edges
     * @param {Vec3[]} edgeNormals
     * @param {Vec3} point
     * @returns {boolean}
     */
    pointInPolygon(edges: PolygonEdge[], edgeNormals: Vec3[], point: Vec3): boolean;
    /**
     * @param {Vec3} origin
     * @param {Vec3} velocity
     * @param {number} velocitySquared
     * @param {Vec3} center
     * @param {number} radiusSquared
     * @returns {boolean}
     */
    rayIntersect(origin: Vec3, velocity: Vec3, velocitySquared: number, center: Vec3, radiusSquared: number): boolean;
    /**
     * @param {Vec3} velocity
     * @param {number} velocitySquared
     * @param {Vec3} offset
     * @param {number} distanceSquared
     * @param {number} radiusSquared
     * @returns {number}
     */
    pRaySphereToi(velocity: Vec3, velocitySquared: number, offset: Vec3, distanceSquared: number, radiusSquared: number): number;
    /**
     * @param {PolygonEdge[]} edges
     * @param {Vec3} point
     * @param {Vec3} result
     * @returns {number}
     */
    closestPointOnEdges(edges: PolygonEdge[], point: Vec3, result: Vec3): number;
};
export default CollisionDetection;
