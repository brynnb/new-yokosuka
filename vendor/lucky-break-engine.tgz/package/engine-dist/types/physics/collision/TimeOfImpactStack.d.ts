export interface PendingContact {
    toi: number;
    penetration: number;
    life: number;
    isSS: boolean;
    idi: number;
    idj: number;
    markedAsKilled: boolean;
    free(): void;
    isOutdated(): boolean;
    toString(): string;
}
export default class TimeOfImpactStack {
    static readonly TOISorter: (left: PendingContact, right: PendingContact) => number;
    /** @returns {number} */
    get length(): number;
    private readonly __stack1;
    private readonly __stack2;
    stack: PendingContact[];
    private idleStack;
    private __stackOrderDirty;
    constructor();
    /** @returns {void} */
    freeAll(): void;
    /**
     * @param {PendingContact} contact
     * @returns {void}
     */
    add(contact: PendingContact): void;
    /** @returns {void} */
    removeAllSS(): void;
    /**
     * @param {number} bodyId
     * @returns {void}
     */
    outdateAllSSWithId(bodyId: number): void;
    /** @returns {void} */
    resort(): void;
    /**
     * @param {number} stepTime
     * @param {PendingContact[]} result
     * @returns {number}
     */
    step2(stepTime: number, result: PendingContact[]): number;
    /**
     * @param {boolean} skipOutdated
     * @param {number[]} [bodyIds]
     * @returns {void}
     */
    log(skipOutdated: boolean, bodyIds?: number[]): void;
}
