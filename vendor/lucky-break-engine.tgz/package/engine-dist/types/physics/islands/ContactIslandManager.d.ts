import ObjectPool from "../core/ObjectPool";
import type BaseContact from "../contacts/BaseContact";
import ContactIsland from "./ContactIsland";
export default class ContactIslandManager {
    /** @returns {ContactIsland | null} */
    get entry(): ContactIsland | null;
    /** @returns {ContactIsland | null} */
    get tail(): ContactIsland | null;
    readonly pool: ObjectPool<ContactIsland>;
    __entry: ContactIsland | null;
    __tail: ContactIsland | null;
    private idMap;
    private __pureMap;
    private ssIdCounter;
    private readonly restingGrid;
    private width;
    private height;
    private dataWidth;
    private dataHeight;
    ssIdStart: number;
    nIslands: number;
    totalItems: number;
    private needsPure;
    private needsUpdate;
    /** @param {number} initialSize */
    constructor(initialSize: number);
    /**
     * @param {number} width
     * @param {number} sphereIdStart
     * @returns {void}
     */
    resize(width: number, sphereIdStart: number): void;
    /** @returns {void} */
    freeAll(): void;
    /**
     * @param {number} bodyId
     * @param {number} otherId
     * @returns {boolean}
     */
    isResting(bodyId: number, otherId: number): boolean;
    /**
     * @param {number} bodyId
     * @returns {void}
     */
    markReupdate(bodyId: number): void;
    /**
     * @param {number} bodyId
     * @returns {number}
     */
    getNContacts(bodyId: number): number;
    /**
     * @param {number} bodyId
     * @returns {ContactIsland | null}
     */
    getIslandByIdi(bodyId: number): ContactIsland | null;
    /**
     * @param {BaseContact} contact
     * @returns {void}
     */
    add(contact: BaseContact): void;
    /**
     * @param {BaseContact} contact
     * @returns {void}
     */
    private __addSP;
    /**
     * @param {BaseContact} contact
     * @returns {void}
     */
    private __addSS;
    /**
     * @param {ContactIsland} island
     * @returns {void}
     */
    private __removeIsland;
    /** @returns {void} */
    private __pureIslands;
    /**
     * @param {number} bodyId
     * @returns {void}
     */
    removeAllContactsWithId(bodyId: number): void;
    /**
     * @param {BaseContact} contact
     * @param {boolean} freeContact
     * @returns {void}
     */
    remove(contact: BaseContact, freeContact: boolean): void;
    /**
     * @param {ContactIsland} originalIsland
     * @returns {void}
     */
    private __pureIsland;
    /**
     * @param {number[]} bodyIds
     * @returns {void}
     */
    logIslandByIds(bodyIds: number[]): void;
    /** @returns {void} */
    logPenes(): void;
    /**
     * @param {boolean} [includePool]
     * @returns {void}
     */
    log(includePool?: boolean): void;
}
