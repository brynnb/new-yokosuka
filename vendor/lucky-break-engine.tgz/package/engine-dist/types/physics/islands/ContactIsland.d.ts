import type BaseContact from "../contacts/BaseContact";
interface IslandPool {
    freeIndex(index: number): void;
}
export default class ContactIsland {
    private weakParent;
    readonly id: number;
    inUse: boolean;
    itemEntry: BaseContact | null;
    itemTail: BaseContact | null;
    next: ContactIsland | null;
    prev: ContactIsland | null;
    totalItems: number;
    dirty: boolean;
    needsUpdate: boolean;
    needsPure: boolean;
    /**
     * @param {IslandPool} parentPool
     * @param {number} id
     */
    constructor(parentPool: IslandPool, id: number);
    /** @returns {ContactIsland} */
    activate(): this;
    /**
     * @param {number} bodyId
     * @returns {BaseContact | null}
     */
    getGroundContact(bodyId: number): BaseContact | null;
    /** @returns {void} */
    free(): void;
    /** @returns {void} */
    dispose(): void;
    /**
     * @param {BaseContact} contact
     * @returns {void}
     */
    setEntry(contact: BaseContact): void;
    /**
     * @param {BaseContact} contact
     * @returns {void}
     */
    remove(contact: BaseContact): void;
    /**
     * @param {BaseContact} contact
     * @returns {void}
     */
    push(contact: BaseContact): void;
    /**
     * @param {ContactIsland} other
     * @returns {void}
     */
    merge(other: ContactIsland): void;
    /** @returns {string} */
    toString(): string;
}
export {};
