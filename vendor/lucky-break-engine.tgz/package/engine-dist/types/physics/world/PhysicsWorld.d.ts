import TimeOfImpactStack from "../collision/TimeOfImpactStack";
import BaseContact from "../contacts/BaseContact";
import type SphereBody from "../dynamics/SphereBody";
import ContactIslandManager from "../islands/ContactIslandManager";
import type MeshBody from "../mesh/MeshBody";
import ContactSolver from "../solver/ContactSolver";
type WorldMeshBody = MeshBody;
export interface PhysicsSerialData {
    balls: number[];
    mbid: string;
    evolution: number;
}
type TouchHandler = (contact: BaseContact) => void;
type OutOfBoundsHandler = (body: SphereBody) => void;
export default class PhysicsWorld {
    /** @returns {number} */
    get stepSize(): number;
    /** @param {number} value */
    set stepSize(value: number);
    /** @returns {boolean} */
    get environmentReady(): boolean;
    /** @returns {never} */
    get timestamp(): void;
    /** @returns {number} */
    get evolution(): number;
    accumulator: number;
    meshBody: WorldMeshBody | null;
    readonly balls: SphereBody[];
    private readonly qCDSP;
    private readonly qCDSS;
    private readonly ssSkips;
    private readonly p2a;
    private readonly rechecks;
    private nRechecks;
    protected readonly cActings: ContactIslandManager;
    protected readonly cPendings: TimeOfImpactStack;
    private readonly spPool;
    private readonly ssPool;
    protected _environmentReady: boolean;
    internalStep: () => void;
    nAwakened: number;
    touchPresolveHandler: TouchHandler;
    outOfBoundsHandler: OutOfBoundsHandler;
    useStrictMode: boolean;
    solver: ContactSolver;
    private lowestBoundY;
    private readonly _maxSteps;
    protected _stepSize: number;
    private _evolution;
    private tipContact?;
    constructor();
    /** @returns {PhysicsSerialData} */
    static makeSerialData(): PhysicsSerialData;
    /**
     * @param {PhysicsSerialData} source
     * @param {PhysicsSerialData} target
     * @returns {void}
     */
    static copySerialDataAToB(source: PhysicsSerialData, target: PhysicsSerialData): void;
    /**
     * @param {TouchHandler} [handler]
     * @returns {void}
     */
    onTouchPresolve(handler?: TouchHandler): void;
    /**
     * @param {OutOfBoundsHandler} [handler]
     * @returns {void}
     */
    onOutOfBounds(handler?: OutOfBoundsHandler): void;
    /** @returns {void} */
    clearCallbacks(): void;
    /**
     * @param {SphereBody} body
     * @param {ArrayLike<number>} tipData
     * @returns {void}
     */
    shoot(body: SphereBody, tipData: ArrayLike<number>): void;
    /** @returns {void} */
    protected _breakEnvironment(): void;
    /** @returns {void} */
    protected _rebuildEnvironment(): void;
    /** @returns {void} */
    emptyMeshBody(): void;
    /** @returns {void} */
    emptyBalls(): void;
    /** @returns {void} */
    reset(): void;
    /**
     * @param {PhysicsSerialData} data
     * @returns {PhysicsSerialData}
     */
    serialize(data: PhysicsSerialData): PhysicsSerialData;
    /**
     * @param {PhysicsSerialData} data
     * @returns {void}
     */
    deserialize(data: PhysicsSerialData): void;
    /**
     * @param {SphereBody} ball
     * @returns {void}
     */
    addBall(ball: SphereBody): void;
    /**
     * @param {WorldMeshBody} meshBody
     * @returns {void}
     */
    setMeshBody(meshBody: WorldMeshBody): void;
    /**
     * @param {SphereBody} ball
     * @returns {void}
     */
    inactivateBall(ball: SphereBody): void;
    /**
     * @param {number} deltaTime
     * @returns {number}
     */
    step(deltaTime: number): number;
    /**
     * @param {BaseContact} contact
     * @returns {void}
     */
    private markRecheck;
    /**
     * @param {SphereBody[]} excludedBodies
     * @param {number} maxTime
     * @returns {void}
     */
    private flushRechecks;
    /** @returns {never} */
    protected __internalStep_error(): never;
    /** @returns {void} */
    protected __internalStep__(): void;
}
export {};
