import Vec3 from "../math/Vec3";
import type BaseContact from "../contacts/BaseContact";
import type SphereBody from "../dynamics/SphereBody";
import type MeshBody from "../mesh/MeshBody";
import InterruptibleContactSolver from "../solver/InterruptibleContactSolver";
import PhysicsWorld from "./PhysicsWorld";
type NumberedSphereBody = SphereBody & {
    number: number;
    collisionMask: number;
};
type PhysicsSerialData = ReturnType<typeof PhysicsWorld.makeSerialData>;
declare class PredictionContext {
    readonly p0: Vec3;
    readonly p1: Vec3;
    readonly cue: Vec3;
    cueVSq: number;
    readonly impactV1: Vec3;
    targetNumber: number;
    readonly p2: Vec3;
    readonly target: Vec3;
    targetVSq: number;
    _b1: NumberedSphereBody | null;
    private _b2;
    impactOccured: boolean;
    hasImpactTarget: boolean;
    constructor();
    /**
     * @param {NumberedSphereBody} cueBall
     * @returns {void}
     */
    onPredictionStart(cueBall: NumberedSphereBody): void;
    /** @returns {number} */
    onStepped(): number;
    /**
     * @param {NumberedSphereBody | null} targetBody
     * @returns {void}
     */
    onImpact(targetBody: NumberedSphereBody | null): void;
    /** @returns {void} */
    onPredictionEnd(): void;
}
export default class PhysicsWorldClient extends PhysicsWorld {
    balls: NumberedSphereBody[];
    meshBody: any;
    accumulator: number;
    _stepSize: number;
    _environmentReady: boolean;
    solver: any;
    touchPresolveHandler: (contact: BaseContact) => void;
    outOfBoundsHandler: (body: SphereBody) => void;
    useStrictMode: boolean;
    internalStep: () => void;
    readonly predictionCtx: PredictionContext;
    readonly predictorSolver: InterruptibleContactSolver;
    private readonly _serialData;
    private readonly predictorCallback;
    simplifiedMeshBody: ReturnType<MeshBody["slice"]> | null;
    private originMeshBody;
    constructor();
    /**
     * @param {WorldMeshBody} meshBody
     * @returns {void}
     */
    setMeshBody(meshBody: MeshBody): void;
    /** @returns {void} */
    emptyMeshBody(): void;
    /** @returns {void} */
    save(): void;
    /**
     * @param {PhysicsSerialData} [serialData]
     * @returns {void}
     */
    restore(serialData?: PhysicsSerialData): void;
    /**
     * @param {number} deltaTime
     * @returns {number}
     */
    step(deltaTime: number): number;
    /**
     * @param {NumberedSphereBody} cueBall
     * @param {ArrayLike<number>} tipData
     * @param {number} maxDistance
     * @returns {PredictionContext}
     */
    predict(cueBall: NumberedSphereBody, tipData: ArrayLike<number>, maxDistance: number): PredictionContext;
}
export { PredictionContext };
