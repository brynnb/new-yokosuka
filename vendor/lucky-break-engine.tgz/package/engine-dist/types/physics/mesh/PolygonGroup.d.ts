import type CollisionPolygon from "./CollisionPolygon";
export default class PolygonGroup {
    readonly name: string;
    readonly polys: CollisionPolygon[];
    /**
     * @param {string} name
     * @param {import("./CollisionPolygon").default[]} polygons
     */
    constructor(name: string, polygons: CollisionPolygon[]);
    /**
     * @param {number} id
     * @returns {import("./CollisionPolygon").default | null}
     */
    getPolygonByID(id: number): CollisionPolygon | null;
    /**
     * @param {number} group
     * @returns {void}
     */
    setCollisionGroup(group: number): void;
    /** @returns {void} */
    setPolyFrictionAndRestitution(): void;
    /**
     * @param {(...args: unknown[]) => unknown} handler
     * @returns {void}
     */
    setCustomRelativeVelHandler(handler: (...args: unknown[]) => unknown): void;
}
