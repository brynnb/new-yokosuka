import Vec3 from "../math/Vec3";
import type PolygonGroup from "./PolygonGroup";
interface NormalMapImageData {
    width: number;
    height: number;
    data: ArrayLike<number>;
}
declare class NormalTable {
    private readonly array2D;
    private readonly maxRow;
    private readonly maxLine;
    /** @param {NormalMapImageData} imageData */
    constructor(imageData: NormalMapImageData);
    /**
     * @param {number} u
     * @param {number} v
     * @param {Vec3} result
     * @returns {void}
     */
    getNormalByUV(u: number, v: number, result: Vec3): void;
}
declare const PolygonNormalMapExtension: {
    /**
     * @param {NormalMapImageData} imageData
     * @returns {NormalTable}
     */
    createNTableWithImgData(imageData: NormalMapImageData): NormalTable;
    /**
     * @param {import("./PolygonGroup").default} group
     * @param {NormalTable} normalTable
     * @returns {void}
     */
    extendPolyGroup(group: PolygonGroup, normalTable: NormalTable): void;
};
export { NormalTable };
export default PolygonNormalMapExtension;
