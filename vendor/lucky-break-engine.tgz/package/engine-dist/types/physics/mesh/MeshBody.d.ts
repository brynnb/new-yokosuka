import Vec3 from "../math/Vec3";
import CollisionPolygon from "./CollisionPolygon";
import PolygonGroup from "./PolygonGroup";
export interface SerializedPolygon {
    i: number[];
    n: [number, number, number];
    uv?: number[];
    s?: [number, number, number, number];
    f?: string[];
}
export interface SerializedPolygonGroup {
    p: number[];
    q: SerializedPolygon[];
}
export type SerializedMeshBody = Record<string, SerializedPolygonGroup>;
export default class MeshBody {
    /** @returns {CollisionPolygon | null} */
    get ground(): CollisionPolygon | null;
    /** @param {SerializedMeshBody} data */
    readonly groups: PolygonGroup[];
    id: string;
    private _groundPolygon;
    readonly lowestPosition: Vec3;
    nPolygons: number;
    nEdges: number;
    constructor(data: SerializedMeshBody);
    /**
     * @param {string} name
     * @returns {PolygonGroup | null}
     */
    getGroupByName(name: string): PolygonGroup | null;
    /**
     * @param {number} id
     * @returns {CollisionPolygon | null}
     */
    getPolygonByID(id: number): CollisionPolygon | null;
    /**
     * @param {string} name
     * @returns {{ groups: PolygonGroup[] }}
     */
    slice(name: string): {
        groups: PolygonGroup[];
    };
    /**
     * @param {SerializedMeshBody} data
     * @returns {void}
     */
    private initData;
    /**
     * @param {SerializedPolygonGroup} data
     * @returns {CollisionPolygon[]}
     */
    private dataToPolys;
    /** @returns {void} */
    log(): void;
}
