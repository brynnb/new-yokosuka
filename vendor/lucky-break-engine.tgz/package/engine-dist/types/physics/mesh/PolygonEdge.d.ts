import Vec3 from "../math/Vec3";
export interface PolygonEdgeSharedData {
    count: number;
}
export default class PolygonEdge {
    readonly va: Vec3;
    readonly vb: Vec3;
    readonly vab: Vec3;
    readonly abDotAb: number;
    readonly sharedData: PolygonEdgeSharedData;
    /**
     * @param {Vec3} vertexA
     * @param {Vec3} vertexB
     * @param {PolygonEdgeSharedData | null} [sharedData]
     */
    constructor(vertexA: Vec3, vertexB: Vec3, sharedData?: PolygonEdgeSharedData | null);
    /** @returns {PolygonEdge} */
    cloneReversed(): PolygonEdge;
}
