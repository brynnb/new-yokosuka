import Vec3 from "../math/Vec3";
import type PolygonEdge from "./PolygonEdge";
export default class CollisionPolygon {
    ground: boolean;
    sidesoft: boolean;
    sidehard: boolean;
    pocket: boolean;
    tunnel: boolean;
    end: boolean;
    uid: number;
    normal: Vec3;
    edges: PolygonEdge[];
    edgeXNormals: Vec3[];
    readonly centerPosition: Vec3;
    readonly a: number;
    readonly b: number;
    readonly c: number;
    readonly d: number;
    bCenter: Vec3 | null;
    bR: number;
    bRSq: number;
    restitution: number;
    friction: number;
    collisionGroup: number;
    uv: number[] | null;
    private _size;
    /** @returns {string} */
    get label(): string;
    /** @returns {Vec3} */
    get size(): Vec3;
    /**
     * @param {Vec3} normal
     * @param {import("./PolygonEdge").default[]} edges
     */
    constructor(normal: Vec3, edges: PolygonEdge[]);
    /** @returns {string} */
    toString(): string;
    /** @returns {string} */
    toStringShort(): string;
    /**
     * @param {Vec3} center
     * @param {number} radius
     * @returns {void}
     */
    setBoundingSphere(center: Vec3, radius: number): void;
    /**
     * @param {Vec3} point
     * @returns {number}
     */
    distanceFromPointToPlane(point: Vec3): number;
    /** @returns {void} */
    dispose(): void;
}
