import type Mat3 from "../math/Mat3";
import Vec3 from "../math/Vec3";
export interface ImpulseBody {
    applyImpulseAtPoint(impulse: Vec3, arm: Vec3, rollingFrictionPower: number): void;
    addPeneOffset(penetration: number, offset: Vec3): void;
}
export interface SolverContact {
    transformLocVel2Imp: Mat3;
    spaceTransformL2W: Mat3;
    restitution: number;
    friction: number;
    rollingFriction: number;
    bounceThreshold: number;
    bi: ImpulseBody;
    bj: unknown;
    armI: Vec3;
    armLenI: number;
    isSS: boolean;
    armJ?: Vec3;
    armLenJ?: number;
    getRelativeVelocity(): Vec3;
    getCloseSpeed(): number;
    penetration: number;
    normal: Vec3;
    next: SolverContact | null;
}
export interface SolverIsland {
    dirty: boolean;
    totalItems: number;
    itemEntry: SolverContact | null;
    next: SolverIsland | null;
}
export interface SolverIslandList {
    entry: SolverIsland | null;
}
export default class ContactSolver {
    static readonly sharedInstance: ContactSolver;
    protected maxIter: number;
    constructor();
    /**
     * @param {SolverContact} contact
     * @returns {void}
     */
    solveContact(contact: SolverContact): void;
    /**
     * @param {SolverIslandList} islandList
     * @param {boolean} solveAll
     * @returns {void}
     */
    solveList(islandList: SolverIslandList, solveAll: boolean): void;
    /**
     * @param {SolverIsland} island
     * @returns {void}
     */
    solveIsland(island: SolverIsland): void;
    /**
     * @param {SolverIsland} island
     * @returns {boolean}
     */
    protected _solveMostUrgentChildren(island: SolverIsland): boolean;
    /**
     * @param {SolverIsland} island
     * @returns {void}
     */
    protected _sloveChildrenPene(island: SolverIsland): void;
}
