import ContactSolver, { type SolverContact, type SolverIsland, type SolverIslandList } from "./ContactSolver";
type InterruptCallback = (contact: SolverContact) => boolean;
export default class InterruptibleContactSolver extends ContactSolver {
    static readonly sharedInstance: InterruptibleContactSolver;
    private callback;
    interrupt: boolean;
    constructor();
    /**
     * @param {InterruptCallback | null} callback
     * @returns {void}
     */
    reset(callback: InterruptCallback | null): void;
    /**
     * @param {SolverIslandList} islandList
     * @param {boolean} solveAll
     * @returns {void}
     */
    solveList(islandList: SolverIslandList, solveAll: boolean): void;
    /**
     * @param {SolverIsland} island
     * @returns {void}
     */
    solveIsland(island: SolverIsland): void;
    /**
     * @param {SolverIsland} island
     * @returns {boolean}
     */
    protected _solveMostUrgentChildren(island: SolverIsland): boolean;
}
export {};
