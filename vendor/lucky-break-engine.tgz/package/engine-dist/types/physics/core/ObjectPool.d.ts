export interface PoolItem {
    inUse: boolean;
    activate(): this;
    free(): void;
    dispose(): void;
}
type PoolItemConstructor<T extends PoolItem> = new (parent: ObjectPool<T>, index: number) => T;
export default class ObjectPool<T extends PoolItem> {
    /** @returns {number} */
    get size(): number;
    /** @returns {number} */
    get nInUse(): number;
    /**
     * @param {string} name
     * @param {new (parent: ObjectPool<T>, index: number) => T} ItemClass
     * @param {number} initialSize
     */
    readonly pool: T[];
    private readonly freedIndices;
    private readonly maxFreedIndex;
    private freedIndex;
    private poolIndex;
    private readonly itemClass;
    private readonly maxExpCount;
    private readonly name;
    constructor(name: string, ItemClass: PoolItemConstructor<T>, initialSize: number);
    /**
     * @param {number} index
     * @returns {void}
     */
    freeIndex(index: number): void;
    /** @returns {void} */
    dispose(): void;
    /**
     * @param {number} index
     * @returns {T}
     */
    indexAt(index: number): T;
    /** @returns {void} */
    freeAll(): void;
    /** @returns {T} */
    acquire(): T;
    /** @returns {void} */
    log(): void;
}
export {};
