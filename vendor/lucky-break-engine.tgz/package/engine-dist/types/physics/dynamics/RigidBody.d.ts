import Mat3 from "../math/Mat3";
import Quaternion from "../math/Quaternion";
import Vec3 from "../math/Vec3";
export default class RigidBody {
    static baseSleepBias: number;
    static minEnergy: number;
    static maxEnergy: number;
    static wakeUpEnergy: number;
    static readonly vStates: {
        readonly ZERO: 0;
        readonly SLOWER: 1;
        readonly FASTER: 2;
        readonly DIR_CHANGE: 3;
    };
    uid: number;
    active: boolean;
    readonly mass: number;
    readonly invMass: number;
    readonly acc: Vec3;
    cdRound: number;
    readonly v: Vec3;
    private readonly vProp_dir;
    private vProp_sq;
    private vProp_dirty;
    vChangedCount: number;
    private readonly vProp0_dir;
    private vProp0_sq;
    private __vState;
    private __vStateDirty;
    readonly w: Vec3;
    private wProp_sq;
    private wProp_dirty;
    readonly invInertia: Mat3;
    airAngularDamping: number;
    private rfPower;
    private readonly rfDir;
    readonly position: Vec3;
    readonly orientation: Quaternion;
    predictionDirty: boolean;
    steppedLenSq: number;
    canSleep: boolean;
    asleep: boolean;
    energy: number;
    userData: unknown;
    restitution: number;
    friction: number;
    private readonly peneOffset;
    private penetration;
    serializable: boolean;
    collisionGroup: number;
    collisionMask: number;
    /** @returns {number} */
    get wSq(): number;
    /** @returns {Vec3} */
    get vDir(): Vec3;
    /** @returns {number} */
    get vSq(): number;
    /** @returns {number} */
    get vState(): number;
    /**
     * @param {number} mass
     * @param {number} [x]
     * @param {number} [y]
     * @param {number} [z]
     * @param {number} [rotationX]
     * @param {number} [rotationY]
     * @param {number} [rotationZ]
     */
    constructor(mass: number, x?: number, y?: number, z?: number, rotationX?: number, rotationY?: number, rotationZ?: number);
    /**
     * @param {number[]} target
     * @returns {void}
     */
    serialize(target: number[]): void;
    /**
     * @param {ArrayLike<number>} source
     * @param {number} offset
     * @returns {number}
     */
    deserialize(source: ArrayLike<number>, offset: number): number;
    /** @returns {void} */
    dispose(): void;
    /** @returns {void} */
    setSleep(): void;
    /** @returns {void} */
    wakeUp(): void;
    /**
     * @param {Vec3} force
     * @returns {void}
     */
    applyForce(force: Vec3): void;
    /**
     * @param {number} scale
     * @param {Vec3} force
     * @returns {void}
     */
    applyForce2(scale: number, force: Vec3): void;
    /**
     * @param {number} deltaTime
     * @returns {void}
     */
    predVelocities(deltaTime: number): void;
    /**
     * @param {Vec3} impulse
     * @param {Vec3} arm
     * @param {number} rollingFrictionPower
     * @returns {void}
     */
    applyImpulseAtPoint(impulse: Vec3, arm: Vec3, rollingFrictionPower: number): void;
    /**
     * @param {number} deltaTime
     * @returns {boolean}
     */
    step(deltaTime: number): boolean;
    /**
     * @param {number} penetration
     * @param {Vec3} offset
     * @returns {void}
     */
    addPeneOffset(penetration: number, offset: Vec3): void;
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @returns {void}
     */
    reset(x: number, y: number, z: number): void;
    /** @returns {void} */
    private updateVProps;
    /** @returns {void} */
    private updateVState;
    /** @returns {number} */
    getMotion(): number;
}
