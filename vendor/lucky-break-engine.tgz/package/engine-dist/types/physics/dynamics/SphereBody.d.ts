import Quaternion from "../math/Quaternion";
import Mat3 from "../math/Mat3";
import Vec3 from "../math/Vec3";
import RigidBody from "./RigidBody";
interface SphereStates {
    position: Vec3;
    orientation: Quaternion;
}
export default class SphereBody extends RigidBody {
    mass: number;
    invInertia: Mat3;
    position: Vec3;
    orientation: Quaternion;
    v: Vec3;
    w: Vec3;
    uid: number;
    restitution: number;
    friction: number;
    cdRound: number;
    vChangedCount: number;
    invMass: number;
    wakeUp: () => void;
    readonly radius: number;
    readonly radiusSq: number;
    readonly states: SphereStates;
    /**
     * @param {number} radius
     * @param {number} mass
     * @param {number} [x]
     * @param {number} [y]
     * @param {number} [z]
     * @param {number} [rotationX]
     * @param {number} [rotationY]
     * @param {number} [rotationZ]
     */
    constructor(radius: number, mass: number, x?: number, y?: number, z?: number, rotationX?: number, rotationY?: number, rotationZ?: number);
    /** @returns {number} */
    getMotion(): number;
    /**
     * @param {number} deltaTime
     * @returns {void}
     */
    syncStates(deltaTime: number): void;
}
export {};
