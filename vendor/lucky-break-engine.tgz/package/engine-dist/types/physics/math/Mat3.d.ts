import type Vec3 from "./Vec3";
export default class Mat3 {
    readonly data: Float32Array;
    constructor();
    /**
     * @param {number[] | Float32Array} target
     * @param {number} offset
     * @returns {void}
     */
    toArray(target: number[] | Float32Array, offset: number): void;
    /** @returns {string} */
    toString(): string;
    /**
     * @param {import("./Vec3").default} vector
     * @param {import("./Vec3").default} target
     * @returns {void}
     */
    transform(vector: Vec3, target: Vec3): void;
    /**
     * @param {import("./Vec3").default} vector
     * @param {import("./Vec3").default} target
     * @returns {void}
     */
    transformTranspose(vector: Vec3, target: Vec3): void;
    /**
     * @param {number} m00
     * @param {number} m10
     * @param {number} m20
     * @param {number} m01
     * @param {number} m11
     * @param {number} m21
     * @param {number} m02
     * @param {number} m12
     * @param {number} m22
     * @returns {Mat3}
     */
    set(m00: number, m10: number, m20: number, m01: number, m11: number, m21: number, m02: number, m12: number, m22: number): this;
    /** @returns {Mat3} */
    identity(): this;
    /** @returns {number} */
    clone(): number;
    /**
     * @param {ArrayLike<number>} source
     * @param {number} [offset]
     * @returns {number} Number of consumed values.
     */
    fromArray(source: ArrayLike<number>, offset?: number): number;
    /** @param {Mat3} source @returns {Mat3} */
    copy(source: Mat3): this;
    /** @param {number} scale @returns {Mat3} */
    multiplyScalar(scale: number): this;
    /** @param {Mat3} other @returns {Mat3} */
    multiply(other: Mat3): this;
    /** @param {Mat3} other @returns {Mat3} */
    add(other: Mat3): this;
    /** @param {number} value @returns {Mat3} */
    addToDiagonal(value: number): this;
    /** @param {Mat3} source @returns {Mat3} */
    setInverse(source: Mat3): this;
    /** @param {Mat3} source @returns {Mat3} */
    setTranspose(source: Mat3): this;
    /** @returns {Mat3} */
    transpose(): this;
    /** @param {import("./Vec3").default} vector @returns {Mat3} */
    setSkewSymmetric(vector: Vec3): this;
    /**
     * @param {import("./Vec3").default} first
     * @param {import("./Vec3").default} second
     * @param {import("./Vec3").default} third
     * @returns {void}
     */
    setComponents(first: Vec3, second: Vec3, third: Vec3): void;
}
