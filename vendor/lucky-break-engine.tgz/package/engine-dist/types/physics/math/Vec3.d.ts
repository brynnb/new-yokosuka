interface QuaternionLike {
    x: number;
    y: number;
    z: number;
    w: number;
}
/**
 * Mutable three-dimensional vector.
 *
 * @param {number} [x]
 * @param {number} [y]
 * @param {number} [z]
 * @class
 */
export default class Vec3 {
    static readonly ZERO: Vec3;
    static readonly UNIT_X: Vec3;
    static readonly UNIT_Y: Vec3;
    static readonly UNIT_Z: Vec3;
    static readonly EPSILON = 0.000001;
    x: number;
    y: number;
    z: number;
    /**
     * @param {number} [x]
     * @param {number} [y]
     * @param {number} [z]
     */
    constructor(x?: number, y?: number, z?: number);
    /**
     * @param {number[] | Float32Array} target
     * @param {number} offset
     * @returns {void}
     */
    toArray(target: number[] | Float32Array, offset: number): void;
    /**
     * @param {ArrayLike<number>} source
     * @param {number} [offset]
     * @returns {number} Number of consumed values.
     */
    fromArray(source: ArrayLike<number>, offset?: number): number;
    /** @param {number} x @param {number} y @param {number} z @returns {Vec3} */
    set(x: number, y: number, z: number): this;
    /** @returns {Vec3} */
    setZero(): this;
    /** @param {Vec3} source @returns {Vec3} */
    copy(source: Vec3): this;
    /** @param {Vec3} source @returns {Vec3} */
    copyNeg(source: Vec3): this;
    /** @returns {Vec3} */
    clone(): Vec3;
    /** @returns {number} */
    lengthSq(): number;
    /** @returns {number} */
    length(): number;
    /** @returns {Vec3} */
    normalize(): this;
    /** @param {Vec3} source @returns {Vec3} */
    normalizeVector(source: Vec3): this;
    /** @param {Vec3} other @returns {Vec3} */
    add(other: Vec3): this;
    /** @param {Vec3} vector @param {number} scale @returns {Vec3} */
    addScaled(vector: Vec3, scale: number): this;
    /**
     * @param {Vec3} origin
     * @param {Vec3} direction
     * @param {number} distance
     * @returns {Vec3}
     */
    interpolate(origin: Vec3, direction: Vec3, distance: number): this;
    /** @param {Vec3} left @param {Vec3} right @returns {Vec3} */
    addVectors(left: Vec3, right: Vec3): this;
    /** @param {Vec3} other @returns {Vec3} */
    sub(other: Vec3): this;
    /** @param {Vec3} left @param {Vec3} right @returns {Vec3} */
    subVectors(left: Vec3, right: Vec3): this;
    /** @param {Vec3} other @returns {Vec3} */
    cross(other: Vec3): this;
    /** @param {Vec3} left @param {Vec3} right @returns {Vec3} */
    crossVectors(left: Vec3, right: Vec3): this;
    /**
     * @param {Vec3} left
     * @param {Vec3} right
     * @param {Vec3} addend
     * @returns {Vec3}
     */
    setCrossThenAdd(left: Vec3, right: Vec3, addend: Vec3): this;
    /** @param {Vec3} other @returns {number} */
    distanceToSq(other: Vec3): number;
    /** @param {Vec3} other @returns {number} */
    distanceTo(other: Vec3): number;
    /** @param {number} scale @returns {Vec3} */
    scale(scale: number): this;
    /** @param {number} scale @param {Vec3} vector @returns {Vec3} */
    scaleVector(scale: number, vector: Vec3): this;
    /** @param {Vec3} other @returns {Vec3} */
    multiply(other: Vec3): this;
    /** @returns {Vec3} */
    negate(): this;
    /** @param {Vec3} other @returns {number} */
    dot(other: Vec3): number;
    /** @returns {boolean} */
    isZero(): boolean;
    /** @param {number} [epsilon] @returns {boolean} */
    almostZero(epsilon?: number): boolean;
    /** @param {Vec3} other @returns {boolean} */
    almostEquals(other: Vec3): boolean;
    /** @returns {string} */
    toString(): string;
    /** @param {Vec3} target @param {number} amount @returns {Vec3} */
    lerp(target: Vec3, amount: number): this;
    /**
     * @param {QuaternionLike} quaternion
     * @returns {Vec3}
     */
    applyQuaternion(quaternion: QuaternionLike): this;
    /**
     * @param {QuaternionLike} quaternion
     * @param {Vec3} vector
     * @returns {Vec3}
     */
    vectorApplyQuaternion(quaternion: QuaternionLike, vector: Vec3): this;
}
export {};
