import type Vec3 from "./Vec3";
export default class Quaternion {
    x: number;
    y: number;
    z: number;
    w: number;
    /**
     * @param {number} [x]
     * @param {number} [y]
     * @param {number} [z]
     * @param {number} [w]
     */
    constructor(x?: number, y?: number, z?: number, w?: number);
    /**
     * @param {number[] | Float32Array} target
     * @param {number} offset
     * @returns {void}
     */
    toArray(target: number[] | Float32Array, offset: number): void;
    /**
     * @param {ArrayLike<number>} source
     * @param {number} [offset]
     * @returns {number} Number of consumed values.
     */
    fromArray(source: ArrayLike<number>, offset?: number): number;
    /** @returns {string} */
    toString(): string;
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @param {number} w
     * @returns {Quaternion}
     */
    set(x: number, y: number, z: number, w: number): this;
    /**
     * @param {import("./Vec3").default} axis
     * @param {number} angle
     * @returns {Quaternion}
     */
    setFromAngleAxis(axis: Vec3, angle: number): this;
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @param {"XYZ" | "YXZ" | "ZXY" | "ZYX" | "YZX" | "XZY"} [order]
     * @returns {Quaternion}
     */
    setFromEuler(x: number, y: number, z: number, order?: "XYZ" | "YXZ" | "ZXY" | "ZYX" | "YZX" | "XZY"): this;
    /** @returns {Quaternion} */
    clone(): Quaternion;
    /** @param {Quaternion} source @returns {Quaternion} */
    copy(source: Quaternion): this;
    /** @returns {Quaternion} */
    normalize(): this;
    /**
     * @param {import("./Vec3").default} angularVelocity
     * @param {number} deltaTime
     * @returns {Quaternion}
     */
    integrate(angularVelocity: Vec3, deltaTime: number): this;
    /**
     * @param {Quaternion} source
     * @param {import("./Vec3").default} angularVelocity
     * @param {number} deltaTime
     * @returns {Quaternion}
     */
    integrateQuad(source: Quaternion, angularVelocity: Vec3, deltaTime: number): this;
    /**
     * @param {Quaternion} start
     * @param {Quaternion} end
     * @param {number} amount
     * @returns {void}
     */
    slerpQuaternions(start: Quaternion, end: Quaternion, amount: number): void;
    /** @param {Quaternion} other @returns {Quaternion} */
    multiply(other: Quaternion): this;
}
