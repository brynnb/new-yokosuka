import Vec3 from "../math/Vec3";
export interface ShotBall {
    index: number;
    active: boolean;
    radius: number;
    position: Vec3;
}
declare class ShotGeometryUtilities {
    private readonly _sphereToRayOrigin;
    private readonly _segmentDirection;
    private readonly _sectionCopy;
    private readonly _sectionSubtractionResult;
    private readonly _intersectionDistances;
    private readonly _intersectingBallIndices;
    constructor();
    /**
     * @param {number} sectionStart
     * @param {number} sectionEnd
     * @param {number} cutStart
     * @param {number} cutEnd
     * @param {number[]} result
     * @returns {number}
     */
    sectionSub(sectionStart: number, sectionEnd: number, cutStart: number, cutEnd: number, result: number[]): number;
    /**
     * @param {number[]} sections
     * @param {number} cutStart
     * @param {number} cutEnd
     * @returns {void}
     */
    sectionsSub(sections: number[], cutStart: number, cutEnd: number): void;
    /**
     * @param {number} target
     * @param {number[]} sections
     * @returns {number}
     */
    findClosestTInSections(target: number, sections: number[]): number;
    /**
     * @param {number[]} sections
     * @param {number} [minimumLength]
     * @returns {number}
     */
    findCenterOfLongestInSections(sections: number[], minimumLength?: number): number;
    /**
     * @param {Vec3} sphereCenter
     * @param {number} sphereRadius
     * @param {Vec3} rayOrigin
     * @param {Vec3} rayDirection
     * @param {number[]} result
     * @returns {number}
     */
    intersectSphereRay(sphereCenter: Vec3, sphereRadius: number, rayOrigin: Vec3, rayDirection: Vec3, result: number[]): number;
    /**
     * @param {Vec3} sphereCenter
     * @param {number} sphereRadius
     * @param {Vec3} rayOrigin
     * @param {Vec3} rayDirection
     * @returns {number}
     */
    nIntersectSphereRay(sphereCenter: Vec3, sphereRadius: number, rayOrigin: Vec3, rayDirection: Vec3): number;
    /**
     * @param {Vec3} sphereCenter
     * @param {number} sphereRadius
     * @param {Vec3} start
     * @param {Vec3} end
     * @param {number[]} result
     * @returns {number}
     */
    intersectSphereAB(sphereCenter: Vec3, sphereRadius: number, start: Vec3, end: Vec3, result: number[]): number;
    /**
     * @param {Vec3} sphereCenter
     * @param {number} sphereRadius
     * @param {Vec3} start
     * @param {Vec3} direction
     * @param {number} length
     * @param {number[]} result
     * @returns {number}
     */
    intersectSphereADirLen(sphereCenter: Vec3, sphereRadius: number, start: Vec3, direction: Vec3, length: number, result: number[]): number;
    /**
     * @param {Vec3} sphereCenter
     * @param {number} sphereRadius
     * @param {Vec3} start
     * @param {Vec3} direction
     * @param {number} length
     * @returns {number}
     */
    nIntersectSphereADirLen(sphereCenter: Vec3, sphereRadius: number, start: Vec3, direction: Vec3, length: number): number;
    /**
     * @param {ShotBall[]} balls
     * @param {ShotBall | null} ignoredBall
     * @param {number} movingRadius
     * @param {Vec3} start
     * @param {Vec3} end
     * @param {number[]} sections
     * @param {Vec3 | null} fallbackDirection
     * @returns {boolean}
     */
    sectionsBallsAB(balls: ShotBall[], ignoredBall: ShotBall | null, movingRadius: number, start: Vec3, end: Vec3, sections: number[], fallbackDirection: Vec3 | null): boolean;
}
declare const shotGeometryUtilities: ShotGeometryUtilities;
export { ShotGeometryUtilities };
export default shotGeometryUtilities;
