import Vec3 from "../math/Vec3";
export default class PlanarRegionBase {
    static TmpV: Vec3;
    /** @returns {Vec3 | null} */
    get geoCenter(): Vec3 | null;
    readonly normal: Vec3;
    protected d: number;
    constructor();
    /** @returns {boolean} */
    isZeroNormal(): boolean;
    /**
     * @param {Vec3} point
     * @param {Vec3} normal
     * @returns {this}
     */
    setWithPointNormal(point: Vec3, normal: Vec3): this;
    /**
     * @param {Vec3} point
     * @param {Vec3} firstDirection
     * @param {Vec3} secondDirection
     * @returns {this}
     */
    setWithPointAnd2Dirs(point: Vec3, firstDirection: Vec3, secondDirection: Vec3): this;
    /**
     * @param {Vec3} firstPoint
     * @param {Vec3} secondPoint
     * @param {Vec3} thirdPoint
     * @returns {this}
     */
    setWithPoint(firstPoint: Vec3, secondPoint: Vec3, thirdPoint: Vec3): this;
    /**
     * @param {Vec3} point
     * @returns {number}
     */
    signedDistance(point: Vec3): number;
    /**
     * @param {Vec3} rayOrigin
     * @param {Vec3} rayDirection
     * @param {Vec3} target
     * @param {number} [maxDistance]
     * @returns {boolean}
     */
    intersectionWithRay(rayOrigin: Vec3, rayDirection: Vec3, target: Vec3, maxDistance?: number): boolean;
    /** @returns {boolean} */
    projectionInside(..._coordinates: number[]): boolean;
}
