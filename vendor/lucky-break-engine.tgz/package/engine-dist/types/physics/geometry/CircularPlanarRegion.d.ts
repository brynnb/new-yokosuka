import PlanarRegionBase from "./PlanarRegionBase";
import Vec3 from "../math/Vec3";
export default class CircularPlanarRegion extends PlanarRegionBase {
    /** @returns {number} */
    get radius(): number;
    /** @returns {Vec3} */
    get center(): Vec3;
    /** @returns {Vec3} */
    get arcDir(): Vec3;
    /** @returns {Vec3} */
    get geoCenter(): Vec3;
    /** @returns {Vec3} */
    get diameterDir(): Vec3;
    /** @returns {Vec3} */
    get diameterA(): Vec3;
    /** @returns {Vec3} */
    get diameterB(): Vec3;
    private readonly _center;
    private _radius;
    private readonly _arcDir;
    private readonly _diameterA;
    private readonly _diameterB;
    private readonly _diameterDir;
    private _geoCenter;
    constructor();
    /**
     * @param {number} centerX
     * @param {number} centerY
     * @param {number} centerZ
     * @param {number} topX
     * @param {number} topY
     * @param {number} topZ
     * @param {Vec3} normal
     * @returns {void}
     */
    resetWithCenterTopNormal(centerX: number, centerY: number, centerZ: number, topX: number, topY: number, topZ: number, normal: Vec3): void;
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @returns {boolean}
     */
    projectionInside(x: number, y: number, z: number): boolean;
    /** @returns {string} */
    toString(): string;
}
