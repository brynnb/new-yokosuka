import PlanarRegionBase from "./PlanarRegionBase";
import Vec3 from "../math/Vec3";
interface PolygonRegionSource {
    edges: Array<{
        va: Vec3;
    }>;
    normal: Vec3;
    edgeXNormals: Vec3[];
}
export default class PolygonPlanarRegion extends PlanarRegionBase {
    /** @returns {Vec3 | null} */
    get geoCenter(): Vec3 | null;
    private readonly _ps;
    private readonly _edgeXNormals;
    private _geoCenter;
    constructor();
    /**
     * @param {import("../mesh/CollisionPolygon").default} polygon
     * @returns {void}
     */
    resetWithAtomPolygon(polygon: PolygonRegionSource): void;
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @returns {boolean}
     */
    projectionInside(x: number, y: number, z: number): boolean;
}
export {};
