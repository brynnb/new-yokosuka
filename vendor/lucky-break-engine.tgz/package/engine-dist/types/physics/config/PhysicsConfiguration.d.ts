import Vec3 from "../math/Vec3";
interface BallMaterial {
    restitution: number;
    friction: number;
}
interface PolygonMaterial {
    friction: number;
    restitution: number;
}
interface PhysicsConfigurationState {
    gravity: Vec3;
    tPrecision: number;
    islandUpdMinDisSq: number;
    airAngularDamping: number;
    frictionS: number;
    frictionP: number;
    restitution: Record<string, number>;
    __gravityDir: Vec3 | null;
    getGravityDir(): Vec3;
    setBallFrictionAndRestitution(ball: BallMaterial): void;
    setPolyFrictionAndRestitution(polygon: PolygonMaterial): void;
}
declare const PhysicsConfiguration: PhysicsConfigurationState;
export default PhysicsConfiguration;
