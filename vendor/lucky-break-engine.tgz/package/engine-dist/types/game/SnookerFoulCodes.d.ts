/** @type {{
 *   MISS_TARGET: number,
 *   ILLEGAL_FIRST_HIT: number,
 *   ILLEGAL_POTTING: number,
 *   POTTING_CUE_BALL: number,
 *   OFF_TABLE: number,
 *   NO_RAIL_AFTER_CONTACT: number,
 *   ILLEGAL_BREAK: number,
 * }} */
declare const FoulCode: any;
/**
 * @param {number} code
 * @returns {string}
 */
declare function getFoulDescription(code: number): string;
declare const SnookerFoulCodes: {
    FoulCode: any;
    getFoulDescription: typeof getFoulDescription;
};
export { FoulCode, getFoulDescription };
export default SnookerFoulCodes;
