import type { UserInfo } from "./GameDataFactories";
export default class GamePlayer {
    static readonly PLAYER_TYPE_USER = 0;
    static readonly PLAYER_TYPE_AI = 1;
    static readonly PLAYER_TYPE_REMOTE = 2;
    private _userInfo;
    private readonly _userId;
    private readonly _type;
    pts: number;
    penalty: number;
    private _brk;
    private _maxBrk;
    shootingCount: number;
    scoreCount: number;
    /** @returns {string | number} */
    get id(): string | number;
    /** @returns {number} */
    get type(): number;
    /** @returns {string} */
    get displayName(): string;
    /**
     * @param {UserInfo} userInfo
     * @param {number} type
     */
    constructor(userInfo: UserInfo, type: number);
    /** @returns {number} */
    get maxbrk(): number;
    /** @returns {number} */
    get brk(): number;
    /** @param {number} value */
    set brk(value: number);
    /** @returns {number} */
    get accuracy(): number;
    /** @returns {void} */
    clearScores(): void;
    /**
     * @template {keyof UserInfo} K
     * @param {K} key
     * @returns {UserInfo[K]}
     */
    getInfoData<K extends keyof UserInfo>(key: K): UserInfo[K];
    /** @returns {void} */
    dispose(): void;
}
