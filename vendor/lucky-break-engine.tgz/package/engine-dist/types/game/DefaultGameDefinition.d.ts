/**
 * @typedef {{
 *   sceneId: string,
 *   ballSet: number[],
 *   ballRadius: number,
 *   ballMass: number,
 *   refId: string,
 * }} GameDefinition
 */
/** @type {{ default: GameDefinition }} */
declare const DefaultGameDefinition: {
    default: {
        sceneId: string;
        ballSet: number[];
        ballRadius: number;
        ballMass: number;
        refId: string;
    };
};
export default DefaultGameDefinition;
