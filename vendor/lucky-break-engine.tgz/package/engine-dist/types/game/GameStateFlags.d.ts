/** @type {{
 *   ERROR: number,
 *   NO_GAME: number,
 *   PENDING: number,
 *   READY: number,
 *   SIMULATING: number,
 *   JUDGING: number,
 * }} */
declare const GameStateFlags: any;
export default GameStateFlags;
