import type BilliardBallBody from "../../simulator/BilliardBallBody";
import type { GameContext, RefereeResult, SimulatorResult } from "../GameDataFactories";
import RefereeBase from "./RefereeBase";
import type { InHandPlacementRegion } from "./RefereeBase";
interface NineBallSimulator {
    result: SimulatorResult;
    getBallAtIndex(index: number): BilliardBallBody;
    getBalls(): BilliardBallBody[];
    respotIndexDefault(index: number): void;
}
export default class NineBallReferee extends RefereeBase {
    private _openingBreak;
    get inHandPlacementRegion(): InHandPlacementRegion | null;
    resetGContext(context: GameContext): void;
    projectionInSideValidRegion(x: number, y: number, z: number): boolean;
    checkResult(context: GameContext, simulator: NineBallSimulator, refereeResult: RefereeResult): void;
    private _restoreCueBall;
    private _lowestActiveBallMask;
}
export {};
