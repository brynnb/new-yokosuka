import EventEmitter from "../../core/EventEmitter";
import PolygonPlanarRegion from "../../physics/geometry/PolygonPlanarRegion";
import type Vec3 from "../../physics/math/Vec3";
import type { GameContext, RefereeResult } from "../GameDataFactories";
interface RefereeSimulatorArea {
    sceneId: string;
    ground: Parameters<PolygonPlanarRegion["resetWithAtomPolygon"]>[0];
}
export interface InHandPlacementRegion {
    axis: "x" | "z";
    coordinate: number;
    side: -1 | 1;
}
export default class RefereeBase extends EventEmitter {
    /** @returns {Vec3 | null} */
    get validRegionGeoCenter(): Vec3 | null;
    get inHandPlacementRegion(): InHandPlacementRegion | null;
    /** @returns {number} */
    get sysReservedBallOn(): number;
    protected _sceneId: string;
    protected readonly _playArea: PolygonPlanarRegion;
    constructor();
    /**
     * @param {RefereeSimulatorArea} simulator
     * @returns {void}
     */
    syncAreaWithSimulator(simulator: RefereeSimulatorArea): void;
    /**
     * @param {Vec3} origin
     * @param {Vec3} direction
     * @param {Vec3} result
     * @returns {boolean}
     */
    intersectionRayValidRegionPlane(origin: Vec3, direction: Vec3, result: Vec3): boolean;
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @returns {boolean}
     */
    projectionInSideValidRegion(x: number, y: number, z: number): boolean;
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @returns {boolean}
     */
    projectionOnTable(x: number, y: number, z: number): boolean;
    /**
     * @param {GameContext} context
     * @returns {void}
     */
    resetGContext(context: GameContext): void;
    /**
     * @param {GameContext} context
     * @param {any} simulator
     * @param {RefereeResult} result
     * @returns {void}
     */
    checkResult(context: GameContext, simulator: unknown, result: RefereeResult): void;
}
export {};
