import Vec3 from "../../physics/math/Vec3";
import type CollisionPolygon from "../../physics/mesh/CollisionPolygon";
import type BilliardBallBody from "../../simulator/BilliardBallBody";
import type { GameContext, RefereeResult, SimulatorResult } from "../GameDataFactories";
import RefereeBase from "./RefereeBase";
interface RefereeSimulatorArea {
    sceneId: string;
    ground: CollisionPolygon;
}
interface SnookerSimulator extends RefereeSimulatorArea {
    ballRadius: number;
    result: SimulatorResult;
    getBallAtIndex(index: number): BilliardBallBody;
    getBalls(): BilliardBallBody[];
    touchBalls(excludedIndex: number, position: Vec3, distance?: number): boolean;
    respotIndexDefault(index: number): void;
    resetBallPosition(ball: BilliardBallBody, position: Vec3 | null | undefined): void;
    resetBallXYZ(ball: BilliardBallBody, x: number, y: number, z: number): void;
}
declare const BallOn: {
    readonly RED: 2;
    readonly YELLOW: 4;
    readonly BLACK: 128;
    readonly COLOR_ALL: 252;
};
export default class SnookerReferee extends RefereeBase {
    /** @returns {Vec3} */
    get validRegionGeoCenter(): Vec3;
    private readonly _dArea;
    private readonly _tmpArray;
    private readonly _tmpOccupiedSpots;
    private readonly _tmpSections;
    private readonly _tmpA;
    private readonly _tmpB;
    private readonly _respotColorBallsSortHandler;
    constructor();
    /**
     * @param {RefereeSimulatorArea} simulator
    * @returns {void}
    */
    syncAreaWithSimulator(simulator: RefereeSimulatorArea): void;
    /**
     * @param {Vec3} origin
     * @param {Vec3} direction
     * @param {Vec3} result
     * @returns {boolean}
     */
    intersectionRayValidRegionPlane(origin: Vec3, direction: Vec3, result: Vec3): boolean;
    /**
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @returns {boolean}
     */
    projectionInSideValidRegion(x: number, y: number, z: number): boolean;
    /**
     * @param {GameContext} context
     * @returns {void}
     */
    resetGContext(context: GameContext): void;
    /**
     * @param {GameContext} context
     * @param {SnookerSimulator} simulator
     * @param {RefereeResult} refereeResult
     * @returns {void}
     */
    checkResult(context: GameContext, simulator: SnookerSimulator, refereeResult: RefereeResult): void;
    /**
     * @param {number[]} pottedIndices
     * @param {number[]} outOfBoundsIndices
     * @param {SnookerSimulator} simulator
     * @returns {void}
     */
    private _liveRespot;
    /**
     * @param {SnookerSimulator} simulator
     * @returns {number}
     */
    private _nActiveReds;
    /**
     * @param {BilliardBallBody[]} colorBalls
     * @param {SnookerSimulator} simulator
     * @returns {void}
     */
    private _liveRespotColorBalls;
    /**
     * @param {SnookerSimulator} simulator
     * @returns {void}
     */
    private _liveRespotCueBall;
}
export { BallOn };
