import type RefereeBase from "./RefereeBase";
declare const RefereeRegistry: {
    getInstance(id: string): RefereeBase;
};
export default RefereeRegistry;
