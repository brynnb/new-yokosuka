export interface UserInfo {
    userId: string | number;
    displayName: string;
    level: number;
    stickName: string;
}
export interface GameContext {
    nRounds: number;
    inHand: number;
    playerIndex: number;
    ballOn: number;
    winnerIndex: number;
}
export interface SimulatorResult {
    nKissed: number;
    firstKissIndex: number;
    pottedIndices: number[];
    outOfBoundsIndices: number[];
    railAfterFirstContact: boolean;
    objectRailContactIndices: number[];
}
export interface RefereeResult {
    score: number;
    foulCode: number;
}
declare const GameDataFactories: {
    /**
     * @param {string | number} userId
     * @param {string} displayName
     * @param {number} level
     * @param {string} stickName
     * @returns {UserInfo}
     */
    makeUserInfo(userId: string | number, displayName: string, level: number, stickName: string): UserInfo;
    /** @returns {GameContext} */
    makeGContext(): GameContext;
    /** @returns {SimulatorResult} */
    makeSimulatorResult(): SimulatorResult;
    /** @returns {RefereeResult} */
    makeRefResult(): RefereeResult;
};
export default GameDataFactories;
