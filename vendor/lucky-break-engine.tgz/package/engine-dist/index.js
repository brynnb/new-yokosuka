//#region src/physics/math/Vec3.ts
var e = class e {
	static ZERO = new e(0, 0, 0);
	static UNIT_X = new e(1, 0, 0);
	static UNIT_Y = new e(0, 1, 0);
	static UNIT_Z = new e(0, 0, 1);
	static EPSILON = 1e-6;
	x;
	y;
	z;
	constructor(e = 0, t = 0, n = 0) {
		this.x = e || 0, this.y = t || 0, this.z = n || 0;
	}
	toArray(e, t) {
		e[t] = this.x, e[t + 1] = this.y, e[t + 2] = this.z;
	}
	fromArray(e, t = 0) {
		return this.x = e[t], this.y = e[t + 1], this.z = e[t + 2], 3;
	}
	set(e, t, n) {
		return this.x = e, this.y = t, this.z = n, this;
	}
	setZero() {
		return this.x = 0, this.y = 0, this.z = 0, this;
	}
	copy(e) {
		return this.x = e.x, this.y = e.y, this.z = e.z, this;
	}
	copyNeg(e) {
		return this.x = -e.x, this.y = -e.y, this.z = -e.z, this;
	}
	clone() {
		return new e(this.x, this.y, this.z);
	}
	lengthSq() {
		return this.x * this.x + this.y * this.y + this.z * this.z;
	}
	length() {
		return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
	}
	normalize() {
		let e = this.length();
		if (e > 0) {
			let t = 1 / e;
			this.x *= t, this.y *= t, this.z *= t;
		} else this.x = 0, this.y = 0, this.z = 0;
		return this;
	}
	normalizeVector(e) {
		let t = e.length();
		if (t > 0) {
			let n = 1 / t;
			this.x = e.x * n, this.y = e.y * n, this.z = e.z * n;
		} else this.x = 0, this.y = 0, this.z = 0;
		return this;
	}
	add(e) {
		return this.x += e.x, this.y += e.y, this.z += e.z, this;
	}
	addScaled(e, t) {
		return this.x += e.x * t, this.y += e.y * t, this.z += e.z * t, this;
	}
	interpolate(e, t, n) {
		return this.x = e.x + t.x * n, this.y = e.y + t.y * n, this.z = e.z + t.z * n, this;
	}
	addVectors(e, t) {
		return this.x = e.x + t.x, this.y = e.y + t.y, this.z = e.z + t.z, this;
	}
	sub(e) {
		return this.x -= e.x, this.y -= e.y, this.z -= e.z, this;
	}
	subVectors(e, t) {
		return this.x = e.x - t.x, this.y = e.y - t.y, this.z = e.z - t.z, this;
	}
	cross(e) {
		let t = this.x, n = this.y, r = this.z;
		return this.x = n * e.z - r * e.y, this.y = r * e.x - t * e.z, this.z = t * e.y - n * e.x, this;
	}
	crossVectors(e, t) {
		let n = e.x, r = e.y, i = e.z, a = t.x, o = t.y, s = t.z;
		return this.x = r * s - i * o, this.y = i * a - n * s, this.z = n * o - r * a, this;
	}
	setCrossThenAdd(e, t, n) {
		let r = e.x, i = e.y, a = e.z, o = t.x, s = t.y, c = t.z;
		return this.x = i * c - a * s + n.x, this.y = a * o - r * c + n.y, this.z = r * s - i * o + n.z, this;
	}
	distanceToSq(e) {
		let t = this.x - e.x, n = this.y - e.y, r = this.z - e.z;
		return t * t + n * n + r * r;
	}
	distanceTo(e) {
		let t = this.x - e.x, n = this.y - e.y, r = this.z - e.z;
		return Math.sqrt(t * t + n * n + r * r);
	}
	scale(e) {
		return this.x *= e, this.y *= e, this.z *= e, this;
	}
	scaleVector(e, t) {
		return this.x = e * t.x, this.y = e * t.y, this.z = e * t.z, this;
	}
	multiply(e) {
		return this.x *= e.x, this.y *= e.y, this.z *= e.z, this;
	}
	negate() {
		return this.x = -this.x, this.y = -this.y, this.z = -this.z, this;
	}
	dot(e) {
		return this.x * e.x + this.y * e.y + this.z * e.z;
	}
	isZero() {
		return this.x === 0 && this.y === 0 && this.z === 0;
	}
	almostZero(t = e.EPSILON) {
		return !(Math.abs(this.x) > t || Math.abs(this.y) > t || Math.abs(this.z) > t);
	}
	almostEquals(t) {
		let n = e.EPSILON, r = Math.abs;
		return !(r(this.x - t.x) > n || r(this.y - t.y) > n || r(this.z - t.z) > n);
	}
	toString() {
		return "{" + this.x + ", " + this.y + ", " + this.z + "}";
	}
	lerp(e, t) {
		return this.x += (e.x - this.x) * t, this.y += (e.y - this.y) * t, this.z += (e.z - this.z) * t, this;
	}
	applyQuaternion(e) {
		let t = this.x, n = this.y, r = this.z, i = e.x, a = e.y, o = e.z, s = e.w, c = s * t + a * r - o * n, l = s * n + o * t - i * r, u = s * r + i * n - a * t, d = -i * t - a * n - o * r;
		return this.x = c * s + d * -i + l * -o - u * -a, this.y = l * s + d * -a + u * -i - c * -o, this.z = u * s + d * -o + c * -a - l * -i, this;
	}
	vectorApplyQuaternion(e, t) {
		let n = t.x, r = t.y, i = t.z, a = e.x, o = e.y, s = e.z, c = e.w, l = c * n + o * i - s * r, u = c * r + s * n - a * i, d = c * i + a * r - o * n, f = -a * n - o * r - s * i;
		return this.x = l * c + f * -a + u * -s - d * -o, this.y = u * c + f * -o + d * -a - l * -s, this.z = d * c + f * -s + l * -o - u * -a, this;
	}
};
for (let t of Object.getOwnPropertyNames(e.prototype)) t !== "constructor" && Object.defineProperty(e.prototype, t, { enumerable: !0 });
var t = new class {
	_sphereToRayOrigin;
	_segmentDirection;
	_sectionCopy;
	_sectionSubtractionResult;
	_intersectionDistances;
	_intersectingBallIndices;
	constructor() {
		this._sphereToRayOrigin = new e(), this._segmentDirection = new e(), this._sectionCopy = [], this._sectionSubtractionResult = [], this._intersectionDistances = [], this._intersectingBallIndices = [];
	}
	sectionSub(t, n, r, i, a) {
		let o = e.EPSILON;
		if (i <= t || r >= n) return a[0] = t, a[1] = n, 2;
		let s = 0;
		return r > t + o && (a[s++] = t, a[s++] = r), n > i + o && (a[s++] = i, a[s++] = n), s;
	}
	sectionsSub(e, t, n) {
		let r = this._sectionCopy, i = this._sectionSubtractionResult, a = e.length;
		for (let t = 0; t !== a; ++t) r[t] = e[t];
		e.length = 0;
		for (let o = 0; o !== a / 2; ++o) {
			let a = this.sectionSub(r[2 * o], r[2 * o + 1], t, n, i);
			for (let t = 0; t < a; ++t) e.push(i[t]);
		}
	}
	findClosestTInSections(e, t) {
		let n = t.length;
		if (n === 0) return e;
		let r = 0, i = !1;
		for (; r < n && e - t[r] >= 0;) i = !i, r++;
		if (i) return e;
		if (r === 0) return t[r];
		if (r === n) return t[r - 1];
		let a = t[r - 1], o = t[r];
		return e - a > o - e ? o : a;
	}
	findCenterOfLongestInSections(e, t = 0) {
		let n = NaN, r = e.length / 2;
		if (r === 0) return n;
		let i = 0;
		for (let a = 0; a !== r; ++a) {
			let r = e[2 * a], o = e[2 * a + 1], s = o - r;
			s - i > t && (i = s, n = (r + o) / 2);
		}
		return n;
	}
	intersectSphereRay(t, n, r, i, a) {
		let o = e.EPSILON, s = this._sphereToRayOrigin.subVectors(r, t), c = s.dot(i), l = s.dot(s) - n * n;
		if (l > 0 && c > 0) return 0;
		let u = c * c - l;
		if (u < -o) return 0;
		if (u > o) {
			let e = Math.sqrt(u), t = -c - e, n = -c + e;
			return a[0] = t < 0 ? 0 : t, a[1] = n < 0 ? 0 : n, 2;
		}
		let d = -c;
		return a[0] = d < 0 ? 0 : d, 1;
	}
	nIntersectSphereRay(e, t, n, r) {
		return this.intersectSphereRay(e, t, n, r, this._intersectionDistances);
	}
	intersectSphereAB(e, t, n, r, i) {
		let a = this._segmentDirection.subVectors(r, n), o = a.length();
		return this.intersectSphereADirLen(e, t, n, a.normalize(), o, i);
	}
	intersectSphereADirLen(e, t, n, r, i, a) {
		let o = this.intersectSphereRay(e, t, n, r, a);
		return o === 0 ? 0 : o === 1 ? a[0] > i ? 0 : 1 : a[0] > i ? 0 : (a[1] > i && (a[1] = i), 2);
	}
	nIntersectSphereADirLen(e, t, n, r, i) {
		return this.intersectSphereADirLen(e, t, n, r, i, this._intersectionDistances);
	}
	sectionsBallsAB(t, n, r, i, a, o, s) {
		let c = e.EPSILON, l = this._segmentDirection.subVectors(a, i), u = l.length(), d = this._intersectionDistances, f = this._intersectingBallIndices, p = 0;
		l.normalize(), o[0] = 0, o[1] = u, o.length = 2;
		for (let e = 0; e !== t.length; ++e) {
			let a = t[e];
			if (a === n || !a.active) continue;
			let s = r + a.radius;
			this.intersectSphereADirLen(a.position, s, i, l, u, d) === 2 && d[1] - d[0] > c && (this.sectionsSub(o, d[0], d[1]), f[p++] = a.index);
		}
		if (o.length > 0) return !0;
		if (s) {
			let e = Number.MAX_VALUE;
			for (let n = 0; n !== p; ++n) {
				let a = t[f[n]];
				this._sphereToRayOrigin.subVectors(i, a.position);
				let o = r + a.radius - this._sphereToRayOrigin.dot(s);
				o < e && (e = o);
			}
			o[0] = e;
		}
		return !1;
	}
}(), n = class e {
	x;
	y;
	constructor(e = 0, t = 0) {
		this.x = e, this.y = t;
	}
	set(e, t) {
		return this.x = e, this.y = t, this;
	}
	copy(e) {
		return this.set(e.x, e.y);
	}
	clone() {
		return new e(this.x, this.y);
	}
	toString() {
		return `{${this.x}, ${this.y}}`;
	}
	lengthSq() {
		return this.x * this.x + this.y * this.y;
	}
	length() {
		return Math.sqrt(this.lengthSq());
	}
	normalize() {
		let e = this.length();
		return e > 0 ? (this.x /= e, this.y /= e) : (this.x = 0, this.y = 0), this;
	}
	normalizeVector(e) {
		let t = e.length();
		return t > 0 ? (this.x = e.x / t, this.y = e.y / t) : (this.x = 0, this.y = 0), this;
	}
	add(e) {
		return this.x += e.x, this.y += e.y, this;
	}
	addVectors(e, t) {
		return this.set(e.x + t.x, e.y + t.y);
	}
	addScaled(e, t) {
		this.x += e.x * t, this.y += e.y * t;
	}
	interpolate(e, t, n) {
		return this.set(e.x + t.x * n, e.y + t.y * n);
	}
	sub(e) {
		return this.x -= e.x, this.y -= e.y, this;
	}
	subVectors(e, t) {
		return this.set(e.x - t.x, e.y - t.y);
	}
	dot(e) {
		return this.x * e.x + this.y * e.y;
	}
	distanceToSq(e) {
		let t = this.x - e.x, n = this.y - e.y;
		return t * t + n * n;
	}
	distanceTo(e) {
		return Math.sqrt(this.distanceToSq(e));
	}
	scale(e) {
		return this.x *= e, this.y *= e, this;
	}
	scaleVector(e, t) {
		return this.set(e * t.x, e * t.y);
	}
	isZero() {
		return this.x === 0 && this.y === 0;
	}
	almostZero() {
		return Math.abs(this.x) <= 1e-6 && Math.abs(this.y) <= 1e-6;
	}
	almostEquals(e) {
		return Math.abs(this.x - e.x) <= 1e-6 && Math.abs(this.y - e.y) <= 1e-6;
	}
	lerp(e, t) {
		return this.x += (e.x - this.x) * t, this.y += (e.y - this.y) * t, this;
	}
}, r = 20, i = class e {
	get length() {
		return this._length;
	}
	routes;
	_length;
	constructor() {
		this.routes = [];
		for (let t = 0; t < r; t++) this.routes[t] = e.makeRoute();
		this._length = 0;
	}
	getAtIndex(e) {
		return this.routes[e];
	}
	next(t, n, r, i, a, o) {
		let s = this.routes[this._length++];
		return s || (s = e.makeRoute(), this.routes.push(s)), s.pkIndex = -1, s.ballBIndex = -1, s.dx = t, s.dy = n, s.dz = r, s.fbSpin = i, s.powerFactor = a, s.priority = o, s;
	}
	clear() {
		this._length = 0;
	}
	static makeRoute() {
		return Object.create(null);
	}
}, a = new i(), o = .02, s = new e(), c = new e(), l = new e(), u = new e(), d = new e(), f = new e(), p = new e(), m = new e(), h = new n(), g = new n(), _ = new n(), v = new n(), y = new n(), b = new n(), x = new n(), S = class n {
	_simEvolution;
	_ballOnindices;
	_ballCheckIndex;
	_pkIndex;
	_routeCache;
	_isBreak;
	_props;
	_currentTaskIndex;
	_tasks;
	get taskRunning() {
		return this._currentTaskIndex !== -1;
	}
	constructor() {
		this._simEvolution = -1, this._ballOnindices = [], this._ballCheckIndex = 0, this._pkIndex = 0, this._routeCache = a, this._isBreak = !1, this._props = {
			range: 0,
			abf: 0,
			bcf: 0,
			chaoticSeed: 1,
			bpm: 1,
			mpm: 1
		}, this._currentTaskIndex = -1, this._tasks = [
			(e, t, r) => {
				if (this.getIsBreak()) return !0;
				let i = performance.now(), a = e.playArea, s = a.pockets, c = t.getBallAtIndex(0);
				for (; this._ballCheckIndex < this._ballOnindices.length;) {
					let e = t.getBallAtIndex(this._ballOnindices[this._ballCheckIndex]);
					for (; this._pkIndex < s.length;) if (n._checkSinglePK(c, e, this._pkIndex++, a, t, r, this._routeCache), performance.now() - i > o) return !1;
					this._ballCheckIndex++, this._pkIndex = 0;
				}
				return !0;
			},
			(e, t, r) => {
				let i = performance.now(), a = e.playArea, s = t.getBallAtIndex(0), c, l, u, d;
				for (this.getIsBreak() ? (c = 2 * s.radius, l = .85 + .14 * Math.random(), u = .65, d = 1) : (c = -.5 * s.radius, l = .99 + .009 * Math.random(), u = .6, d = 5); this._ballCheckIndex < this._ballOnindices.length;) {
					let e = t.getBallAtIndex(this._ballOnindices[this._ballCheckIndex]);
					if (n._checkPassAbility(s, e, a, t, r, this._routeCache, c, l, u, d)) return !0;
					if (this._ballCheckIndex++, performance.now() - i > o) return !1;
				}
				return !0;
			},
			(t, r) => {
				if (this._ballCheckIndex >= this._ballOnindices.length) return !0;
				let i = e.EPSILON, a = r.sidePolyGroups.polys, o = r.getBallAtIndex(0), c = r.getBallAtIndex(this._ballOnindices[this._ballCheckIndex++]), d = r.getBalls(), f = h.set(o.position.x, o.position.z), p = g.set(c.position.x, c.position.z), m = _.subVectors(p, f), S = y, C = b, w = x, T = v, E = l, D = u, O = s, k = o.radius;
				for (let e of a) {
					if (!e.sidehard || e.bCenter) continue;
					let t = n._getPolyHorizEdge(e);
					if (!t) continue;
					T.set(e.normal.x, e.normal.z).normalize(), S.set(t.va.x, t.va.z), C.set(t.vab.x, t.vab.z);
					let r = C.length();
					C.scale(1 / r);
					let a = w.subVectors(f, S).dot(T) - k, s = w.subVectors(p, S).dot(T) - k;
					if (a * s < 0) continue;
					let l = a + s, u = a / l, h = k + 2 * a * s / l, g = Math.abs(C.x) > Math.abs(C.y) ? (m.x * u - T.x * h + f.x - S.x) / C.x : (m.y * u - T.y * h + f.y - S.y) / C.y;
					if (g < i || g > r - i) continue;
					E.set(S.x + C.x * g + T.x * k, o.position.y, S.y + C.y * g + T.y * k), D.subVectors(E, o.position);
					let _ = D.length();
					if (D.scale(1 / _), !n._isSegmentSafe(o.position, D, _, k, d, o, c)) continue;
					O.subVectors(c.position, E);
					let v = O.length();
					if (O.scale(1 / v), !n._isSegmentSafe(E, O, v, k, d, c)) continue;
					let y = .2 + .02 * (_ + v), b = O.dot(D) + 1;
					b *= b;
					let x = -y * b, ee = 1 - v / 10;
					this._routeCache.next(D.x, D.y, D.z, x, y, ee);
				}
				return !1;
			}
		];
	}
	setFactors(e) {
		this._props.range = e.range, this._props.abf = e.abf, this._props.bcf = e.bcf, this._props.chaoticSeed = e.chaoticSeed, this._props.mpm = e.mpm, this._props.bpm = e.bpm;
	}
	erase() {
		this._ballOnindices.length = 0, this._routeCache.clear(), this._currentTaskIndex = -1;
	}
	getIsBreak() {
		return this._isBreak;
	}
	checkRestart(e, t) {
		let n = e.evolution;
		if (this._simEvolution === n) return !1;
		this._simEvolution = n, this.erase();
		let r = e.getBalls(), i = t.getContext("ballOn");
		for (let e = 1; e < r.length; e++) {
			let t = r[e];
			t.active && 2 ** t.number & i && this._ballOnindices.push(e);
		}
		return this._ballCheckIndex = 0, this._pkIndex = 0, this._currentTaskIndex = 0, this._isBreak = t.getContext("nRounds") === 0, !0;
	}
	step(e, t, r) {
		if (!this._tasks[this._currentTaskIndex](e, t, r)) return null;
		let i = this._routeCache;
		if (i.length === 0) return this._currentTaskIndex++, this._currentTaskIndex >= this._tasks.length ? (this._currentTaskIndex = -1, n._fallbackRoute(i, t, this._ballOnindices[0]), i.getAtIndex(0)) : (this._ballCheckIndex = 0, this._pkIndex = 0, null);
		this._currentTaskIndex = -1;
		let a = -1, o = null;
		for (let e = 0; e < i.length; e++) {
			let t = i.getAtIndex(e);
			t.priority > a && (a = t.priority, o = t);
		}
		return o ? (o.pkIndex !== -1 && o.ballBIndex !== -1 && n._chaos(o, e, t, this._props), o) : null;
	}
	static _fallbackRoute(e, t, n) {
		let r = t.getBallAtIndex(0), i = n === void 0 ? null : t.getBallAtIndex(n), a = i ? u.subVectors(i.position, r.position).normalize() : u.set(1, 0, 0);
		e.next(a.x, a.y, a.z, 0, .35, .01);
	}
	static _getPolyHorizEdge(t) {
		for (let n of t.edges) if (Math.abs(n.vab.y) <= e.EPSILON) return n;
		return null;
	}
	static _chaos(t, n, r, i) {
		if (Math.random() < .05) return;
		let a = r.getBallAtIndex(0), o = r.getBallAtIndex(t.ballBIndex), d = n.playArea.pockets[t.pkIndex], f = a.position.distanceTo(o.position), h = u.set(t.dx, t.dy, t.dz), g = s.subVectors(d.position, o.position);
		g.y = 0;
		let _ = g.length(), v = c.scaleVector(1 / _, g), y = h.dot(v), b = this._sigmoid01(_ - 1.8 * y * y, .5) * i.bcf, x = Math.min(1, f / i.range) * i.abf;
		x *= x;
		let S = x + b, C = (1 - Math.random() ** +i.chaoticSeed) * S, w = p.crossVectors(g, e.UNIT_Y).normalize();
		Math.random() > .5 && (C *= -1), w.scale((d.radius + o.radius) * C), t.pkIndex === 2 || t.pkIndex === 3 ? C *= i.mpm : C < 1 && (C *= i.bpm), g.add(w), v.normalizeVector(g);
		let T = l.scaleVector(-o.radius - a.radius, v).add(o.position), E = m.subVectors(T, a.position).normalize();
		t.dx = E.x, t.dy = E.y, t.dz = E.z;
	}
	static _sigmoid01(e, t) {
		return 1 / (1 + Math.E ** +(-e / t));
	}
	static _checkSinglePK(r, i, a, o, p, m, h) {
		let g = e.EPSILON, _ = s, v = c, y = l, b = d, x = f, S = u, C = p.getBalls(), w = o.pockets, T = w[a];
		if (_.subVectors(T.position, i.position), _.y = 0, v.normalizeVector(_), v.dot(T.normal) > T.maxHalfOpen) return;
		let E = _.length();
		if (!n._isSegmentSafe(i.position, v, E, i.radius, C, r, i) || (y.scaleVector(-i.radius - r.radius, v).add(i.position), !m.pointProjectionOnTable(y.x, y.y, y.z))) return;
		S.subVectors(y, r.position);
		let D = S.length();
		S.scale(1 / D);
		let O = S.dot(v);
		if (O < -g || !n._isSegmentSafe(r.position, S, D - .002, r.radius + g, C, r, i)) return;
		let k = 0, ee = .97 - .31 * Math.min(1, D / 2);
		n._vRef(S, v, ee, b);
		for (let e = 0; e < w.length; e++) {
			let n = w[e].position;
			if (n.distanceToSq(y) < .34) {
				x.subVectors(n, y), x.y = 0;
				let i = x.dot(b), o = t.nIntersectSphereRay(n, r.radius + T.radius, y, b);
				if (i > 0 && o > 0) {
					k = a === e ? 1 : 2;
					break;
				}
			}
		}
		if (k === 2) return;
		let A = E / o.diagonal, j = D / o.diagonal, te = 0, ne = .2 * (j + A) * .5 + (1 - O) * A * .7;
		k === 1 && (te = -.99, ne = Math.max(ne, .7 * j));
		let re = (.5 * (1 - j) + .45 * (1 - A)) * O + .05 * i.number, M = h.next(S.x, S.y, S.z, te, ne, re);
		M.ballBIndex = i.index, M.pkIndex = a;
	}
	static _checkPassAbility(t, r, i, a, o, c, d, f, p, m) {
		let h = a.getBalls(), g = u.subVectors(r.position, t.position), _ = s.crossVectors(g, e.UNIT_Y).normalize(), v = l, y = (-r.radius - t.radius) * f, b = -y, x = .2 * (b - y);
		for (; y <= b;) {
			v.scaleVector(y, _).add(r.position), g.subVectors(v, t.position);
			let a = g.length();
			if (g.scale(1 / a), n._isSegmentSafe(t.position, g, a + d, t.radius + e.EPSILON, h, t, r)) return c.next(g.x, g.y, g.z, 0, .1 * Math.random() + a / i.diagonal * p, .1 * Math.random()), c.length >= m;
			y += x;
		}
		return !1;
	}
	static _vRef(e, t, n, r) {
		r.scaleVector(e.dot(t) * n, t), r.subVectors(e, r).normalize();
	}
	static _isSegmentSafe(e, n, r, i, a, ...o) {
		if (r < i) return !0;
		for (let s of a) if (s.active && o.indexOf(s) === -1 && t.nIntersectSphereADirLen(s.position, s.radius + i, e, n, r) !== 0) return !1;
		return !0;
	}
	static _logRoute(e) {
		console.log(`[Lucky Break AI] vertical spin: ${e.fbSpin}`), console.log(`[Lucky Break AI] route score: ${e.priority}`), console.log(`[Lucky Break AI] aim vector: ${e.dx}, ${e.dy}, ${e.dz}`);
	}
}, C = class t {
	get diagonal() {
		return this._diagonal;
	}
	position;
	size;
	_diagonal;
	pockets;
	constructor() {
		this.position = new e(), this.size = Object.create(null), this.size.w = 0, this.size.h = 0, this._diagonal = 0, this.pockets = [
			t.makePocket(),
			t.makePocket(),
			t.makePocket(),
			t.makePocket(),
			t.makePocket(),
			t.makePocket()
		];
	}
	reset(e, n, r, i, a, o) {
		this.position.set(e, n, r), this.size.w = i, this.size.h = a;
		let s = this.pockets, c = .5 * i - .05, l = .5 * a - .05, u = .5 * a - .05 * .4, d = -Math.cos(65 * Math.PI / 180);
		if (o) {
			for (let i = 0; i < s.length; i++) {
				let a = o[i];
				t.setPocket(s[i], e + a[0], n, r + a[1], a[2], 0, a[3], a[4], a[5]);
			}
			this._diagonal = Math.sqrt(i * i + a * a);
			return;
		}
		t.setPocket(s[0], e - c, n, r - l, 1, 0, 1, .05, 0), t.setPocket(s[1], e - c, n, r + l, 1, 0, -1, .05, 0), t.setPocket(s[2], e, n, r - u, 0, 0, 1, .05, d), t.setPocket(s[3], e, n, r + u, 0, 0, -1, .05, d), t.setPocket(s[4], e + c, n, r - l, -1, 0, 1, .05, 0), t.setPocket(s[5], e + c, n, r + l, -1, 0, -1, .05, 0), this._diagonal = Math.sqrt(i * i + a * a);
	}
	static makePocket() {
		return {
			position: new e(),
			normal: new e(),
			radius: 0,
			maxHalfOpen: 0
		};
	}
	static setPocket(e, t, n, r, i, a, o, s, c) {
		e.position.set(t, n, r), e.normal.set(i, a, o).normalize(), e.radius = s, e.maxHalfOpen = c;
	}
};
//#endregion
//#region src/core/EventEmitter.ts
function w(e, t, n) {
	if (typeof n != "function") throw TypeError("\"listener\" argument must be a function");
	let r = e._events, i;
	return r ? i = r[t] : (r = e._events = Object.create(null), e._eventsCount = 0), i ? typeof i == "function" ? r[t] = [i, n] : i.push(n) : (r[t] = n, e._eventsCount++), e;
}
function T(e, t) {
	for (let n = t, r = t + 1; r < e.length; n++, r++) e[n] = e[r];
	e.pop();
}
var E = [];
function D(e, t) {
	for (let n = 0; n < t; n++) E[n] = e[n];
	return E;
}
function O(e, t) {
	let n = e.length, r = D(e, n);
	for (let e = 0; e < n; e++) r[e](...t);
	r.length = 0;
}
var k = class {
	_events;
	_eventsCount;
	emit;
	on;
	constructor() {
		this._events = Object.create(null), this._eventsCount = 0, this.emit = this._emit, this.on = this._on;
	}
	_on(e, t) {
		return w(this, e, t);
	}
	_emit(e, ...t) {
		let n = this._events, r, i, a = e === "error";
		if (n) a &&= n.error == null;
		else if (!a) return !1;
		if (a) {
			if (t.length > 0 && (r = t[0]), r instanceof Error) throw r;
			let e = /* @__PURE__ */ Error(`An event error had no listener (${r}).`);
			throw e.message = r, e;
		}
		return i = n[e], i ? (typeof i == "function" ? i(...t) : O(i, t), !0) : !1;
	}
	removeAllListeners(e) {
		let t = this._events;
		return t && (e === void 0 ? (this._events = Object.create(null), this._eventsCount = 0) : t[e] && (--this._eventsCount === 0 ? this._events = Object.create(null) : delete t[e])), this;
	}
	removeListener(e, t) {
		if (typeof t != "function") throw TypeError("\"listener\" argument must be a function");
		let n = this._events;
		if (!n) return this;
		let r = n[e];
		if (!r) return this;
		if (r === t || typeof r == "function" && r.listener === t) --this._eventsCount === 0 ? this._events = Object.create(null) : delete n[e];
		else if (typeof r != "function") {
			let i = -1;
			for (let e = r.length - 1; e >= 0; e--) if (r[e] === t || r[e].listener === t) {
				i = e;
				break;
			}
			if (i < 0) return this;
			i === 0 ? r.shift() : T(r, i), r.length === 1 && (n[e] = r[0]);
		}
		return this;
	}
}, ee = { default: {
	sceneId: "shenmueNine",
	ballSet: [
		0,
		-1.11,
		0,
		1,
		.756,
		0,
		2,
		.808481,
		-.0303,
		3,
		.808481,
		.0303,
		4,
		.860962,
		-.0606,
		9,
		.860962,
		0,
		5,
		.860962,
		.0606,
		6,
		.913443,
		-.0303,
		7,
		.913443,
		.0303,
		8,
		.965924,
		0
	],
	ballRadius: .03,
	ballMass: 1.5,
	refId: "std-nine"
} }, A = {
	makeUserInfo(e, t, n, r) {
		let i = Object.create(null);
		return i.userId = e, i.displayName = t, i.level = n, i.stickName = r, i;
	},
	makeGContext() {
		let e = Object.create(null);
		return e.nRounds = 0, e.inHand = 0, e.playerIndex = -1, e.ballOn = 0, e.winnerIndex = -1, e;
	},
	makeSimulatorResult() {
		let e = Object.create(null);
		return e.nKissed = 0, e.firstKissIndex = 0, e.pottedIndices = [], e.outOfBoundsIndices = [], e.railAfterFirstContact = !1, e.objectRailContactIndices = [], e;
	},
	makeRefResult() {
		let e = Object.create(null);
		return e.score = 0, e.foulCode = 0, e;
	}
}, j = Object.create(null);
j.MISS_TARGET = 1, j.ILLEGAL_FIRST_HIT = 2, j.ILLEGAL_POTTING = 4, j.POTTING_CUE_BALL = 8, j.OFF_TABLE = 16, j.NO_RAIL_AFTER_CONTACT = 32, j.ILLEGAL_BREAK = 64;
var te = [
	"",
	"NO OBJECT BALL CONTACT",
	"WRONG BALL CONTACTED FIRST",
	"BALL POCKETED OUT OF ORDER",
	"CUE BALL SCRATCH",
	"BALL LEFT THE TABLE",
	"NO BALL REACHED A RAIL AFTER CONTACT",
	"BREAK DID NOT POCKET A BALL OR SEND FOUR BALLS TO RAILS"
];
function ne(e) {
	let t = "", n = 1, r = 1, i = !1;
	for (; n <= e;) n & e && (t += i ? ", " + te[r] : te[r], i = !0), n <<= 1, r++;
	return i ? t + "." : t;
}
//#endregion
//#region src/physics/geometry/PlanarRegionBase.ts
var re = e.EPSILON, M = class {
	static TmpV = new e(0, 0, 0);
	get geoCenter() {
		return null;
	}
	normal;
	d;
	constructor() {
		this.normal = new e(0, 0, 0), this.d = 0;
	}
	isZeroNormal() {
		let e = this.normal;
		return !(Math.abs(e.x) > re || Math.abs(e.y) > re || Math.abs(e.z) > re);
	}
	setWithPointNormal(e, t) {
		return this.normal.copy(t), this.d = -t.x * e.x - t.y * e.y - t.z * e.z, this;
	}
	setWithPointAnd2Dirs(e, t, n) {
		let r = this.normal;
		return r.crossVectors(t, n).normalize(), this.d = -r.x * e.x - r.y * e.y - r.z * e.z, this;
	}
	setWithPoint(e, t, n) {
		let r = t.x - e.x, i = t.y - e.y, a = t.z - e.z, o = n.x - e.x, s = n.y - e.y, c = n.z - e.z, l = i * c - a * s, u = a * o - r * c, d = r * s - i * o, f = Math.sqrt(l * l + u * u + d * d), p = f === 0 ? 0 : 1 / f, m = this.normal;
		return m.x = l * p, m.y = u * p, m.z = d * p, this.d = -(m.x * e.x + m.y * e.y + m.z * e.z), this;
	}
	signedDistance(e) {
		let t = this.normal;
		return t.x * e.x + t.y * e.y + t.z * e.z + this.d;
	}
	intersectionWithRay(e, t, n, r = 9999) {
		let i = this.signedDistance(e) / -this.normal.dot(t);
		return i < -re || i > r ? !1 : (i < 0 && (i = 0), n.copy(e).addScaled(t, i), !0);
	}
	projectionInside(...e) {
		return !0;
	}
}, ie = class extends M {
	get geoCenter() {
		if (!this._geoCenter) {
			let t = this._ps.length;
			if (t === 0) return null;
			let n = new e();
			for (let e = 0; e !== t; ++e) n.add(this._ps[e]);
			this._geoCenter = n.scale(1 / t);
		}
		return this._geoCenter;
	}
	_ps;
	_edgeXNormals;
	_geoCenter;
	constructor() {
		super(), this._ps = [], this._edgeXNormals = [], this._geoCenter = null;
	}
	resetWithAtomPolygon(e) {
		let t = e.edges;
		for (let e = 0; e !== t.length; ++e) {
			let n = this._ps[e];
			n ? n.copy(t[e].va) : this._ps[e] = t[e].va.clone();
		}
		if (this._ps.length = t.length, this._ps.length < 3) throw Error(`A planar polygon requires at least three points; received ${this._ps.length}.`);
		this.setWithPointNormal(this._ps[0], e.normal);
		for (let t = 0; t !== e.edgeXNormals.length; ++t) this._edgeXNormals[t] ? this._edgeXNormals[t].copy(e.edgeXNormals[t]) : this._edgeXNormals[t] = e.edgeXNormals[t].clone();
		this._edgeXNormals.length = e.edgeXNormals.length, this._geoCenter = null;
	}
	projectionInside(e, t, n) {
		let r = this._ps, i = this._edgeXNormals, a, o = null, s = M.TmpV;
		for (let c = 0; c !== r.length; ++c) {
			if (s.set(e, t, n).sub(r[c]), a = i[c].dot(s), !(o === null || a > 0 && o === !0 || a <= 0 && o === !1)) return !1;
			o === null && (o = a > 0);
		}
		return !0;
	}
}, ae = 65535, oe = class extends k {
	get validRegionGeoCenter() {
		return this._playArea.geoCenter;
	}
	get inHandPlacementRegion() {
		return null;
	}
	get sysReservedBallOn() {
		return ae;
	}
	_sceneId;
	_playArea;
	constructor() {
		super(), this._sceneId = "", this._playArea = new ie();
	}
	syncAreaWithSimulator(e) {
		this._sceneId !== e.sceneId && (this._sceneId = e.sceneId, this._playArea.resetWithAtomPolygon(e.ground));
	}
	intersectionRayValidRegionPlane(e, t, n) {
		return this._playArea.intersectionWithRay(e, t, n, 10);
	}
	projectionInSideValidRegion(e, t, n) {
		return this.projectionOnTable(e, t, n);
	}
	projectionOnTable(e, t, n) {
		return this._playArea.projectionInside(e, t, n);
	}
	resetGContext(e) {
		throw e.inHand = 2, e.ballOn = 0, e.winnerIndex = -1, Error("The selected ruleset cannot begin a round.");
	}
	checkResult(e, t, n) {
		throw Error(`The selected ruleset cannot score this shot: ${e}, ${t}, ${n}`);
	}
}, se = (e) => 2 ** e, ce = -.75, le = {
	axis: "x",
	coordinate: ce,
	side: -1
}, ue = class extends oe {
	_openingBreak = !1;
	get inHandPlacementRegion() {
		return this._openingBreak ? le : null;
	}
	resetGContext(e) {
		this._openingBreak = !0, e.inHand = 2, e.ballOn = se(1), e.winnerIndex = -1;
	}
	projectionInSideValidRegion(e, t, n) {
		return super.projectionInSideValidRegion(e, t, n) ? !this._openingBreak || e <= ce : !1;
	}
	checkResult(e, t, n) {
		let r = this._openingBreak;
		this._openingBreak = !1;
		let i = t.result;
		if (n.score = 0, n.foulCode = 0, e.ballOn === this.sysReservedBallOn) {
			this._restoreCueBall(i, t), e.inHand = 1, e.ballOn = this._lowestActiveBallMask(t);
			return;
		}
		let a = Math.log2(e.ballOn), o = i.nKissed > 0 ? t.getBallAtIndex(i.firstKissIndex).number : 0;
		o === 0 ? n.foulCode |= j.MISS_TARGET : o !== a && (n.foulCode |= j.ILLEGAL_FIRST_HIT);
		let s = !1, c = -1, l = 0;
		for (let e of i.pottedIndices) {
			let r = t.getBallAtIndex(e).number;
			r === 0 ? (s = !0, n.foulCode |= j.POTTING_CUE_BALL) : (l++, r === 9 && (c = e));
		}
		for (let e of i.outOfBoundsIndices) {
			let r = t.getBallAtIndex(e).number;
			n.foulCode |= j.OFF_TABLE, r === 0 && (s = !0), r === 9 && (c = e);
		}
		if (o === a && l === 0 && (r && i.objectRailContactIndices.length < 4 ? n.foulCode |= j.ILLEGAL_BREAK : !r && !i.railAfterFirstContact && (n.foulCode |= j.NO_RAIL_AFTER_CONTACT)), n.foulCode !== 0) {
			n.score = 0, e.inHand = 2, s && t.respotIndexDefault(0), c !== -1 && t.respotIndexDefault(c), e.ballOn = this._lowestActiveBallMask(t);
			return;
		}
		if (e.inHand = 0, c !== -1) {
			n.score = Math.max(1, l), e.winnerIndex = e.playerIndex, e.ballOn = 0;
			return;
		}
		n.score = l, e.ballOn = this._lowestActiveBallMask(t);
	}
	_restoreCueBall(e, t) {
		for (let n of [...e.pottedIndices, ...e.outOfBoundsIndices]) if (t.getBallAtIndex(n).number === 0) {
			t.respotIndexDefault(0);
			return;
		}
	}
	_lowestActiveBallMask(e) {
		let t = Infinity;
		for (let n of e.getBalls()) n.active && n.number > 0 && n.number < t && (t = n.number);
		return Number.isFinite(t) ? se(t) : 0;
	}
}, de = class {
	ground;
	sidesoft;
	sidehard;
	pocket;
	tunnel;
	end;
	uid;
	normal;
	edges;
	edgeXNormals;
	centerPosition;
	a;
	b;
	c;
	d;
	bCenter;
	bR;
	bRSq;
	restitution;
	friction;
	collisionGroup;
	uv;
	_size;
	get label() {
		return this.uid + ": ground:" + !!this.ground + ", sidesoft:" + !!this.sidesoft + ", sidehard:" + !!this.sidehard + ", tunnel:" + !!this.tunnel + ", pocket:" + !!this.pocket;
	}
	get size() {
		if (!this._size) {
			let t = Number.MAX_VALUE, n = 0, r = Number.MAX_VALUE, i = 0, a = Number.MAX_VALUE, o = 0;
			for (let e of this.edges) {
				let s = e.va;
				t > s.x && (t = s.x), n < s.x && (n = s.x), r > s.y && (r = s.y), i < s.y && (i = s.y), a > s.z && (a = s.z), o < s.z && (o = s.z);
			}
			this._size = new e(n - t, i - r, o - a);
		}
		return this._size;
	}
	constructor(t, n) {
		this.ground = !1, this.sidesoft = !1, this.sidehard = !1, this.pocket = !1, this.tunnel = !1, this.end = !1, this.uid = -1, this.normal = t, this.edges = n, this.edgeXNormals = [];
		let r = 0, i = 0, a = 0;
		for (let o = 0; o !== n.length; ++o) this.edgeXNormals[o] = new e().crossVectors(n[o].vab, t), r += n[o].va.x, i += n[o].va.y, a += n[o].va.z;
		this.centerPosition = new e(r / n.length, i / n.length, a / n.length), this.a = t.x, this.b = t.y, this.c = t.z, this.d = -t.dot(n[0].va), this.bCenter = null, this.bR = 0, this.bRSq = 0, this.restitution = 0, this.friction = 0, this.collisionGroup = 1, this.uv = null, this._size = null;
	}
	toString() {
		return this.a + "x + " + this.b + "y + " + this.c + "z + " + this.d + " = 0,restitution:" + this.restitution + ",bCenter: " + this.bCenter + ",bR:" + this.bR;
	}
	toStringShort() {
		let e = "uid: " + this.uid;
		return this.ground && (e = e.concat(", ground")), this.sidesoft && (e = e.concat(", sidesoft")), this.sidehard && (e = e.concat(", sidehard")), this.pocket && (e = e.concat(", pocket")), this.tunnel && (e = e.concat(", tunnel")), this.end && (e = e.concat(", end")), e.concat(", restitution: " + this.restitution + ", friction: " + this.friction + ", cg: " + this.collisionGroup);
	}
	setBoundingSphere(e, t) {
		this.bCenter = e, this.bR = t, this.bRSq = t * t;
	}
	distanceFromPointToPlane(e) {
		return this.a * e.x + this.b * e.y + this.c * e.z + this.d;
	}
	dispose() {
		this.normal = null, this.edges = null, this.edgeXNormals = null, this.bCenter = null, this.bR = 0;
	}
}, fe = class t {
	va;
	vb;
	vab;
	abDotAb;
	sharedData;
	constructor(t, n, r) {
		this.va = t, this.vb = n, this.vab = new e(0, 0, 0), this.vab.subVectors(n, t), this.abDotAb = this.vab.dot(this.vab), this.sharedData = r || { count: 0 }, this.sharedData.count++;
	}
	cloneReversed() {
		return new t(this.vb, this.va, this.sharedData);
	}
};
for (let e of Object.getOwnPropertyNames(fe.prototype)) e !== "constructor" && Object.defineProperty(fe.prototype, e, { enumerable: !0 });
//#endregion
//#region src/physics/config/PhysicsConfiguration.ts
var N = {
	gravity: new e(0, -19, 0),
	tPrecision: 3e-4,
	islandUpdMinDisSq: .1,
	airAngularDamping: .99,
	frictionS: .01,
	frictionP: .15,
	restitution: {
		ball: .985,
		ground: .3,
		sidehard: .92,
		sidesoft: .45,
		tunnel: 0,
		pocket: .002,
		default: .5
	},
	__gravityDir: null,
	getGravityDir() {
		return this.__gravityDir ||= new e(0, 0, 0).normalizeVector(this.gravity), this.__gravityDir;
	},
	setBallFrictionAndRestitution(e) {
		e.restitution = this.restitution.ball, e.friction = this.frictionS;
	},
	setPolyFrictionAndRestitution(e) {
		e.friction = this.frictionP;
		let t = this.restitution;
		for (let n in t) if (e[n]) {
			e.restitution = t[n];
			return;
		}
		e.restitution = t.default;
	}
}, pe = class {
	name;
	polys;
	constructor(e, t) {
		this.name = e, this.polys = t;
	}
	getPolygonByID(e) {
		for (let t of this.polys) if (t.uid === e) return t;
		return null;
	}
	setCollisionGroup(e) {
		for (let t of this.polys) t.collisionGroup = e;
	}
	setPolyFrictionAndRestitution() {
		for (let e of this.polys) N.setPolyFrictionAndRestitution(e);
	}
	setCustomRelativeVelHandler(e) {
		for (let t of this.polys) t.setCustomRelativeVelHandler?.(e);
	}
}, me = {
	ground: 0,
	side: 1,
	tunnel: 2
}, he = {
	ground: 2,
	side: 4,
	tunnel: 8
}, ge = class {
	get ground() {
		return this._groundPolygon;
	}
	groups;
	id = "";
	_groundPolygon;
	lowestPosition;
	nPolygons = 0;
	nEdges = 0;
	constructor(t) {
		this.groups = [], this._groundPolygon = null, this.lowestPosition = new e(0, Number.MAX_VALUE, 0), this.initData(t);
	}
	getGroupByName(e) {
		for (let t of this.groups) if (t.name === e) return t;
		return null;
	}
	getPolygonByID(e) {
		for (let t of this.groups) {
			let n = t.getPolygonByID(e);
			if (n) return n;
		}
		return null;
	}
	slice(e) {
		let t = [];
		for (let n of this.groups) n.name === e && t.push(n);
		let n = Object.create(null);
		return n.groups = t, n;
	}
	initData(e) {
		this.nPolygons = 0, this.nEdges = 0;
		for (let t in e) {
			let n = new pe(t, this.dataToPolys(e[t]));
			n.setCollisionGroup(he[t] || 1), n.setPolyFrictionAndRestitution(), this.groups.push(n);
		}
		this.groups.sort((e, t) => me[e.name] - me[t.name]);
	}
	dataToPolys(t) {
		let n = [];
		for (let r = 0; r !== t.p.length / 3; ++r) n.push(new e(t.p[3 * r], t.p[3 * r + 1], t.p[3 * r + 2]));
		let r = [], i = {};
		for (let a of t.q) {
			let t = a.i;
			if (t.length < 3) throw Error(`Collision polygon requires at least three indices; received ${t.length}.`);
			let o = [];
			for (let e = 0; e !== t.length; ++e) {
				let r = t[e], a = t[(e + 1) % t.length], s = r + "-" + a, c = a + "-" + r;
				i[s] ? o.push(i[s]) : i[c] ? o.push(i[c].cloneReversed()) : (i[s] = new fe(n[r], n[a]), this.nEdges++, o.push(i[s]));
			}
			let s = new de(new e(...a.n), o);
			if (a.uv && (s.uv = a.uv), s.uid = this.nPolygons, this.nPolygons = s.uid + 1, a.s && s.setBoundingSphere(new e(a.s[0], a.s[1], a.s[2]), a.s[3]), a.f) for (let e of a.f) s[e] = !0;
			s.ground && (this._groundPolygon = s), s.centerPosition.y < this.lowestPosition.y && this.lowestPosition.copy(s.centerPosition), r.push(s);
		}
		return n.length = 0, r;
	}
	log() {
		let e = "";
		for (let t of this.groups) {
			e = e.concat(t.name + "\n");
			for (let n = 0; n !== t.polys.length; ++n) e = e.concat("	" + n + ": " + t.polys[n].toStringShort() + "\n");
		}
		console.log(`[Lucky Break physics] Collision mesh layout\n${e}`);
	}
}, _e = e.EPSILON, ve = class {
	array2D;
	maxRow;
	maxLine;
	constructor(e) {
		let t = e.width, n = e.height, r = [];
		for (let i = n - 1; i >= 0; --i) {
			let n = i * t, a = new Float32Array(3 * t);
			for (let r = 0; r < t; ++r) {
				let t = 4 * (n + r), i = e.data[t], o = e.data[t + 1], s = e.data[t + 2];
				a[3 * r] = 2 * (i / 255 - .5), a[3 * r + 1] = 2 * (s / 255 - .5), a[3 * r + 2] = -2 * (o / 255 - .5);
			}
			r.push(a);
		}
		this.array2D = r, this.maxRow = t - 1, this.maxLine = n - 1;
	}
	getNormalByUV(e, t, n) {
		let r = Math.floor(t * this.maxLine), i = 3 * Math.floor(e * this.maxRow), a = this.array2D[r];
		n.set(a[i], a[i + 1], a[i + 2]);
	}
};
function ye(e) {
	if (e.edges.length !== 4) throw Error(`Normal-mapped polygon requires four edges; received ${e.edges.length}.`);
	if (!e.uv) throw Error(`Normal-mapped polygon ${e.uid} has no UV coordinates.`);
	if (e.uv.length !== 8) throw Error(`Normal-mapped polygon requires eight UV values; received ${e.uv.length}.`);
}
function be(t) {
	let n = null, r = null, i = 0;
	for (let e = 0; e !== t.edges.length; ++e) {
		let a = t.edges[e];
		if (Math.abs(a.vab.y) <= _e && t.edgeXNormals[e].y > _e) {
			i = e, n = a, r = e === t.edges.length - 1 ? t.edges[0] : t.edges[e + 1];
			break;
		}
	}
	if (!n) throw Error(`Could not find the right edge of polygon ${t.uid}.`);
	let a = t, o = t.uv, s = r;
	a.lonLatOrigin = n.va, a.lonDir = new e().normalizeVector(n.vab), a.lon = n.va.distanceTo(n.vb), a.lat = s.va.distanceTo(s.vb), a.u0 = o[2 * i], a.v0 = o[2 * i + 1], i = i === 3 ? 0 : i + 1, a.uChange = o[2 * i] - a.u0, i = i === 3 ? 0 : i + 1, a.vChange = o[2 * i + 1] - a.v0;
}
var xe = new e();
function Se(e, t) {
	let n = this.lonLatOrigin;
	xe.subVectors(e, n);
	let r = xe.dot(this.lonDir), i = this.u0 + r / this.lon * this.uChange, a = this.v0 + (e.y - n.y) / this.lat * this.vChange;
	i > 1 ? i = 1 : i < 0 && (i = 0), a > 1 ? a = 1 : a < 0 && (a = 0), this.nTable.getNormalByUV(i, a, t);
}
var Ce = {
	createNTableWithImgData(e) {
		return new ve(e);
	},
	extendPolyGroup(e, t) {
		for (let n of e.polys) {
			ye(n), be(n);
			let e = n;
			e.nTable = t, e.hasCustomNormalHandler = !0, e.customNormalHandler = Se.bind(e);
		}
	}
}, we = class {
	get avg() {
		return this.counter ? this.sum / (this.counter > this.length ? this.length : this.counter) : 0;
	}
	a;
	counter;
	length;
	sum;
	current;
	peak;
	constructor(e) {
		this.a = new Float32Array(e), this.counter = 0, this.length = e, this.sum = 0, this.current = 0, this.peak = 0;
	}
	push(e) {
		this.sum += e;
		let t = this.counter++ % this.length, n = this.a[t];
		this.sum -= n, this.a[t] = e, this.current = e, n >= this.peak - 1e-5 && (this.peak = this.updatePeak()), e > this.peak && (this.peak = e);
	}
	updatePeak() {
		let e = -Infinity;
		for (let t = 0; t !== this.a.length; ++t) this.a[t] > e && (e = this.a[t]);
		return e;
	}
}, Te = class {
	recorder;
	precision;
	name;
	color;
	upperBound;
	width;
	height;
	fpu;
	frame;
	container;
	viewWidth;
	viewHeight;
	ctx;
	valueLabel;
	peakLabel;
	avgLabel;
	constructor(e, t, n, r = 320, i = 1) {
		this.recorder = new we(r), this.precision = i, this.name = e, this.color = t, this.upperBound = n, this.width = 245, this.height = 36, this.fpu = 60, this.frame = Math.round(Math.random() * this.fpu), this.initView();
	}
	initView() {
		this.container = document.createElement("div"), Object.assign(this.container.style, {
			width: this.width + "px",
			height: this.height + "px",
			backgroundColor: "#1a1a1a",
			opacity: "0.9",
			display: "block",
			position: "absolute",
			borderTop: "1px solid #2c2c2c",
			borderRight: "1px solid #2c2c2c",
			borderBottom: "1px solid #2c2c2c",
			boxSizing: "border-box"
		});
		let e = document.createElement("div");
		Object.assign(e.style, {
			display: "block",
			position: "absolute",
			width: "2px",
			height: this.height + "px",
			top: "-1px",
			left: "-1px",
			backgroundColor: this.color
		}), this.container.appendChild(e);
		let t = document.createElement("div");
		t.innerHTML = this.name, Object.assign(t.style, {
			display: "block",
			position: "absolute",
			color: this.color,
			top: "14px",
			left: "8px",
			fontSize: "10px"
		}), this.container.appendChild(t);
		let n = document.createElement("canvas");
		n.width = 320, n.height = 60, Object.assign(n.style, {
			display: "block",
			position: "absolute",
			width: "160px",
			height: "30px",
			top: "2px",
			left: "81px",
			backgroundColor: "#303030"
		}), this.container.appendChild(n);
		let r = document.createElement("div");
		Object.assign(r.style, {
			display: "block",
			position: "absolute",
			color: this.color,
			fontSize: "12px",
			left: "88px",
			top: "12px"
		}), this.container.appendChild(r);
		let i = document.createElement("div");
		Object.assign(i.style, {
			display: "block",
			position: "absolute",
			color: "#d1cbc5",
			fontSize: "9px",
			right: "4px",
			top: "4px"
		}), this.container.appendChild(i);
		let a = document.createElement("div");
		Object.assign(a.style, {
			display: "block",
			position: "absolute",
			color: "#d1cbc5",
			fontSize: "9px",
			right: "4px",
			bottom: "4px"
		}), this.container.appendChild(a), this.viewWidth = n.width, this.viewHeight = n.height;
		let o = n.getContext("2d");
		this.ctx = o, o.strokeStyle = this.color, o.lineWidth = 1, this.valueLabel = r, this.peakLabel = i, this.avgLabel = a;
	}
	push(e) {
		this.recorder.push(e);
	}
	update() {
		let e = this.recorder, t = this.ctx, n = this.viewWidth, r = this.viewHeight, i = this.upperBound, a = this.valueLabel, o = this.peakLabel, s = this.avgLabel;
		if (a.innerHTML = e.current.toFixed(this.precision), o.innerHTML = "P " + e.peak.toFixed(this.precision), s.innerHTML = "A " + e.avg.toFixed(this.precision), e.counter > 1 && ++this.frame >= this.fpu) {
			this.frame = 0, t.clearRect(0, 0, n, r), t.beginPath();
			let a = Math.min(e.counter, e.length), o = n / (e.length - 1), s = e.counter - 1, c = n, l = (1 - e.a[s % e.length] / i) * r;
			l < 0 && (l = 0), t.moveTo(c, l);
			for (let n = 1; n !== a; ++n) c -= o, l = (1 - e.a[--s % e.length] / i) * r, l < 0 && (l = 0), t.lineTo(c, l);
			t.stroke();
		}
	}
	setPosition(e, t) {
		this.container.style.left = t + "px", this.container.style.top = e + "px";
	}
}, Ee = 600, De = (e) => e.toUpperCase(), Oe = class {
	startTime;
	__viewInited;
	monitors;
	height = 0;
	container;
	constructor() {
		this.startTime = 0, this.__viewInited = !1, this.monitors = Object.create(null);
	}
	initView(e) {
		this.__viewInited = !0, this.height = 0, this.container = document.createElement("div"), this.container.id = "dev-tool";
		for (let t of e.data) t.visible && this.appendMonitor(t.name, t.color, t.ceiling, Ee, t.digits);
		Object.assign(this.container.style, {
			display: "block",
			position: "absolute",
			top: "1px",
			right: "1px",
			width: "245px",
			webkitUserSelect: "none",
			pointerEvents: "none"
		}), document.body.appendChild(this.container);
	}
	appendMonitor(e, t, n, r, i) {
		let a = new Te(e.replace(/^(\w)/, De), t, n, r, i), o = this.height;
		a.setPosition(o, 0), this.container.appendChild(a.container), this.monitors[e] = a, this.height = o + a.height - 1;
	}
	update(e) {
		this.__viewInited || this.initView(e);
		for (let t of e.data) {
			let e = this.monitors[t.name];
			e && (e.push(t.value), e.update());
		}
	}
}, ke = "#62C6E3", Ae = "#A64DD9", je = "#7FCC5B", P = "#D94A6C", Me = [
	{
		name: "step",
		color: ke,
		ceiling: 18,
		digits: 3,
		visible: !0,
		value: 0
	},
	{
		name: "nSteps",
		color: ke,
		ceiling: 10,
		digits: 0,
		visible: !0,
		value: 0
	},
	{
		name: "internalStep",
		color: ke,
		ceiling: 10,
		digits: 0,
		visible: !0,
		value: 0
	},
	{
		name: "iteration",
		color: ke,
		ceiling: 10,
		digits: 0,
		visible: !0,
		value: 0
	},
	{
		name: "pending_step",
		color: Ae,
		ceiling: 5,
		digits: 3,
		visible: 1,
		value: 0
	},
	{
		name: "island_update",
		color: Ae,
		ceiling: 5,
		digits: 3,
		visible: 1,
		value: 0
	},
	{
		name: "nIslands",
		color: Ae,
		ceiling: 22,
		digits: 0,
		visible: !0,
		value: 0
	},
	{
		name: "nPendings",
		color: Ae,
		ceiling: 22,
		digits: 0,
		visible: !0,
		value: 0
	},
	{
		name: "nAwakened",
		color: Ae,
		ceiling: 22,
		digits: 0,
		visible: !0,
		value: 0
	},
	{
		name: "solve",
		color: je,
		ceiling: 5,
		digits: 3,
		visible: 1,
		value: 0
	},
	{
		name: "nSolvedCts",
		color: je,
		ceiling: 100,
		digits: 0,
		visible: 1,
		value: 0
	},
	{
		name: "dSPB",
		color: P,
		ceiling: 5,
		digits: 3,
		visible: 1,
		value: 0
	},
	{
		name: "ccdSS",
		color: P,
		ceiling: 5,
		digits: 3,
		visible: 1,
		value: 0
	},
	{
		name: "nCcdSS",
		color: P,
		ceiling: 200,
		digits: 0,
		visible: 1,
		value: 0
	},
	{
		name: "ccdSP_Far",
		color: P,
		ceiling: 5,
		digits: 3,
		visible: 1,
		value: 0
	},
	{
		name: "nCcdSP_Far",
		color: P,
		ceiling: 200,
		digits: 0,
		visible: 1,
		value: 0
	},
	{
		name: "ccdSP_Near",
		color: P,
		ceiling: 5,
		digits: 3,
		visible: 1,
		value: 0
	},
	{
		name: "nCcdSP_Near",
		color: P,
		ceiling: 200,
		digits: 0,
		visible: 1,
		value: 0
	}
], F = new class {
	data;
	metricIndices;
	_viewer;
	constructor() {
		this.data = Me, this.metricIndices = Object.create(null);
		for (let e = 0; e !== this.data.length; ++e) this.metricIndices[this.data[e].name] = e;
		this._viewer = null;
	}
	createViewer() {
		this._viewer ||= new Oe();
	}
	clear() {
		for (let e of this.data) e.value = 0;
	}
	startTick(e) {
		let t = this.metricIndices[e], n = this.data[t];
		n.value = performance.now() - n.value;
	}
	stopTick(e) {
		let t = this.metricIndices[e], n = this.data[t];
		n.value = performance.now() - n.value;
	}
	count(e, t) {
		let n = this.metricIndices[e], r = this.data[n];
		r.value += t;
	}
	end() {
		this._viewer && this._viewer.update(this);
	}
}(), Ne = e.EPSILON, I = new e(), Pe = new e(), L = new e(), Fe = new e(), Ie = new e(), Le = class e {
	static sharedInstance = new e();
	maxIter;
	constructor() {
		this.maxIter = 4;
	}
	solveContact(e) {
		let t = e.transformLocVel2Imp, n = e.spaceTransformL2W, r = -1 - e.restitution;
		n.transformTranspose(e.getRelativeVelocity(), I);
		let i = I.x >= e.bounceThreshold ? -I.x : r * I.x;
		Pe.set(i, -I.y, -I.z), t.transform(Pe, L);
		let a = Math.sqrt(L.y * L.y + L.z * L.z), o = L.x * e.friction;
		if (a > o) {
			let e = o / a;
			L.y *= e, L.z *= e;
		}
		o = L.x * e.rollingFriction, n.transform(L, Fe), e.bi.applyImpulseAtPoint(Fe, e.armI, o / e.armLenI), e.isSS && (Fe.scale(-1), e.bj.applyImpulseAtPoint(Fe, e.armJ, o / e.armLenJ));
	}
	solveList(e, t) {
		F.startTick("solve");
		let n = e.entry;
		if (t) for (; n;) this.solveIsland(n), n = n.next;
		else for (; n;) n.dirty && this.solveIsland(n), n = n.next;
		F.stopTick("solve");
	}
	solveIsland(e) {
		e.dirty = !1;
		for (let t = 0; t !== this.maxIter && !this._solveMostUrgentChildren(e); ++t);
		this._sloveChildrenPene(e);
	}
	_solveMostUrgentChildren(e) {
		if (e.totalItems === 1) {
			let t = e.itemEntry;
			return t.getCloseSpeed() < -Ne && (this.solveContact(t), F.count("nSolvedCts", 1)), !0;
		}
		for (let t = 0; t !== e.totalItems; ++t) {
			let t = e.itemEntry, n = 0, r = null;
			for (; t;) {
				let e = t.getCloseSpeed();
				e < n && (n = e, r = t), t = t.next;
			}
			if (!(r && n < -Ne)) return !0;
			this.solveContact(r), F.count("nSolvedCts", 1);
		}
		return !1;
	}
	_sloveChildrenPene(e) {
		let t = e.itemEntry;
		for (; t;) {
			if (t.penetration < -Ne) {
				let e = t.penetration;
				Ie.scaleVector(-.5 * e, t.normal), t.bi.addPeneOffset(e, Ie), t.isSS && t.bj.addPeneOffset(e, Ie.scale(-1));
			}
			t = t.next;
		}
	}
}, Re = e.EPSILON, ze = class e extends Le {
	static sharedInstance = new e();
	callback;
	interrupt;
	constructor() {
		super(), this.callback = null, this.interrupt = !1;
	}
	reset(e) {
		this.callback = e;
	}
	solveList(e, t) {
		if (this.interrupt) return;
		let n = e.entry;
		if (t) for (; n;) {
			if (this.solveIsland(n), this.interrupt) return;
			n = n.next;
		}
		else for (; n;) {
			if (n.dirty && (this.solveIsland(n), this.interrupt)) return;
			n = n.next;
		}
	}
	solveIsland(e) {
		e.dirty = !1;
		for (let t = 0; t !== this.maxIter && !this._solveMostUrgentChildren(e); ++t);
		this._sloveChildrenPene(e);
	}
	_solveMostUrgentChildren(e) {
		if (e.totalItems === 1) {
			let t = e.itemEntry;
			return t.getCloseSpeed() < -Re && (this.solveContact(t), this.callback(t)) && (this.interrupt = !0), !0;
		}
		for (let t = 0; t !== e.totalItems; ++t) {
			let t = e.itemEntry, n = 0, r = null;
			for (; t;) {
				let e = t.getCloseSpeed();
				e < n && (n = e, r = t), t = t.next;
			}
			if (!(r && n < -Re)) return !0;
			if (this.solveContact(r), this.callback(r)) return this.interrupt = !0, !0;
		}
		return !1;
	}
}, Be = N.tPrecision, R = e.EPSILON, Ve = new e(), z = new e(), He = new e(), B = new e(), Ue = new e(), V = new e(), We = new e(), H = new e(), Ge = new e(), Ke = new e(), U = [], W = {
	initIslands(e, t, n, r, i) {
		let a = t.groups;
		for (let t = 0; t !== e.length; ++t) {
			let o = e[t];
			if (!o.active) continue;
			let s = r.acquire();
			for (let i = t + 1; i < e.length; ++i) {
				let t = e[i];
				t.active && (s.resetWithBiBj(o, t), this.dcdSS(s) && (n.add(s), s.startResting(), s.transformLocVel2Imp, s = r.acquire()));
			}
			s.free(), s = i.acquire();
			for (let e of a) for (let t of e.polys) s.resetWithBiBj(o, t), this.dcdSP(s) && (n.add(s), s.startResting(), s.transformLocVel2Imp, s = i.acquire());
			s.free();
		}
	},
	updateIslands(e, t) {
		F.startTick("island_update");
		let n = e.entry;
		for (; n;) {
			let r = n.next;
			(t || n.needsUpdate) && this.updateIsland(n, e), n = r;
		}
		F.stopTick("island_update");
	},
	updateIsland(e, t) {
		let n = e.itemEntry;
		for (e.needsUpdate = !1; n;) n.markedAsKilled ? U.push(n) : n.needsUpdateResting() && ((n.isSS ? this.dcdSS(n) : this.dcdSP(n)) || (n.bi.predictionDirty = !0, n.isSS && (n.bj.predictionDirty = !0), U.push(n))), n = n.next;
		for (let e of U) e.stopResting(), t.remove(e, !0);
		U.length = 0;
	},
	updateSSToi(e, t, n, r, i, a, o) {
		let s = n.acquire();
		for (let c of t) !c.active || c === e || e.collisionGroup & c.collisionMask || c.collisionGroup & e.collisionMask || i.indexOf(c.uid) !== -1 || r.isResting(e.uid, c.uid) || this.ccdSS(e, c, a, s) && (o.add(s), s = n.acquire());
		s.free();
	},
	updateSPToi(e, t, n, r, i) {
		let a = Number.MAX_VALUE;
		for (let i of t.groups) {
			let t = this.dSPB(e, i, n, r, a, U);
			t < a && (a = t);
		}
		if (U.length !== 0) {
			if (a !== Number.MAX_VALUE) {
				let e = a + Be;
				for (let t of U) t.toi <= e ? i.add(t) : t.free();
			} else for (let e of U) e.free();
			U.length = 0;
		}
	},
	dSPB(e, t, n, r, i, a) {
		F.startTick("dSPB");
		let o = n.acquire(), s = i + Be;
		for (let c of t.polys) !r.isResting(e.uid, c.uid) && this.ccdSP(e, c, s, o) && (a.push(o), o.toi < i && (i = o.toi, s = i + Be), o = n.acquire());
		return o.free(), F.stopTick("dSPB"), i;
	},
	dcdSS(e) {
		let t = e.bi, n = e.bj, r = t.position.distanceToSq(n.position);
		if (r - t.radiusSq - n.radiusSq - 2 * t.radius * n.radius > R) return !1;
		let i = Math.sqrt(r);
		return i < R ? We.set(0, 1, 0) : We.subVectors(t.position, n.position).scale(1 / i), e.resetRestingWithPeneNormal(.5 * (i - t.radius - n.radius), We), !0;
	},
	dcdSP(e) {
		let t = e.bi, n = e.bj, r = t.position, i = n.distanceFromPointToPlane(r) - t.radius;
		if (i > R || i < R - 2 * t.radius) return !1;
		if (this.pointInPolygon(n.edges, n.edgeXNormals, r)) return n.hasCustomNormalHandler ? e.resetRestingWithPeneCP(i, r) : e.resetRestingWithPeneNormal(i, n.normal), !0;
		let a = this.closestPointOnEdges(n.edges, r, H);
		return a - t.radiusSq > R ? !1 : (e.resetRestingWithPeneCP(Math.sqrt(a) - t.radius, H), !0);
	},
	ccdSS(e, t, n, r) {
		if (F.startTick("ccdSS"), V.subVectors(e.position, t.position), Ve.subVectors(e.v, t.v), Ve.dot(V) > 0) return F.stopTick("ccdSS"), !1;
		F.count("nCcdSS", 1);
		let i = e.radiusSq + t.radiusSq + 2 * e.radius * t.radius, a = V.lengthSq();
		if (a < i) return r.resetPendingWithToiPene(e, t, 0, .5 * (Math.sqrt(a) - e.radius - t.radius)), F.stopTick("ccdSS"), !0;
		let o = this.pRaySphereToi(Ve, Ve.dot(Ve), V, a, i);
		return o < n ? (r.resetPendingWithToiPene(e, t, o, 0), F.stopTick("ccdSS"), !0) : (F.stopTick("ccdSS"), !1);
	},
	ccdSP(e, t, n, r) {
		if (e.collisionMask & t.collisionGroup || t.bR !== 0 && !this.rayIntersect(e.position, e.v, e.vSq, t.bCenter, e.radiusSq + t.bRSq + 2 * e.radius * t.bR)) return !1;
		let i = t.distanceFromPointToPlane(e.position);
		if (i - e.radius >= -R) {
			let a = e.v.dot(t.normal);
			return a < 0 && this.__ccdspFar(i, e, t, a, n, r);
		}
		return i > R - e.radius && this.__ccdspNear(i, e, t, n, r);
	},
	__ccdspFar(e, t, n, r, i, a) {
		F.count("nCcdSP_Far", 1), F.startTick("ccdSP_Far"), He.scaleVector(t.radius, n.normal);
		let o = (t.radius - e) / r;
		return o < R && (o = 0), o > i ? (F.stopTick("ccdSP_Far"), !1) : (B.interpolate(t.position, t.v, o).sub(He), this.pointInPolygon(n.edges, n.edgeXNormals, B) ? (n.hasCustomNormalHandler ? a.resetPendingWithToiPeneCP(t, n, o, 0, B) : a.resetPendingWithToiPeneNormal(t, n, o, 0, n.normal), F.stopTick("ccdSP_Far"), !0) : (this.closestPointOnEdges(n.edges, B, H), Ue.copyNeg(t.v), z.subVectors(H, t.position), o = this.pRaySphereToi(Ue, t.vSq, z, z.lengthSq(), t.radiusSq), o <= i && o !== Number.MAX_VALUE ? (a.resetPendingWithToiPeneCP(t, n, o, 0, H), F.stopTick("ccdSP_Far"), !0) : (F.stopTick("ccdSP_Far"), !1)));
	},
	__ccdspNear(e, t, n, r, i) {
		if (F.count("nCcdSP_Near", 1), F.startTick("ccdSP_Near"), He.scaleVector(t.radius, n.normal), B.subVectors(t.position, He), this.pointInPolygon(n.edges, n.edgeXNormals, B)) return n.hasCustomNormalHandler ? i.resetPendingWithToiPeneCP(t, n, 0, e - t.radius, B) : i.resetPendingWithToiPeneNormal(t, n, 0, e - t.radius, n.normal), F.stopTick("ccdSP_Near"), !0;
		this.closestPointOnEdges(n.edges, B, H), z.subVectors(H, t.position);
		let a = z.lengthSq();
		if (a <= t.radiusSq) return i.resetPendingWithToiPeneCP(t, n, 0, Math.sqrt(a) - t.radius, H), F.stopTick("ccdSP_Near"), !0;
		Ue.copyNeg(t.v);
		let o = this.pRaySphereToi(Ue, t.vSq, z, a, t.radiusSq);
		return o <= r && o !== Number.MAX_VALUE ? (i.resetPendingWithToiPeneCP(t, n, o, 0, H), F.stopTick("ccdSP_Near"), !0) : (F.stopTick("ccdSP_Near"), !1);
	},
	pointInPolygon(e, t, n) {
		let r = null;
		for (let i = 0; i !== e.length; ++i) {
			Ge.subVectors(n, e[i].va);
			let a = t[i].dot(Ge);
			if (r !== null && !(a > 0 && r === !0 || a <= 0 && r === !1)) return !1;
			r === null && (r = a > 0);
		}
		return !0;
	},
	rayIntersect(e, t, n, r, i) {
		V.subVectors(e, r);
		let a = V.lengthSq() - i, o = V.dot(t);
		return !(a > 0 && o > 0) && o * o - a * n >= 0;
	},
	pRaySphereToi(e, t, n, r, i) {
		let a = n.dot(e), o = r - i;
		if (o > 0 && a > 0) return Number.MAX_VALUE;
		let s = a * a - t * o;
		if (s <= 0) return Number.MAX_VALUE;
		let c = (-a - Math.sqrt(s)) / t;
		return c < R && (c = 0), c;
	},
	closestPointOnEdges(e, t, n) {
		let r = Number.MAX_VALUE;
		for (let i of e) {
			Ge.subVectors(t, i.va);
			let e = Ge.dot(i.vab) / i.abDotAb, a = e <= 0 ? i.va : e >= 1 ? i.vb : Ke.scaleVector(e, i.vab).add(i.va), o = a.distanceToSq(t);
			o < r && (r = o, n.copy(a));
		}
		return r;
	}
}, qe = N.tPrecision, Je = class e {
	static TOISorter = (e, t) => {
		let n = t.toi - e.toi;
		return n === 0 ? t.penetration - e.penetration : n;
	};
	get length() {
		return this.stack.length;
	}
	__stack1;
	__stack2;
	stack;
	idleStack;
	__stackOrderDirty;
	constructor() {
		this.__stack1 = [], this.__stack2 = [], this.stack = this.__stack1, this.idleStack = this.__stack2, this.__stackOrderDirty = !1;
	}
	freeAll() {
		for (let e of this.stack) e.free();
		this.stack.length = 0, this.__stackOrderDirty = !1;
	}
	add(e) {
		e.markedAsKilled = !1, this.__stackOrderDirty = !0, this.stack.push(e);
	}
	removeAllSS() {
		let e = this.stack, t = this.idleStack, n = -1;
		for (let r of e) r.isSS ? r.free() : t[++n] = r;
		e.length = 0, this.stack = t, this.idleStack = e;
	}
	outdateAllSSWithId(e) {
		for (let t of this.stack) t.isSS && (t.idi === e || t.idj === e) && (t.markedAsKilled = !0);
	}
	resort() {
		this.__stackOrderDirty = !1;
		let t = this.stack, n = this.idleStack, r = -1;
		for (let e of t) e.isOutdated() ? e.free() : n[++r] = e;
		t.length = 0, n.sort(e.TOISorter), this.stack = n, this.idleStack = t;
	}
	step2(e, t) {
		let n, r, i, a, o = !1, s = e;
		if (this.__stackOrderDirty) for (this.resort(), n = this.stack, i = r = n.length; i > 0 && (a = n[--i]).toi <= s;) t.push(a), r--, o || (o = !0, s = Math.min(e, a.toi + qe));
		else for (n = this.stack, i = r = n.length; i > 0;) if (a = n[--i], a.isOutdated()) a.free(), r--;
		else {
			if (!(a.toi <= s)) break;
			t.push(a), r--, o || (o = !0, s = Math.min(e, a.toi + qe));
		}
		if (n.length = r, t.length !== 0 && (e = t[t.length - 1].toi), e > 0) for (let t of n) t.toi -= e, t.life += e;
		return e;
	}
	log(e, t) {
		let n = "", r = 0;
		for (let i of this.stack) e && i.isOutdated() || (t === void 0 || t.indexOf(i.idi) !== -1 || t.indexOf(i.idj) !== -1) && (n += i.toString() + "\n", r++);
		r === 0 ? console.log("[Lucky Break physics] No matching impact events.") : (console.log(`[Lucky Break physics] Impact queue: ${r} of ${this.stack.length} events`), console.log(`[Lucky Break physics] impact details\n${n}`));
	}
}, G = class e {
	data;
	constructor() {
		this.data = new Float32Array([
			1,
			0,
			0,
			0,
			1,
			0,
			0,
			0,
			1
		]);
	}
	toArray(e, t) {
		let n = this.data;
		for (let r = 0; r !== n.length; ++r) e[t + r] = n[r];
	}
	toString() {
		let e = this.data;
		return "Mat: [\n	" + e[0] + "," + e[1] + "," + e[2] + "\n	" + e[3] + "," + e[4] + "," + e[5] + "\n	" + e[6] + "," + e[7] + "," + e[8] + "]";
	}
	transform(e, t) {
		let n = this.data, r = e.x * n[0] + e.y * n[1] + e.z * n[2], i = e.x * n[3] + e.y * n[4] + e.z * n[5], a = e.x * n[6] + e.y * n[7] + e.z * n[8];
		t.set(r, i, a);
	}
	transformTranspose(e, t) {
		let n = this.data, r = e.x * n[0] + e.y * n[3] + e.z * n[6], i = e.x * n[1] + e.y * n[4] + e.z * n[7], a = e.x * n[2] + e.y * n[5] + e.z * n[8];
		t.set(r, i, a);
	}
	set(e, t, n, r, i, a, o, s, c) {
		let l = this.data;
		return l[0] = e, l[1] = r, l[2] = o, l[3] = t, l[4] = i, l[5] = s, l[6] = n, l[7] = a, l[8] = c, this;
	}
	identity() {
		return this.set(1, 0, 0, 0, 1, 0, 0, 0, 1), this;
	}
	clone() {
		return new e().fromArray(this.data);
	}
	fromArray(e, t = 0) {
		for (let n = 0; n < 9; n++) this.data[n] = e[n + t];
		return 9;
	}
	copy(e) {
		let t = e.data;
		return this.set(t[0], t[3], t[6], t[1], t[4], t[7], t[2], t[5], t[8]), this;
	}
	multiplyScalar(e) {
		let t = this.data;
		return t[0] *= e, t[3] *= e, t[6] *= e, t[1] *= e, t[4] *= e, t[7] *= e, t[2] *= e, t[5] *= e, t[8] *= e, this;
	}
	multiply(e) {
		let t = this.data, n = e.data, r = t[0] * n[0] + t[1] * n[3] + t[2] * n[6], i = t[0] * n[1] + t[1] * n[4] + t[2] * n[7], a = t[0] * n[2] + t[1] * n[5] + t[2] * n[8];
		return t[0] = r, t[1] = i, t[2] = a, r = t[3] * n[0] + t[4] * n[3] + t[5] * n[6], i = t[3] * n[1] + t[4] * n[4] + t[5] * n[7], a = t[3] * n[2] + t[4] * n[5] + t[5] * n[8], t[3] = r, t[4] = i, t[5] = a, r = t[6] * n[0] + t[7] * n[3] + t[8] * n[6], i = t[6] * n[1] + t[7] * n[4] + t[8] * n[7], a = t[6] * n[2] + t[7] * n[5] + t[8] * n[8], t[6] = r, t[7] = i, t[8] = a, this;
	}
	add(e) {
		let t = this.data, n = e.data;
		return t[0] += n[0], t[1] += n[1], t[2] += n[2], t[3] += n[3], t[4] += n[4], t[5] += n[5], t[6] += n[6], t[7] += n[7], t[8] += n[8], this;
	}
	addToDiagonal(e) {
		let t = this.data;
		return t[0] += e, t[4] += e, t[8] += e, this;
	}
	setInverse(e) {
		let t = e.data, n = this.data, r = t[0], i = t[1], a = t[2], o = t[3], s = t[4], c = t[5], l = t[6], u = t[7], d = t[8], f = d * s - c * u, p = c * l - d * o, m = u * o - s * l, h = r * f + i * p + a * m;
		if (h === 0) return console.warn("[Lucky Break physics] Matrix inversion skipped: determinant is zero."), this.identity();
		let g = 1 / h;
		return n[0] = f * g, n[1] = (a * u - d * i) * g, n[2] = (c * i - a * s) * g, n[3] = p * g, n[4] = (d * r - a * l) * g, n[5] = (a * o - c * r) * g, n[6] = m * g, n[7] = (i * l - u * r) * g, n[8] = (s * r - i * o) * g, this;
	}
	setTranspose(e) {
		let t = this.data, n = e.data;
		return t[0] = n[0], t[1] = n[3], t[2] = n[6], t[3] = n[1], t[4] = n[4], t[5] = n[7], t[6] = n[2], t[7] = n[5], t[8] = n[8], this;
	}
	transpose() {
		let e = this.data, t = e[1];
		return e[1] = e[3], e[3] = t, t = e[2], e[2] = e[6], e[6] = t, t = e[5], e[5] = e[7], e[7] = t, this;
	}
	setSkewSymmetric(e) {
		let t = this.data;
		return t[0] = 0, t[4] = 0, t[8] = 0, t[1] = -e.z, t[2] = e.y, t[3] = e.z, t[5] = -e.x, t[6] = -e.y, t[7] = e.x, this;
	}
	setComponents(e, t, n) {
		let r = this.data;
		r[0] = e.x, r[1] = t.x, r[2] = n.x, r[3] = e.y, r[4] = t.y, r[5] = n.y, r[6] = e.z, r[7] = t.z, r[8] = n.z;
	}
};
for (let e of Object.getOwnPropertyNames(G.prototype)) e !== "constructor" && Object.defineProperty(G.prototype, e, { enumerable: !0 });
//#endregion
//#region src/physics/contacts/BaseContact.ts
var Ye = e.EPSILON, K = new e(), Xe = new e(), Ze = class t {
	static gt = new e();
	get label() {
		return this.idi + "->" + this.idj;
	}
	get penetration() {
		return this._penetration;
	}
	get normal() {
		return this.normalDirty && this.normalUpdateHandler(), this._normal;
	}
	get bounceThreshold() {
		let e = this;
		return e.bounceThresholdDirty && (e.bounceThresholdDirty = !1, e._bounceThreshold = t.gt.dot(this.normal)), e._bounceThreshold;
	}
	get armI() {
		return this.armDirty && this.updateForceArm(), this._armI;
	}
	get armLenI() {
		return this.armDirty && this.updateForceArm(), this._armLenI;
	}
	get spaceTransformL2W() {
		return this.spaceTransformDirty && this.updateSpaceTransform(), this._m_loc2Wor;
	}
	get spaceTransformW2L() {
		return this.spaceTransformDirty && this.updateSpaceTransform(), this._m_wor2Loc;
	}
	get transformImp2LocVel() {
		return this.impulseTransformDirty && this.updateImpulseTransform(), this._m_imp2LocVel;
	}
	get transformLocVel2Imp() {
		return this.impulseTransformDirty && this.updateImpulseTransform(), this._m_locVel2Imp;
	}
	__weakParent;
	poolIndex;
	inUse;
	next;
	prev;
	isSS;
	markedAsKilled;
	bi;
	bj;
	idi;
	idj;
	cdRoundI;
	restitution;
	friction;
	toi;
	life;
	_penetration;
	restingCheckPosI;
	normalUpdateHandler;
	armDirty;
	_armI;
	_armLenI;
	bounceThresholdDirty;
	_bounceThreshold;
	relVelDirty;
	_closeSpeed;
	relativeVelW;
	vChangedCountI;
	spaceTransformDirty;
	_m_loc2Wor;
	_m_wor2Loc;
	impulseTransformDirty;
	_m_locVel2Imp;
	_m_imp2LocVel;
	m_imp2WorVel;
	skewSymmetric;
	normalDirty;
	_normal;
	rollingFriction;
	constructor(t, n) {
		this.__weakParent = t, this.poolIndex = t ? n : -1, this.inUse = !1, this.next = null, this.prev = null, this.isSS = !1, this.markedAsKilled = !1, this.bi = null, this.bj = null, this.idi = NaN, this.idj = NaN, this.cdRoundI = NaN, this.restitution = 0, this.friction = 0, this.toi = 0, this.life = 0, this._penetration = 0, this.restingCheckPosI = new e(), this.normalUpdateHandler = null, this.armDirty = !1, this._armI = new e(), this._armLenI = 0, this.bounceThresholdDirty = !1, this._bounceThreshold = 0, this.relVelDirty = !1, this._closeSpeed = 0, this.relativeVelW = new e(), this.vChangedCountI = -1, this.spaceTransformDirty = !1, this._m_loc2Wor = new G(), this._m_wor2Loc = new G(), this.impulseTransformDirty = !1, this._m_locVel2Imp = new G(), this._m_imp2LocVel = new G(), this.m_imp2WorVel = new G(), this.skewSymmetric = new G(), this.normalDirty = !1, this._normal = new e(), this.rollingFriction = .013;
	}
	toString() {
		return this.label + ": {toi:" + this.toi + ", life:" + this.life + ", outdated:" + this.isOutdated() + ", isSS:" + this.isSS + "}";
	}
	free() {
		this.bi = null, this.bj = null, this.inUse = !1, this.__weakParent.freeIndex(this.poolIndex);
	}
	dispose() {
		this.bi = null, this.bj = null, this.inUse = !1, this.__weakParent = null;
	}
	activate() {
		return this.inUse = !0, this.life = 0, this.toi = Number.MAX_VALUE, this._penetration = 0, this;
	}
	isOutdated() {
		return this.cdRoundI !== this.bi.cdRound || this.markedAsKilled;
	}
	startResting() {
		let e = this.bi, t = this.bj;
		this.restingCheckPosI.copy(e.position), this.restitution = e.restitution > t.restitution ? t.restitution : e.restitution, this.friction = e.friction > t.friction ? e.friction : t.friction;
	}
	needsUpdateResting() {
		return !this.restingCheckPosI.almostEquals(this.bi.position);
	}
	resetRestingWithPeneNormal(e, t) {
		this._penetration = e > -Ye ? 0 : e, this.restingCheckPosI.copy(this.bi.position), this.normalDirty = !1, this._normal.almostEquals(t) || (this._normal.copy(t), this.markNormalRelatedDirty());
	}
	stopResting() {
		this.bi.wakeUp();
	}
	resetWithBiBj(e, t) {
		(this.bi !== e || this.bj !== t) && (this.bi = e, this.idi = e.uid, this.bj = t, this.idj = t.uid, this.markObjectChanged());
	}
	getCloseSpeed() {
		let e = this.bi;
		return (this.relVelDirty || this.vChangedCountI !== e.vChangedCount) && this.updateRelVelocity(), this._closeSpeed;
	}
	getRelativeVelocity() {
		let e = this.bi;
		return (this.relVelDirty || this.vChangedCountI !== e.vChangedCount) && this.updateRelVelocity(), this.relativeVelW;
	}
	updateRelVelocity() {
		let e = this.bi;
		this.vChangedCountI = e.vChangedCount, this.relVelDirty = !1, this.relativeVelW.setCrossThenAdd(e.w, this.armI, e.v), this._closeSpeed = this.relativeVelW.dot(this.normal);
	}
	markNormalRelatedDirty() {
		this.bounceThresholdDirty = !0, this.spaceTransformDirty = !0, this.armDirty = !0, this.relVelDirty = !0, this.impulseTransformDirty = !0;
	}
	markNormalDirty() {
		this.normalDirty = !0, this.markNormalRelatedDirty();
	}
	markObjectChanged() {
		this.armDirty = !0, this.relVelDirty = !0, this.impulseTransformDirty = !0;
	}
	updateForceArm() {
		this.armDirty = !1, console.warn("[Lucky Break physics] Contact force-arm update has no implementation.");
	}
	updateSpaceTransform() {
		this.spaceTransformDirty = !1;
		let e = this.normal;
		if (Math.abs(e.x) > Math.abs(e.y)) {
			let t = 1 / Math.sqrt(e.z * e.z + e.x * e.x);
			K.set(e.z * t, 0, -e.x * t), Xe.set(e.y * K.z, e.z * K.x - e.x * K.z, -e.y * K.x);
		} else {
			let t = 1 / Math.sqrt(e.z * e.z + e.y * e.y);
			K.set(0, -e.z * t, e.y * t), Xe.set(e.y * K.z - e.z * K.y, -e.x * K.z, e.x * K.y);
		}
		this._m_loc2Wor.setComponents(e, K, Xe), this._m_wor2Loc.setTranspose(this._m_loc2Wor);
	}
	updateImpulseTransform() {
		let e = this.bi;
		this.impulseTransformDirty = !1;
		let t = this.skewSymmetric.setSkewSymmetric(this.armI), n = this.m_imp2WorVel.copy(t);
		n.multiply(e.invInertia), n.multiply(t), n.multiplyScalar(-1), this._m_imp2LocVel.copy(this.spaceTransformW2L), this._m_imp2LocVel.multiply(n), this._m_imp2LocVel.multiply(this.spaceTransformL2W), this._m_imp2LocVel.addToDiagonal(e.invMass), this._m_locVel2Imp.setInverse(this._m_imp2LocVel);
	}
}, Qe = e.EPSILON, $e = class extends Ze {
	cdRoundJ;
	vChangedCountJ;
	_armJ;
	_armLenJ;
	restingCheckPosJ;
	relVelWJ;
	m_imp2LocVel2;
	get armJ() {
		return this.armDirty && this.updateForceArm(), this._armJ;
	}
	get armLenJ() {
		return this.armDirty && this.updateForceArm(), this._armLenJ;
	}
	constructor(t, n) {
		super(t, n), this.isSS = !0, this.cdRoundJ = NaN, this.vChangedCountJ = -1, this._armJ = new e(), this._armLenJ = 0, this.restingCheckPosJ = new e(), this.relVelWJ = new e(), this.m_imp2LocVel2 = new G(), this.normalUpdateHandler = () => {
			let e = this.bi, t = this.bj;
			this.normalDirty = !1, this._normal.subVectors(e.position, t.position);
			let n = this._normal.length();
			n < Qe ? this._normal.set(0, 1, 0) : this._normal.scale(1 / n);
		}, this.rollingFriction = 0;
	}
	isOutdated() {
		let e = this.bi, t = this.bj;
		return this.cdRoundI !== e.cdRound || this.cdRoundJ !== t.cdRound || this.markedAsKilled;
	}
	startResting() {
		this.restingCheckPosJ.copy(this.bj.position), super.startResting();
	}
	needsUpdateResting() {
		let e = this.bi, t = this.bj;
		return !this.restingCheckPosI.almostEquals(e.position) || !this.restingCheckPosJ.almostEquals(t.position);
	}
	resetRestingWithPeneNormal(e, t) {
		this.restingCheckPosJ.copy(this.bj.position), super.resetRestingWithPeneNormal(e, t);
	}
	resetPendingWithToiPene(e, t, n, r) {
		this.resetWithBiBj(e, t), this.toi = n, this._penetration = r > -Qe ? 0 : r, this.cdRoundI = e.cdRound, this.cdRoundJ = t.cdRound, this.life = 0, this.markNormalDirty();
	}
	stopResting() {
		this.bi.wakeUp(), this.bj.wakeUp();
	}
	updateForceArm() {
		let e = this.bi, t = this.bj;
		this.armDirty = !1, this._armLenI = e.radius, this._armLenJ = t.radius, this._armI.scaleVector(-this._armLenI, this.normal), this._armJ.scaleVector(this._armLenJ, this.normal);
	}
	getCloseSpeed() {
		let e = this.bi, t = this.bj;
		return (this.relVelDirty || this.vChangedCountI !== e.vChangedCount || this.vChangedCountJ !== t.vChangedCount) && this.updateRelVelocity(), this._closeSpeed;
	}
	getRelativeVelocity() {
		let e = this.bi, t = this.bj;
		return (this.relVelDirty || this.vChangedCountI !== e.vChangedCount || this.vChangedCountJ !== t.vChangedCount) && this.updateRelVelocity(), this.relativeVelW;
	}
	updateRelVelocity() {
		let e = this.bi, t = this.bj;
		this.vChangedCountI = e.vChangedCount, this.vChangedCountJ = t.vChangedCount, this.relVelDirty = !1, this.relativeVelW.setCrossThenAdd(e.w, this.armI, e.v), this.relativeVelW.sub(this.relVelWJ.setCrossThenAdd(t.w, this.armJ, t.v)), this._closeSpeed = this.relativeVelW.dot(this.normal);
	}
	updateImpulseTransform() {
		let e = this.bi, t = this.bj;
		this.impulseTransformDirty = !1;
		let n = this.skewSymmetric.setSkewSymmetric(this.armI), r = this.m_imp2WorVel.copy(n);
		r.multiply(e.invInertia), r.multiply(n), r.multiplyScalar(-1), n = this.skewSymmetric.setSkewSymmetric(this.armJ);
		let i = this.m_imp2LocVel2.copy(n);
		i.multiply(t.invInertia), i.multiply(n), i.multiplyScalar(-1), r.add(i), this._m_imp2LocVel.copy(this.spaceTransformW2L), this._m_imp2LocVel.multiply(r), this._m_imp2LocVel.multiply(this.spaceTransformL2W), this._m_imp2LocVel.addToDiagonal(e.invMass + t.invMass), this._m_locVel2Imp.setInverse(this._m_imp2LocVel);
	}
}, et = class extends $e {
	get label() {
		return "tip";
	}
	constructor(t) {
		super(null, 0), this.isSS = !1, this.restitution = 0, this.friction = .9, this.bj = {
			uid: -1,
			restitution: 0,
			friction: .9,
			v: new e(),
			w: new e(),
			radius: 0,
			mass: t,
			invMass: t > 0 ? 1 / t : 0,
			invInertia: new G().set(0, 0, 0, 0, 0, 0, 0, 0, 0)
		};
	}
	resetTip(e, t) {
		let n = this.bj;
		this.bi = e, n.radius = t[7], n.v.set(t[3], t[4], t[5]).scale(t[6]);
		let r = e.position;
		this._normal.set(r.x - t[0], r.y - t[1], r.z - t[2]).normalize(), this.markNormalRelatedDirty();
	}
	free() {
		this.bi = null;
	}
	dispose() {
		this.bi = null, this.bj = null;
	}
}, tt = e.EPSILON, nt = class extends Ze {
	contactPoint;
	normalUpdateCP;
	constructor(t, n) {
		super(t, n), this.contactPoint = new e(), this.normalUpdateCP = () => {
			let e = this.bi, t = this.bj;
			if (this.normalDirty = !1, t.hasCustomNormalHandler) t.customNormalHandler(this.contactPoint, this._normal);
			else {
				this._normal.subVectors(e.position, this.contactPoint);
				let n = this._normal.length();
				n < tt ? this._normal.copy(t.normal) : this._normal.scale(1 / n);
			}
		};
	}
	resetRestingWithPeneCP(e, t) {
		this._penetration = e > -tt ? 0 : e, this.restingCheckPosI.copy(this.bi.position), this.contactPoint.copy(t), this.normalUpdateHandler = this.normalUpdateCP, this.markNormalDirty();
	}
	updateRelVelocity() {
		let e = this.bi;
		this.vChangedCountI = e.vChangedCount, this.relVelDirty = !1, this.relativeVelW.setCrossThenAdd(e.w, this.armI, e.v), this._closeSpeed = this.relativeVelW.dot(this.normal);
	}
	resetPendingWithToiPeneNormal(e, t, n, r, i) {
		this.resetWithBiBj(e, t), this.toi = n, this._penetration = r > -tt ? 0 : r, this.cdRoundI = e.cdRound, this.life = 0, this.normalDirty = !1, this._normal.almostEquals(i) || (this._normal.copy(i), this.markNormalRelatedDirty());
	}
	resetPendingWithToiPeneCP(e, t, n, r, i) {
		this.resetWithBiBj(e, t), this.toi = n, this._penetration = r > -tt ? 0 : r, this.cdRoundI = e.cdRound, this.life = 0, this.contactPoint.copy(i), this.normalUpdateHandler = this.normalUpdateCP, this.markNormalDirty();
	}
	updateForceArm() {
		let e = this.bi;
		this.armDirty = !1, this._armLenI = e.radius, this._armI.scaleVector(-this._armLenI, this.normal);
	}
}, rt = class {
	get size() {
		return this.pool.length;
	}
	get nInUse() {
		let e = 0;
		for (let t = 0; t !== this.pool.length; ++t) this.pool[t].inUse && e++;
		return e;
	}
	pool;
	freedIndices;
	maxFreedIndex;
	freedIndex;
	poolIndex;
	itemClass;
	maxExpCount;
	name;
	constructor(e, t, n) {
		this.pool = [];
		for (let e = 0; e !== n; ++e) this.pool[e] = new t(this, e);
		this.freedIndices = new Uint16Array(n), this.maxFreedIndex = n - 1, this.freedIndex = -1, this.poolIndex = -1, this.itemClass = t, this.maxExpCount = Math.max(1, n), this.name = e;
	}
	freeIndex(e) {
		this.freedIndex < this.maxFreedIndex && (this.freedIndices[++this.freedIndex] = e);
	}
	dispose() {
		for (let e = 0; e < this.pool.length; ++e) this.pool[e].dispose();
	}
	indexAt(e) {
		return this.pool[e];
	}
	freeAll() {
		for (let e = 0; e < this.pool.length; ++e) this.pool[e].free();
		this.freedIndex = -1, this.poolIndex = -1;
	}
	acquire() {
		let e = this.pool;
		if (this.freedIndex !== -1) {
			let t = e[this.freedIndices[this.freedIndex]];
			return this.freedIndex--, t.activate();
		}
		for (let t = 0; t !== e.length; ++t) {
			let t = e[++this.poolIndex % e.length];
			if (!t.inUse) return t.activate();
		}
		let t = e.length;
		this.poolIndex = t;
		let n = Math.min(this.maxExpCount, Math.floor(Math.floor(t / 3) + 1));
		for (let t = 0; t < n; ++t) e.push(new this.itemClass(this, e.length));
		return console.warn(`[Lucky Break memory] Expanded ${this.name} pool to ${e.length} items.`), e[this.poolIndex].activate();
	}
	log() {
		console.log(`[Lucky Break memory] ${this.name} pool: ${this.pool.length} items`);
		for (let e = 0; e !== this.pool.length; ++e) console.log(`[Lucky Break memory] item ${e}: active=${this.pool[e].inUse}; ${this.pool[e]}`);
		console.log(`[Lucky Break memory] End of ${this.name} pool snapshot.`);
	}
}, it = class e {
	x;
	y;
	z;
	w;
	constructor(e = 0, t = 0, n = 0, r = 1) {
		this.x = e || 0, this.y = t || 0, this.z = n || 0, this.w = r === void 0 ? 1 : r;
	}
	toArray(e, t) {
		e[t] = this.x, e[t + 1] = this.y, e[t + 2] = this.z, e[t + 3] = this.w;
	}
	fromArray(e, t = 0) {
		return this.x = e[t], this.y = e[t + 1], this.z = e[t + 2], this.w = e[t + 3], 4;
	}
	toString() {
		return "{x:" + this.x + ",y:" + this.y + ",z:" + this.z + ",w:" + this.w;
	}
	set(e, t, n, r) {
		return this.x = e, this.y = t, this.z = n, this.w = r, this;
	}
	setFromAngleAxis(e, t) {
		let n = Math.sin(t / 2);
		return this.w = Math.cos(t / 2), this.x = e.x * n, this.y = e.y * n, this.z = e.z * n, this;
	}
	setFromEuler(e, t, n, r = "XYZ") {
		let i = Math.cos(e / 2), a = Math.cos(t / 2), o = Math.cos(n / 2), s = Math.sin(e / 2), c = Math.sin(t / 2), l = Math.sin(n / 2);
		if (r === "XYZ") return this.x = s * a * o + i * c * l, this.y = i * c * o - s * a * l, this.z = i * a * l + s * c * o, this.w = i * a * o - s * c * l, this;
		switch (r) {
			case "YXZ": return this.x = s * a * o + i * c * l, this.y = i * c * o - s * a * l, this.z = i * a * l - s * c * o, this.w = i * a * o + s * c * l, this;
			case "ZXY": return this.x = s * a * o - i * c * l, this.y = i * c * o + s * a * l, this.z = i * a * l + s * c * o, this.w = i * a * o - s * c * l, this;
			case "ZYX": return this.x = s * a * o - i * c * l, this.y = i * c * o + s * a * l, this.z = i * a * l - s * c * o, this.w = i * a * o + s * c * l, this;
			case "YZX": return this.x = s * a * o + i * c * l, this.y = i * c * o + s * a * l, this.z = i * a * l - s * c * o, this.w = i * a * o - s * c * l, this;
			case "XZY": return this.x = s * a * o - i * c * l, this.y = i * c * o - s * a * l, this.z = i * a * l + s * c * o, this.w = i * a * o + s * c * l, this;
			default: throw Error("Quaternion rotation order is not recognized.");
		}
	}
	clone() {
		return new e(this.x, this.y, this.z, this.w);
	}
	copy(e) {
		return this.x = e.x, this.y = e.y, this.z = e.z, this.w = e.w, this;
	}
	normalize() {
		let e = Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
		return e === 0 ? (this.x = 0, this.y = 0, this.z = 0, this.w = 1) : (e = 1 / e, this.x *= e, this.y *= e, this.z *= e, this.w *= e), this;
	}
	integrate(e, t) {
		let n = t * .5, r = e.x, i = e.y, a = e.z, o = this.w, s = this.x, c = this.y, l = this.z, u = (-r * s - i * c - a * l) * n + o, d = (r * o + i * l - a * c) * n + s, f = (-r * l + i * o + a * s) * n + c, p = (r * c - i * s + a * o) * n + l, m = 1 / Math.sqrt(u * u + d * d + f * f + p * p);
		return this.w = u * m, this.x = d * m, this.y = f * m, this.z = p * m, this;
	}
	integrateQuad(e, t, n) {
		let r = n * .5, i = t.x, a = t.y, o = t.z, s = e.w, c = e.x, l = e.y, u = e.z, d = (-i * c - a * l - o * u) * r + s, f = (i * s + a * u - o * l) * r + c, p = (-i * u + a * s + o * c) * r + l, m = (i * l - a * c + o * s) * r + u, h = 1 / Math.sqrt(d * d + f * f + p * p + m * m);
		return this.w = d * h, this.x = f * h, this.y = p * h, this.z = m * h, this;
	}
	slerpQuaternions(e, t, n) {
		let r, i, a = e.x * t.x + e.y * t.y + e.z * t.z + e.w * t.w, o = !1;
		if (a < 0 && (o = !0, a = -a), a > .999999) i = 1 - n, r = o ? -n : n;
		else {
			let e = Math.acos(a), t = 1 / Math.sin(e);
			i = Math.sin((1 - n) * e) * t, r = o ? -Math.sin(n * e) * t : Math.sin(n * e) * t;
		}
		this.x = i * e.x + r * t.x, this.y = i * e.y + r * t.y, this.z = i * e.z + r * t.z, this.w = i * e.w + r * t.w;
	}
	multiply(e) {
		let t = this.x, n = this.y, r = this.z, i = this.w, a = e.x, o = e.y, s = e.z, c = e.w;
		return this.x = t * c + i * a + n * s - r * o, this.y = n * c + i * o + r * a - t * s, this.z = r * c + i * s + t * o - n * a, this.w = i * c - t * a - n * o - r * s, this;
	}
};
for (let e of Object.getOwnPropertyNames(it.prototype)) e !== "constructor" && Object.defineProperty(it.prototype, e, { enumerable: !0 });
//#endregion
//#region src/physics/dynamics/RigidBody.ts
var at = e.EPSILON, ot = N.gravity, st = new e(), ct = [
	"uid",
	"active",
	"acc",
	"cdRound",
	"v",
	"vProp_dir",
	"vProp_sq",
	"vProp_dirty",
	"vChangedCount",
	"vProp0_dir",
	"vProp0_sq",
	"__vState",
	"__vStateDirty",
	"w",
	"wProp_sq",
	"wProp_dirty",
	"position",
	"orientation",
	"predictionDirty",
	"steppedLenSq",
	"canSleep",
	"asleep",
	"energy"
], q = class t {
	static baseSleepBias = .3;
	static minEnergy = NaN;
	static maxEnergy = NaN;
	static wakeUpEnergy = NaN;
	static vStates = {
		ZERO: 0,
		SLOWER: 1,
		FASTER: 2,
		DIR_CHANGE: 3
	};
	uid;
	active;
	mass;
	invMass;
	acc;
	cdRound;
	v;
	vProp_dir;
	vProp_sq;
	vProp_dirty;
	vChangedCount;
	vProp0_dir;
	vProp0_sq;
	__vState;
	__vStateDirty;
	w;
	wProp_sq;
	wProp_dirty;
	invInertia;
	airAngularDamping;
	rfPower;
	rfDir;
	position;
	orientation;
	predictionDirty;
	steppedLenSq;
	canSleep;
	asleep;
	energy;
	userData;
	restitution;
	friction;
	peneOffset;
	penetration;
	serializable;
	collisionGroup;
	collisionMask;
	get wSq() {
		let e = this;
		return e.wProp_dirty && (e.wProp_dirty = !1, e.wProp_sq = this.w.lengthSq()), e.wProp_sq;
	}
	get vDir() {
		return this.vProp_dirty && this.updateVProps(), this.vProp_dir;
	}
	get vSq() {
		return this.vProp_dirty && this.updateVProps(), this.vProp_sq;
	}
	get vState() {
		return this.__vStateDirty && this.updateVState(), this.__vState;
	}
	constructor(n, r = 0, i = 0, a = 0, o = 0, s = 0, c = 0) {
		this.uid = -1, this.active = !0, this.mass = n, this.invMass = n > 0 ? 1 / n : 0, this.acc = ot.clone(), this.cdRound = 0, this.v = new e(), this.vProp_dir = new e(), this.vProp_sq = 0, this.vProp_dirty = !1, this.vChangedCount = 0, this.vProp0_dir = new e(), this.vProp0_sq = 0, this.__vState = 0, this.__vStateDirty = !1, this.w = new e(), this.wProp_sq = 0, this.wProp_dirty = !1, this.invInertia = new G(), this.airAngularDamping = N.airAngularDamping, this.rfPower = 0, this.rfDir = new e(), this.position = new e(r, i, a), this.orientation = new it().setFromEuler(o, s, c), this.predictionDirty = !1, this.steppedLenSq = 0, this.canSleep = !0, this.asleep = !1, this.energy = t.minEnergy, this.userData = null, this.restitution = 0, this.friction = 0, this.peneOffset = new e(), this.penetration = 0, this.serializable = !0, this.collisionGroup = 1, this.collisionMask = 0;
	}
	serialize(e) {
		if (!this.serializable) {
			e.push(-1 - Math.floor(10 * Math.random()));
			return;
		}
		if (e.push(this.uid), e.push(+!!this.active), this.active) for (let t = 2; t !== ct.length; ++t) {
			let n = this[ct[t]];
			switch (typeof n) {
				case "number":
					e.push(n);
					break;
				case "boolean":
					e.push(+!!n);
					break;
				case "object": n.toArray(e, e.length);
			}
		}
	}
	deserialize(e, t) {
		if (e[t] < 0) return t + 1;
		if (e[t + 1] === 0) return this.active = !1, t + 2;
		this.active = !0, t += 2;
		for (let n = 2; n !== ct.length; ++n) {
			let r = ct[n], i = this;
			switch (typeof i[r]) {
				case "number":
					i[r] = e[t++];
					break;
				case "boolean":
					i[r] = !!e[t++];
					break;
				case "object": t += i[r].fromArray(e, t);
			}
		}
		return t;
	}
	dispose() {
		let e = this;
		e.acc = null, e.v = null, e.vProp_dir = null, e.vProp0_dir = null, e.w = null, e.invInertia = null, e.position = null, e.orientation = null, e.userData = null;
	}
	setSleep() {
		this.asleep || (this.asleep = !0, this.energy = 0, this.vProp0_dir.set(0, 0, 0), this.vProp0_sq = 0, this.v.set(0, 0, 0), this.w.set(0, 0, 0), this.__vStateDirty = !0, this.vProp_dirty = !0, this.wProp_dirty = !0);
	}
	wakeUp() {
		this.asleep && (this.asleep = !1, this.energy = t.wakeUpEnergy);
	}
	applyForce(e) {
		this.acc.addScaled(e, this.invMass), this.wakeUp();
	}
	applyForce2(e, t) {
		this.acc.addScaled(t, this.invMass * e), this.wakeUp();
	}
	predVelocities(e) {
		if (this.predictionDirty = !1, !this.asleep) {
			if (this.v.addScaled(this.acc, e), this.rfPower !== 0) {
				let e = this.rfDir.normalize().scale(this.rfPower), t = Math.abs(e.x), n = Math.abs(e.y), r = Math.abs(e.z), i = this.w;
				i.x = i.x > t ? i.x - t : i.x < -t ? i.x + t : 0, i.y = i.y > n ? i.y - n : i.y < -n ? i.y + n : 0, i.z = i.z > r ? i.z - r : i.z < -r ? i.z + r : 0, this.rfPower = 0, e.set(0, 0, 0);
			}
			this.w.scale(this.airAngularDamping), this.__vStateDirty = !0, this.vProp_dirty = !0, this.vChangedCount++;
		}
	}
	applyImpulseAtPoint(e, t, n) {
		this.v.addScaled(e, this.invMass), st.crossVectors(t, e), this.invInertia.transform(st, st), this.w.add(st), n > this.rfPower && (this.rfPower = n), this.rfDir.add(st), this.__vStateDirty = !0, this.vProp_dirty = !0, this.wProp_dirty = !0, this.vChangedCount++, this.wakeUp(), this.canSleep = !0;
	}
	step(e) {
		if (this.asleep) return this.steppedLenSq = 0, this.penetration = 0, !0;
		this.position.addScaled(this.v, e), this.penetration !== 0 && (this.position.add(this.peneOffset), this.penetration = 0, this.canSleep = !1), this.orientation.integrate(this.w, e), this.acc.copy(ot), this.steppedLenSq = this.vSq * e;
		let n = t.baseSleepBias ** +e, r = n * this.energy + (1 - n) * this.getMotion();
		if (r > t.maxEnergy) r = t.maxEnergy;
		else if (r < t.minEnergy && this.canSleep) return this.setSleep(), !0;
		return this.energy = r, this.vProp0_dir.copy(this.vDir), this.vProp0_sq = this.vSq, !1;
	}
	addPeneOffset(e, t) {
		e < this.penetration && (this.penetration = e, this.peneOffset.copy(t), e < -.001 && this.wakeUp());
	}
	reset(e, t, n) {
		this.position.set(e, t, n), this.vProp0_dir.set(0, 0, 0), this.vProp0_sq = 0, this.acc.copy(ot), this.v.set(0, 0, 0), this.w.set(0, 0, 0), this.__vStateDirty = !0, this.vProp_dirty = !0, this.wProp_dirty = !0, this.wakeUp();
	}
	updateVProps() {
		this.vProp_dirty = !1, this.vProp_sq = this.v.lengthSq(), this.vProp_sq < at ? (this.vProp_sq = 0, this.vProp_dir.set(0, 0, 0), this.v.set(0, 0, 0)) : this.vProp_dir.scaleVector(1 / Math.sqrt(this.vProp_sq), this.v);
	}
	updateVState() {
		this.__vStateDirty = !1;
		let e = t.vStates, n = this.vSq;
		this.__vState = n === 0 ? e.ZERO : n > this.vProp0_sq ? e.FASTER : 1 - at > this.vDir.dot(this.vProp0_dir) ? e.DIR_CHANGE : e.SLOWER;
	}
	getMotion() {
		return this.vSq + this.wSq;
	}
}, lt = class {
	weakParent;
	id;
	inUse;
	itemEntry;
	itemTail;
	next;
	prev;
	totalItems;
	dirty;
	needsUpdate;
	needsPure;
	constructor(e, t) {
		this.weakParent = e, this.id = t, this.inUse = !1, this.itemEntry = null, this.itemTail = null, this.next = null, this.prev = null, this.totalItems = 0, this.dirty = !1, this.needsUpdate = !1, this.needsPure = !1;
	}
	activate() {
		return this.inUse = !0, this;
	}
	getGroundContact(e) {
		let t = this.itemEntry;
		for (; t;) {
			if (!t.isSS && t.idi === e && t.bj.ground) return t;
			t = t.next;
		}
		return null;
	}
	free() {
		this.next = null, this.prev = null, this.itemEntry = null, this.itemTail = null, this.totalItems = 0, this.inUse = !1, this.dirty = !1, this.needsUpdate = !1, this.needsPure = !1, this.weakParent.freeIndex(this.id);
	}
	dispose() {
		this.weakParent = null, this.next = null, this.prev = null, this.itemEntry = null, this.itemTail = null, console.warn("[Lucky Break physics] Contact island disposal remains provisional.");
	}
	setEntry(e) {
		e.next = null, e.prev = null, this.itemEntry = e, this.itemTail = e, this.totalItems = 1, this.dirty = !0;
	}
	remove(e) {
		let t = e.prev, n = e.next;
		t ? t.next = n : this.itemEntry = n, n ? n.prev = t : this.itemTail = t, this.dirty = !0, this.totalItems--, e.prev = null, e.next = null;
	}
	push(e) {
		let t = this.itemTail;
		t.next = e, e.prev = this.itemTail, e.next = null, this.itemTail = e, this.totalItems++, this.dirty = !0;
	}
	merge(e) {
		let t = this.itemTail, n = e.itemEntry;
		t.next = n, n.prev = t, this.itemTail = e.itemTail, this.totalItems += e.totalItems, this.dirty = !0;
	}
	toString() {
		let e = this.itemEntry;
		if (!e) return "Island " + this.id + ": {count:0, items:[]}";
		let t = "Island " + this.id + ": {count:" + this.totalItems + ", items:[" + e.label;
		for (e = e.next; e;) t += "," + e.label, e = e.next;
		return t + "], tail: " + this.itemTail.label + "}";
	}
}, ut = e.EPSILON, dt = [];
function ft(e, t) {
	e.__tail ? (e.__tail.next = t, t.prev = e.__tail, e.__tail = t) : (e.__entry = t, e.__tail = t), e.nIslands++;
}
var pt = class {
	get entry() {
		return this.needsPure && this.__pureIslands(), this.__entry;
	}
	get tail() {
		return this.needsPure && this.__pureIslands(), this.__tail;
	}
	pool;
	__entry;
	__tail;
	idMap;
	__pureMap;
	ssIdCounter;
	restingGrid;
	width;
	height;
	dataWidth;
	dataHeight;
	ssIdStart;
	nIslands;
	totalItems;
	needsPure;
	needsUpdate;
	constructor(e) {
		this.pool = new rt("island", lt, e), this.__entry = null, this.__tail = null, this.idMap = null, this.__pureMap = null, this.ssIdCounter = null, this.restingGrid = [], this.width = 0, this.height = 0, this.dataWidth = 0, this.dataHeight = 0, this.ssIdStart = 0, this.nIslands = 0, this.totalItems = 0, this.needsPure = !1, this.needsUpdate = !1;
	}
	resize(e, t) {
		this.ssIdStart = t;
		let n = e - t, r = !1;
		if (n > this.dataHeight && (r = !0, this.dataHeight = n, this.idMap = new Int8Array(n), this.__pureMap = new Int8Array(n), this.ssIdCounter = new Uint8Array(n)), e > this.dataWidth && (r = !0, this.dataWidth = e), r) {
			this.restingGrid.length = 0;
			for (let t = 0; t !== n; ++t) this.restingGrid[t] = new Uint8Array(e);
		}
		this.width = e, this.height = n, this.freeAll();
	}
	freeAll() {
		let e = this.idMap, t = this.ssIdCounter;
		this.pool.freeAll(), this.__entry = null, this.__tail = null;
		for (let t = 0; t !== this.height; ++t) e[t] = -1;
		for (let e = 0; e !== this.height; ++e) t[e] = 0;
		for (let e = 0; e !== this.height; ++e) for (let t = 0; t !== this.width; ++t) this.restingGrid[e][t] = 0;
		this.nIslands = 0, this.totalItems = 0, this.needsUpdate = !1;
	}
	isResting(e, t) {
		let n = this.restingGrid[e - this.ssIdStart][t];
		if (n !== 0 && n !== 1) throw this.log(), Error(`Resting-contact grid contains ${n} for bodies ${e} and ${t}.`);
		return n !== 0;
	}
	markReupdate(e) {
		this.needsPure && this.__pureIslands();
		let t = this.pool.indexAt(this.idMap[e - this.ssIdStart]);
		t && (t.needsUpdate = !0);
	}
	getNContacts(e) {
		return this.ssIdCounter[e - this.ssIdStart];
	}
	getIslandByIdi(e) {
		let t = this.idMap[e - this.ssIdStart];
		return t === -1 ? null : this.pool.indexAt(t);
	}
	add(e) {
		e.markedAsKilled = !1, e.isSS ? this.__addSS(e) : this.__addSP(e), this.totalItems++;
	}
	__addSP(e) {
		this.needsPure && this.__pureIslands();
		let t = this.idMap, n = this.ssIdCounter, r = e.idi - this.ssIdStart, i = t[r];
		if (n[r]++, this.restingGrid[r][e.idj]++, i !== -1) {
			this.pool.indexAt(i).push(e);
			return;
		}
		let a = this.pool.acquire();
		a.setEntry(e), t[r] = a.id, ft(this, a);
	}
	__addSS(e) {
		this.needsPure && this.__pureIslands();
		let t = this.idMap, n = this.ssIdCounter, r = e.idi - this.ssIdStart, i = e.idj - this.ssIdStart, a = t[r], o = t[i];
		if (n[r]++, n[i]++, this.restingGrid[r][e.idj]++, this.restingGrid[i][e.idi]++, a !== -1) {
			let n = this.pool.indexAt(a);
			if (o !== -1 && a !== o) {
				let e = this.pool.indexAt(o);
				n.merge(e), this.__removeIsland(e);
				for (let e = 0; e !== this.height; ++e) t[e] === o && (t[e] = a);
			} else t[i] = a;
			n.push(e);
		} else if (o !== -1) this.pool.indexAt(o).push(e), t[r] = o;
		else {
			let n = this.pool.acquire();
			n.setEntry(e), t[r] = n.id, t[i] = n.id, ft(this, n);
		}
	}
	__removeIsland(e) {
		let t = e.prev, n = e.next;
		t ? t.next = n : this.__entry = n, n ? n.prev = t : this.__tail = t, this.nIslands--, e.free();
	}
	__pureIslands() {
		this.needsPure = !1;
		let e = this.__entry;
		for (; e;) e.needsPure && this.__pureIsland(e), e = e.next;
	}
	removeAllContactsWithId(e) {
		let t = this.idMap, n = this.ssIdCounter, r = e - this.ssIdStart;
		if (t[r] === -1) {
			if (n[r] !== 0) throw Error(`Body ${e} has contacts but no contact-group mapping.`);
			return;
		}
		let i = this.pool.indexAt(t[r]), a = i.itemEntry;
		for (; a;) {
			let o = a.next;
			if (a.idi === e) {
				if (this.totalItems--, this.restingGrid[r][a.idj]--, i.remove(a), a.free(), a.isSS) {
					let r = a.idj - this.ssIdStart;
					this.restingGrid[r][e]--, --n[r] === 0 && (t[r] = -1);
				}
			} else if (a.idj === e) {
				this.totalItems--, this.restingGrid[r][a.idi]--, i.remove(a), a.free();
				let o = a.idi - this.ssIdStart;
				this.restingGrid[o][e]--, --n[o] === 0 && (t[o] = -1);
			}
			a = o;
		}
		n[r] = 0, t[r] = -1, i.totalItems === 0 ? this.__removeIsland(i) : i.totalItems > 1 && (i.needsPure = !0, this.needsPure = !0);
	}
	remove(e, t) {
		let n = this.idMap, r = this.ssIdCounter;
		this.totalItems--;
		let i = e.idi - this.ssIdStart, a = this.pool.indexAt(n[i]);
		if (a.remove(e), e.isSS) {
			let t = e.idj - this.ssIdStart, o = !0;
			this.restingGrid[i][e.idj]--, this.restingGrid[t][e.idi]--, --r[i] === 0 && (n[i] = -1, o = !1), --r[t] === 0 && (n[t] = -1, o = !1), a.totalItems === 0 ? this.__removeIsland(a) : o && (a.needsPure = !0, this.needsPure = !0);
		} else this.restingGrid[i][e.idj]--, --r[i] === 0 && (n[i] = -1), a.totalItems === 0 && this.__removeIsland(a);
		t && e.free();
	}
	__pureIsland(e) {
		let t = this.__pureMap, n = this.idMap, r = e.itemEntry, i = 0, a = this.ssIdStart;
		for (let e = 0; e !== this.height; ++e) t[e] = -1;
		for (dt[i] = e; r;) {
			let o = r.idi - a, s, c = e.id;
			t[o] = i, n[o] = c, r.isSS && (s = r.idj - a, t[s] = i, n[s] = c);
			let l = r, u = r, d = r.next, f = 1;
			for (; d;) {
				if (o = d.idi - a, s = d.idj - a, t[o] === i) n[o] = c, d.isSS && (t[s] = i, n[s] = c), u = d, f++;
				else {
					if (t[s] !== i) break;
					t[o] = i, n[o] = c, n[s] = c, u = d, f++;
				}
				d = d.next;
			}
			let p = u.next;
			for (; p;) o = p.idi - a, s = p.idj - a, (t[o] === i || t[s] === i) && (t[o] = i, n[o] = c, p.isSS && (t[s] = i, n[s] = c), p.prev.next = p.next, p.next && (p.next.prev = p.prev), u.next && (u.next.prev = p), p.next = u.next, u.next = p, p.prev = u, u = p, f++), p = p.next;
			r = u.next, l.prev = null, u.next = null, e.itemEntry = l, e.itemTail = u, e.totalItems = f, e.needsPure = !1, r && (i++, e = this.pool.acquire(), dt[i] = e);
		}
		for (let e = 1; e < dt.length; ++e) {
			let t = dt[e];
			this.__tail.next = t, t.prev = this.__tail, this.__tail = t, t.dirty = !0, this.nIslands++;
		}
		dt.length = 0;
	}
	logIslandByIds(e) {
		let t = this.entry, n = "", r = 0;
		for (; t;) {
			let i = t.itemEntry;
			for (; i;) {
				if (e.indexOf(i.idi - this.ssIdStart) !== -1 || e.indexOf(i.idj - this.ssIdStart) !== -1) {
					n += t.toString() + "\n", r++;
					break;
				}
				i = i.next;
			}
			t = t.next;
		}
		console.log(`[Lucky Break physics] ${r} contact groups match the requested bodies.`), n && console.log(`[Lucky Break physics] matching groups\n${n}`);
	}
	logPenes() {
		let e = this.entry, t = 0;
		for (; e;) {
			let n = e.itemEntry;
			for (; n;) n.penetration < -ut && (console.log(`[Lucky Break physics] overlap=${n.penetration}; contact=${n.label}`), t++), n = n.next;
			e = e.next;
		}
		console.log(`[Lucky Break physics] Contact groups contain ${t} overlaps.`);
	}
	log(e) {
		console.log(`[Lucky Break physics] Contact-group snapshot: ${this.nIslands} groups`);
		let t = this.entry;
		for (; t;) console.log(`[Lucky Break physics] group ${t.toString()}`), t = t.next;
		let n = [];
		for (let e = 0; e !== this.height; ++e) {
			let t = this.ssIdCounter[e];
			t !== 0 && n.push(e + this.ssIdStart + "(" + t + ")");
		}
		console.log(`[Lucky Break physics] body contact counts: [${n.join(",")}]`), e && this.pool.log(), console.log("[Lucky Break physics] End of contact-group snapshot.");
	}
}, mt = (e) => {}, ht = (e) => {}, gt = class {
	get stepSize() {
		return this._stepSize;
	}
	set stepSize(e) {
		this._stepSize !== e && (this._stepSize = e, q.minEnergy = Math.round(N.gravity.length() * e * (1 - q.baseSleepBias ** +e) * .5 * 1e3) / 1e3, q.maxEnergy = 4.5 * q.minEnergy, q.wakeUpEnergy = 1.4 * q.minEnergy, Ze.gt.scaleVector(2.3 * e, N.gravity));
	}
	get environmentReady() {
		return this._environmentReady;
	}
	get timestamp() {
		throw Error("Read evolution instead of the retired timestamp value.");
	}
	get evolution() {
		return this._evolution;
	}
	accumulator;
	meshBody;
	balls;
	qCDSP;
	qCDSS;
	ssSkips;
	p2a;
	rechecks;
	nRechecks;
	cActings;
	cPendings;
	spPool;
	ssPool;
	_environmentReady;
	internalStep;
	nAwakened;
	touchPresolveHandler;
	outOfBoundsHandler;
	useStrictMode;
	solver;
	lowestBoundY;
	_maxSteps;
	_stepSize = 0;
	_evolution;
	tipContact;
	constructor() {
		this.accumulator = 0, this.meshBody = null, this.balls = [], this.qCDSP = [], this.qCDSS = [], this.ssSkips = [], this.p2a = [], this.rechecks = [], this.nRechecks = 0, this.cActings = new pt(44), this.cPendings = new Je(), this.spPool = new rt("sp", nt, 70), this.ssPool = new rt("ss", $e, 70), this._environmentReady = !1, this.internalStep = this.__internalStep_error.bind(this), this.nAwakened = 0, this.touchPresolveHandler = mt, this.outOfBoundsHandler = ht, this.useStrictMode = !0, this.solver = Le.sharedInstance, this.lowestBoundY = -Number.MAX_VALUE, this._maxSteps = 10, this.stepSize = .0167, this._evolution = 0;
	}
	static makeSerialData() {
		return {
			balls: [],
			mbid: "",
			evolution: 0
		};
	}
	static copySerialDataAToB(e, t) {
		t.evolution = e.evolution, t.mbid = e.mbid;
		for (let n = 0; n !== e.balls.length; ++n) t.balls[n] = e.balls[n];
		t.balls.length = e.balls.length;
	}
	onTouchPresolve(e) {
		e !== void 0 && (this.touchPresolveHandler = e);
	}
	onOutOfBounds(e) {
		e !== void 0 && (this.outOfBoundsHandler = e);
	}
	clearCallbacks() {
		this.touchPresolveHandler = mt, this.outOfBoundsHandler = ht;
	}
	shoot(e, t) {
		this.tipContact ||= new et(.15), this.tipContact.resetTip(e, t), this.solver.solveContact(this.tipContact), this.tipContact.free(), e.wakeUp();
	}
	_breakEnvironment() {
		this._environmentReady = !1, this.internalStep = this.__internalStep_error.bind(this), this.cPendings.freeAll(), this.cActings.freeAll(), this.spPool.freeAll(), this.ssPool.freeAll(), this.qCDSP.length = 0, this.qCDSS.length = 0, this.ssSkips.length = 0, this.p2a.length = 0;
	}
	_rebuildEnvironment() {
		this._environmentReady = !0;
		let e = this.meshBody.nPolygons, t = e;
		for (let t of this.balls) t.uid = e++, N.setBallFrictionAndRestitution(t);
		this.cActings.resize(e, t), this.internalStep = this.__internalStep__.bind(this);
	}
	emptyMeshBody() {
		this._environmentReady && this._breakEnvironment(), this.meshBody = null;
	}
	emptyBalls() {
		this._environmentReady && this._breakEnvironment();
		for (let e of this.balls) e.dispose();
		this.balls.length = 0;
	}
	reset() {
		if (this._environmentReady) {
			if (this.cPendings.freeAll(), this.cActings.freeAll(), this.spPool.freeAll(), this.ssPool.freeAll(), this.nRechecks !== 0) throw Error("Physics reset began with pending collision checks.");
		} else this._rebuildEnvironment();
		W.initIslands(this.balls, this.meshBody, this.cActings, this.ssPool, this.spPool), this._evolution++;
	}
	serialize(e) {
		if (!this._environmentReady) throw Error("Physics state cannot be saved before the table is ready.");
		e.balls.length = 0;
		for (let t of this.balls) t.serialize(e.balls);
		return e.evolution = this._evolution, e.mbid = this.meshBody.id, e;
	}
	deserialize(e) {
		if (!this._environmentReady) throw Error("Physics state cannot be restored before the table is ready.");
		let t = this.meshBody;
		if (e.mbid !== t.id) throw Error(`Saved collision mesh "${e.mbid}" does not match "${t.id}".`);
		this.nAwakened = 0;
		let n = 0;
		for (let t of this.balls) n = t.deserialize(e.balls, n), t.active && !t.asleep && this.nAwakened++;
		this.reset(), this._evolution = e.evolution;
	}
	addBall(e) {
		if (this._environmentReady) throw Error("Balls must be added before the physics table is sealed.");
		this.balls.push(e);
	}
	setMeshBody(e) {
		if (this._environmentReady) throw Error("The collision mesh must be assigned before the physics table is sealed.");
		this.meshBody = e, this.lowestBoundY = e.lowestPosition.y;
	}
	inactivateBall(e) {
		if (!e.active) return;
		let t = e.uid;
		e.active = !1, this.cActings.removeAllContactsWithId(t);
		for (let e of this.cPendings.stack) (e.idi === t || e.idj === t) && (e.markedAsKilled = !0);
	}
	step(e) {
		F.clear(), F.startTick("step");
		let t = 0;
		for (this.accumulator += e; this.accumulator >= this._stepSize && t < this._maxSteps;) this.accumulator -= this._stepSize, t++, this.internalStep();
		if (t === 0) {
			this.nAwakened = 0;
			for (let e of this.balls) e.active && !e.asleep && this.nAwakened++;
		}
		return F.count("nSteps", t), F.count("nIslands", this.cActings.nIslands), F.count("nPendings", this.cPendings.length), F.count("nAwakened", this.nAwakened), F.stopTick("step"), F.end(), t * this._stepSize;
	}
	markRecheck(e) {
		this.nRechecks++, this.rechecks.push(e);
	}
	flushRechecks(e, t) {
		for (let n of this.rechecks) if (n.isOutdated()) n.free();
		else if (n.isSS) {
			let r = n, i = r.bi, a = r.bj;
			!i.active || !a.active || e.indexOf(i) !== -1 || e.indexOf(a) !== -1 || i.vState === 0 && a.vState === 0 || !W.ccdSS(i, a, t, r) ? n.free() : this.cPendings.add(n);
		} else {
			let e = n, t = e.bi;
			t.active && t.vState !== 0 && W.ccdSP(t, e.bj, Number.MAX_VALUE, e) ? this.cPendings.add(n) : n.free();
		}
		this.rechecks.length = 0, this.nRechecks = 0;
	}
	__internalStep_error() {
		throw Error("Reset the physics world before advancing the simulation.");
	}
	__internalStep__() {
		let e = this.balls, t = this.cActings, n = this.cPendings, r = this.solver, i = this.p2a, a = q.vStates.ZERO, o = q.vStates.SLOWER, s = this.useStrictMode, c = this._stepSize, l = 0, u = 0;
		F.count("internalStep", 1), this._evolution++, s ? n.removeAllSS() : a = o, W.updateIslands(t, !0);
		for (let t of e) t.active && t.predVelocities(c);
		r.solveList(t, !0);
		for (let t of e) t.active && (t.vState > o ? (t.cdRound++, this.qCDSP.push(t), this.qCDSS.push(t)) : t.vState > a && this.qCDSS.push(t));
		for (; l < c || this.qCDSP.length;) {
			let d = c - l, f = s ? d : Number.MAX_VALUE;
			if (++u > 100) throw Error(`Physics step exceeded its 100-iteration safety limit (${u}).`);
			if (F.count("iteration", 1), this.qCDSP.length !== 0) {
				for (let e of this.qCDSP) W.updateSPToi(e, this.meshBody, this.spPool, t, n);
				this.qCDSP.length = 0;
			}
			if (this.nRechecks && this.flushRechecks(this.qCDSS, f), this.qCDSS.length !== 0) {
				for (let r of this.qCDSS) W.updateSSToi(r, e, this.ssPool, t, this.ssSkips, f, n), this.ssSkips.push(r.uid);
				this.qCDSS.length = 0, this.ssSkips.length = 0;
			}
			if (F.startTick("pending_step"), d = n.step2(d, i), F.stopTick("pending_step"), i.length === 0) {
				this.nAwakened = 0;
				for (let t of e) t.active && (t.step(d) || this.nAwakened++, t.position.y < this.lowestBoundY && (this.inactivateBall(t), this.outOfBoundsHandler(t)));
				this.nAwakened === 0 && (n.freeAll(), this.accumulator = 0);
				break;
			}
			if (d > 0) {
				l += d, this.nAwakened = 0;
				for (let t of e) t.active && !t.step(d) && this.nAwakened++;
				for (let e of i) e.bi.steppedLenSq > N.islandUpdMinDisSq && t.markReupdate(e.idi), e.isSS && e.bj.steppedLenSq > N.islandUpdMinDisSq && t.markReupdate(e.idj);
				W.updateIslands(t, !1);
				for (let t of e) t.active && t.predictionDirty && t.predVelocities(c - l);
			}
			for (let e of i) {
				let n = e.bi, r = e.isSS ? e.bj : null;
				!n.active || r && !r.active ? e.free() : e.life === 0 ? (t.add(e), e.startResting(), this.touchPresolveHandler(e)) : this.markRecheck(e);
			}
			i.length = 0, r.solveList(t, !1);
			for (let t of e) t.active && (t.vState > o ? (t.cdRound++, this.qCDSP.push(t), this.qCDSS.push(t)) : t.vState > a && (n.outdateAllSSWithId(t.uid), this.qCDSS.push(t)));
		}
	}
}, _t = () => {};
function vt(e) {
	let t = this.predictionCtx;
	if (t.impactOccured || e.bj.ground) return !1;
	let n, r;
	e.idi === t._b1.uid ? (n = e.bi, r = e.bj) : (n = e.bj, r = e.bi), this.meshBody = this.simplifiedMeshBody, t.onImpact(e.isSS ? r : null);
	for (let e of this.balls) e !== n && e !== r && this.inactivateBall(e);
	return !0;
}
var yt = class {
	p0;
	p1;
	cue;
	cueVSq;
	impactV1;
	targetNumber;
	p2;
	target;
	targetVSq;
	_b1;
	_b2;
	impactOccured;
	hasImpactTarget;
	constructor() {
		this.p0 = new e(), this.p1 = new e(), this.cue = new e(), this.cueVSq = 0, this.impactV1 = new e(), this.targetNumber = 0, this.p2 = new e(), this.target = new e(), this.targetVSq = 0, this._b1 = null, this._b2 = null, this.impactOccured = !1, this.hasImpactTarget = !1;
	}
	onPredictionStart(e) {
		this._b1 = e, this._b2 = null, this.impactOccured = !1, this.hasImpactTarget = !1, this.p0.copy(this._b1.position), this.cue.copy(this.p0);
	}
	onStepped() {
		let e = this._b1, t = this.cue.distanceTo(e.position);
		return this.cue.copy(e.position), t;
	}
	onImpact(e) {
		let t = this._b1;
		this.impactOccured = !0, this.p1.copy(t.position), t.collisionMask = 12, e && (this.hasImpactTarget = !0, this._b2 = e, this.p2.copy(e.position), e.collisionMask = 12, this.targetNumber = e.number);
	}
	onPredictionEnd() {
		let e = this._b1;
		this.cueVSq = e.vSq, e.collisionMask = 0, this._b1 = null, this._b2 &&= (this.target.copy(this._b2.position), this.targetVSq = this._b2.vSq, this._b2.collisionMask = 0, null);
	}
}, bt = class extends gt {
	predictionCtx;
	predictorSolver;
	_serialData;
	predictorCallback;
	simplifiedMeshBody;
	originMeshBody = null;
	constructor() {
		super(), this.predictionCtx = new yt(), this.predictorSolver = ze.sharedInstance, this._serialData = gt.makeSerialData(), this.predictorCallback = vt.bind(this), this.simplifiedMeshBody = null;
	}
	setMeshBody(e) {
		super.setMeshBody(e), this.originMeshBody = e, this.simplifiedMeshBody = e.slice("ground");
	}
	emptyMeshBody() {
		this.simplifiedMeshBody = null, this.originMeshBody = null, super.emptyMeshBody();
	}
	save() {
		this.serialize(this._serialData);
	}
	restore(e) {
		this._environmentReady || this._rebuildEnvironment(), e !== void 0 && gt.copySerialDataAToB(e, this._serialData), this.deserialize(this._serialData);
	}
	step(e) {
		let t = super.step(e), n = this.accumulator;
		n > this._stepSize && (n = 0);
		for (let e of this.balls) e.syncStates(n);
		return t;
	}
	predict(e, t, n) {
		let r = this.touchPresolveHandler, i = this.outOfBoundsHandler, a = this.predictionCtx, o = 0, s = 0;
		for (this.solver = this.predictorSolver, this.touchPresolveHandler = _t, this.outOfBoundsHandler = _t, this.useStrictMode = !1, this.predictorSolver.reset(this.predictorCallback), a.onPredictionStart(e), this.shoot(e, t), a.impactV1.copy(e.v); s < n && ++o < 70 && (this.predictorSolver.interrupt = !1, this.internalStep(), s += a.onStepped(), a.impactOccured || a.impactV1.copy(e.v), !(e.getMotion() < 1)););
		return this.meshBody = this.originMeshBody, this.touchPresolveHandler = r, this.outOfBoundsHandler = i, this.predictorSolver.reset(null), this.solver = Le.sharedInstance, this.useStrictMode = !0, a.onPredictionEnd(), this.restore(), a;
	}
}, xt = class extends q {
	radius;
	radiusSq;
	states;
	constructor(t, n, r, i, a, o, s, c) {
		super(n, r, i, a, o, s, c), this.radius = t, this.radiusSq = t * t;
		let l = 1 / (.4 * this.mass * this.radiusSq);
		this.invInertia.set(l, 0, 0, 0, l, 0, 0, 0, l), this.states = {
			position: new e(),
			orientation: new it()
		};
	}
	getMotion() {
		return this.vSq + this.wSq * this.radiusSq;
	}
	syncStates(e) {
		this.states.position.interpolate(this.position, this.v, e), this.states.orientation.integrateQuad(this.orientation, this.w, e);
	}
}, St = class extends xt {
	number;
	spot;
	index;
	constructor(t, n, r, i, a, o, s) {
		super(n, r, 0, 0, 0, 0, 0, 0), this.number = t, this.spot = new e(i, a, o), this.index = s;
	}
}, Ct = { shenmueNine: {
	rgb: "shenmue-pool-table-collision.json",
	dArea: {
		cx: -1.11,
		cz: 0,
		sx: -1.35,
		sz: 0
	}
} }, J = Object.create(null);
J.FIRST_KISS = "fk", J.OUT_OF_BOUNDS = "oob", J.POTTED = "ptd", J.PREPOT = "ppt";
//#endregion
//#region src/simulator/SimulatorEvents.ts
var Y = Object.create(null);
Y.ERROR = "error", Y.SYNCHRONIZED = "synchronized", Y.BALL_IMPACT = "ball_impact";
//#endregion
//#region src/simulator/SimulatorState.ts
var X = Object.create(null);
X.ERROR = -1, X.NO_SCENE = 0, X.LOADING = 1, X.SYNCHRONIZED = 2;
//#endregion
//#region src/simulator/BilliardsSimulator.ts
var wt = class extends k {
	get sceneId() {
		return this._sceneId;
	}
	get id() {
		return this._id;
	}
	get state() {
		return this._state;
	}
	get nAwakened() {
		return this._nPhxAwakened;
	}
	get ground() {
		return this._world.meshBody.ground;
	}
	get sidePolyGroups() {
		return this._world.meshBody.getGroupByName("side");
	}
	get ballRadius() {
		return this._syncList.ballRadius;
	}
	get spotY() {
		return this._spotY;
	}
	get evolution() {
		return this._world.evolution;
	}
	get stepSize() {
		return this._world.stepSize;
	}
	get result() {
		return this._result;
	}
	_id;
	_world;
	_sceneId;
	_mbCache;
	_spotY;
	_syncList;
	_nPhxAwakened;
	_state;
	_result;
	_onTouch;
	_onOutOfBounds;
	_checkSyncTimerId;
	_onCheckSyncTimeout;
	constructor(e, t, n) {
		super(), this._id = e + "", this._world = t, this._sceneId = "", this._mbCache = n, this._spotY = NaN, this._syncList = {
			ballSet: [],
			ballRadius: 0,
			ballMass: 0,
			sceneId: ""
		}, this._nPhxAwakened = 0, this._state = NaN, this._setState(X.NO_SCENE), this._result = A.makeSimulatorResult(), this._onTouch = (e) => {
			let t = this._result;
			if (e.isSS) {
				this.emit(Y.BALL_IMPACT, Math.max(0, -e.getCloseSpeed()));
				let n = e.bi, r = e.bj, i = null;
				n.number === 0 ? (t.nKissed++, i = r) : r.number === 0 && (t.nKissed++, i = n), t.nKissed === 1 && i !== null && (t.firstKissIndex = i.index, this.emit(J.FIRST_KISS, t.firstKissIndex));
			} else if (e.bj?.end) {
				let n = e.bi;
				this._world.inactivateBall(n), t.pottedIndices.push(n.index), this.emit(J.POTTED, n.index);
			} else if (e.bj?.tunnel) this.emit(J.PREPOT, e.bi.index);
			else if (e.bj?.sidehard || e.bj?.sidesoft) {
				let n = e.bi;
				t.nKissed > 0 && (t.railAfterFirstContact = !0), n.number > 0 && !t.objectRailContactIndices.includes(n.index) && t.objectRailContactIndices.push(n.index);
			}
		}, this._onOutOfBounds = (e) => {
			let t = e;
			this._result.outOfBoundsIndices.push(t.index), this.emit(J.OUT_OF_BOUNDS, t.index);
		}, this._checkSyncTimerId = -1, this._onCheckSyncTimeout = () => {
			this._checkSyncTimerId = -1, this._checkSyncList();
		}, this._world.onTouchPresolve(this._onTouch), this._world.onOutOfBounds(this._onOutOfBounds);
	}
	sync(e) {
		this._setState(X.LOADING);
		let t = this._syncList;
		if (e.sceneId !== void 0 && (t.sceneId = e.sceneId), e.ballSet !== void 0) {
			for (let n = 0; n !== e.ballSet.length; n++) t.ballSet[n] = e.ballSet[n];
			t.ballSet.length = e.ballSet.length;
		}
		e.ballRadius !== void 0 && (t.ballRadius = e.ballRadius), e.ballMass !== void 0 && (t.ballMass = e.ballMass), this._checkSyncTimerId === -1 && this._checkSyncList();
	}
	_checkSyncList() {
		let e = this._syncList;
		if (e.sceneId !== this._sceneId) {
			let t = Ct[e.sceneId];
			if (!t) {
				this._err(`Table physics scene "${e.sceneId}" is unavailable.`);
				return;
			}
			let n = t.rgb;
			if (!n || n.length === 0) {
				this._err(`Table physics scene "${e.sceneId}" has no collision mesh.`);
				return;
			}
			let r = this._mbCache.getCache(n);
			if (!r) {
				this._checkSyncTimerId = setTimeout(this._onCheckSyncTimeout, 100);
				return;
			}
			if (r.isError) {
				this._err(r.message);
				return;
			}
			this._world.emptyMeshBody(), this._world.setMeshBody(r), this._sceneId = e.sceneId;
		}
		let t = e.ballSet, n = this._world.balls;
		if (n.length === 0 || n.length !== t.length / 3 || n[0].radius !== e.ballRadius || n[0].mass !== e.ballMass) {
			if (this._world.emptyBalls(), e.ballRadius <= 0 || e.ballMass <= 0) {
				this._err(`Ball mass and radius must be positive; received ${e.ballMass} and ${e.ballRadius}.`);
				return;
			}
			if (t.length === 0 || t.length % 3 != 0) {
				this._err(`Ball layout must contain number/x/z triples; received ${t.length} values.`);
				return;
			}
			let n = this._world.meshBody.ground;
			this._spotY = n.centerPosition.y + e.ballRadius;
			for (let n = 0; n !== t.length / 3; n++) this._world.addBall(new St(t[3 * n], e.ballRadius, e.ballMass, t[3 * n + 1], this._spotY, t[3 * n + 2], n));
		}
		this._setState(X.SYNCHRONIZED), this.emit(Y.SYNCHRONIZED);
	}
	reset(e, t) {
		if (e) for (let e of this._world.balls) this.resetBallPosition(e, e.spot);
		return t && this.clearResult(), this._world.reset(), this;
	}
	getBalls() {
		return this._world.balls;
	}
	getBallAtIndex(e) {
		return this._world.balls[e];
	}
	getCueBallPosition() {
		return this._world.balls[0].position;
	}
	respotIndexDefault(e) {
		let t = this._world.balls[e];
		this.resetBallPosition(t, t.spot);
	}
	respotIndexXYZ(e, t, n, r) {
		this.resetBallXYZ(this._world.balls[e], t, n, r);
	}
	resetBallPosition(e, t) {
		t ? this.resetBallXYZ(e, t.x, t.y, t.z) : (this._world.inactivateBall(e), this._nPhxAwakened++);
	}
	step(e) {
		let t = this._world.step(e);
		return this._nPhxAwakened = this._world.nAwakened, t;
	}
	save() {
		this._world.save();
	}
	predict(e, t) {
		return this._world.predict(this._world.balls[0], e, t);
	}
	getPredictionCtx() {
		return this._world.predictionCtx;
	}
	stroke(e) {
		this.clearResult(), this._world.shoot(this._world.balls[0], e), this._nPhxAwakened++;
	}
	clearResult() {
		this._result.nKissed = 0, this._result.firstKissIndex = 0, this._result.pottedIndices.length = 0, this._result.outOfBoundsIndices.length = 0, this._result.railAfterFirstContact = !1, this._result.objectRailContactIndices.length = 0;
	}
	touchBalls(t, n, r) {
		r === void 0 && (r = 1.02 * this.ballRadius);
		let i = r + this.ballRadius, a = i * i;
		for (let r = 0; r !== this._world.balls.length; r++) {
			let i = this._world.balls[r];
			if (r !== t && i.active && i.position.distanceToSq(n) < a - e.EPSILON) return !0;
		}
		return !1;
	}
	_setState(e) {
		this._state !== e && (this._state = e);
	}
	_err(e) {
		this._setState(X.ERROR), this.emit(Y.ERROR, Error(e));
	}
	resetBallXYZ(e, t, n, r) {
		e.reset(t, n, r), e.active = !0, this._nPhxAwakened++;
	}
}, Tt = {
	side: /* @__PURE__ */ JSON.parse("{\"p\":[1.395236,0.75,0.749582,0.085648,0.87,0.749582,0.085648,0.75,0.749582,-1.500083,0.75,-0.624763,-1.500083,0.87,0.624763,-1.500083,0.87,-0.624763,-0.085648,0.87,0.749582,-1.395236,0.75,0.749582,-0.085648,0.75,0.749582,0.085648,0.87,-0.749582,1.395236,0.75,-0.749582,0.085648,0.75,-0.749582,-1.395236,0.75,-0.749582,-0.085648,0.87,-0.749582,-0.085648,0.75,-0.749582,1.500083,0.87,0.624763,1.500083,0.75,-0.624763,1.500083,0.87,-0.624763,1.395236,0.87,0.749582,-1.500083,0.75,0.624763,-1.395236,0.87,0.749582,1.395236,0.87,-0.749582,-1.395236,0.87,-0.749582,1.500083,0.75,0.624763,0.035645,0.87,0.824741,0.046497,0.75,0.773827,0.046497,0.87,0.773827,1.423785,0.75,0.752424,1.4611,0.87,0.770733,1.423785,0.87,0.752424,1.553676,0.75,0.745903,1.520869,0.87,0.710707,1.553676,0.87,0.745903,1.520869,0.75,0.710707,1.501419,0.87,0.671748,1.49833,0.75,0.805261,1.4611,0.75,0.770733,-0.046497,0.75,0.773827,-0.035645,0.87,0.824741,-0.046497,0.87,0.773827,-1.4611,0.87,0.770733,-1.423785,0.75,0.752424,-1.423785,0.87,0.752424,-1.520869,0.87,0.710707,-1.553676,0.75,0.745903,-1.553676,0.87,0.745903,-1.501419,0.87,0.671748,-1.520869,0.75,0.710707,-1.49833,0.75,0.805261,-1.4611,0.75,0.770733,0.046497,0.75,-0.773827,0.035645,0.87,-0.824741,0.046497,0.87,-0.773827,1.4611,0.87,-0.770733,1.423785,0.75,-0.752424,1.423785,0.87,-0.752424,1.520869,0.87,-0.710707,1.553676,0.75,-0.745903,1.553676,0.87,-0.745903,1.501419,0.87,-0.671748,1.520869,0.75,-0.710707,1.49833,0.75,-0.805261,1.4611,0.75,-0.770733,-0.035645,0.87,-0.824741,-0.046497,0.75,-0.773827,-0.046497,0.87,-0.773827,-1.423785,0.75,-0.752424,-1.4611,0.87,-0.770733,-1.423785,0.87,-0.752424,-1.553676,0.75,-0.745903,-1.520869,0.87,-0.710707,-1.553676,0.87,-0.745903,-1.520869,0.75,-0.710707,-1.501419,0.87,-0.671748,-1.49833,0.75,-0.805261,-1.4611,0.75,-0.770733,0.035645,0.75,0.824741,1.501419,0.75,0.671748,1.49833,0.87,0.805261,-0.035645,0.75,0.824741,-1.501419,0.75,0.671748,-1.49833,0.87,0.805261,0.035645,0.75,-0.824741,1.501419,0.75,-0.671748,1.49833,0.87,-0.805261,-0.035645,0.75,-0.824741,-1.501419,0.75,-0.671748,-1.49833,0.87,-0.805261,0.018782,0.75,0.839957,-0.018782,0.87,-0.839957,0.018782,0.75,-0.839957,-0.018782,0.75,-0.839957,1.53506,0.87,0.814374,1.53506,0.75,0.814374,1.565112,0.87,0.784194,1.565112,0.75,0.784194,-0.018782,0.75,0.839957,-1.53506,0.87,0.814374,-1.565112,0.87,0.784194,-1.53506,0.75,0.814374,-1.565112,0.75,0.784194,-0.018782,0.87,0.839957,1.53506,0.87,-0.814374,1.565112,0.87,-0.784194,1.53506,0.75,-0.814374,1.565112,0.75,-0.784194,-1.53506,0.87,-0.814374,-1.53506,0.75,-0.814374,-1.565112,0.87,-0.784194,-1.565112,0.75,-0.784194,0.018782,0.87,0.839957,0.018782,0.87,-0.839957,0.065863,0.75,0.754264,0.065863,0.87,0.754264,-0.065863,0.75,0.754264,-0.065863,0.87,0.754264,0.065863,0.75,-0.754264,0.065863,0.87,-0.754264,-0.065863,0.75,-0.754264,-0.065863,0.87,-0.754264],\"q\":[{\"i\":[86,3,5,73],\"n\":[0.999596,0,-0.028415],\"f\":[\"sidehard\"],\"s\":[-1.500751,0.81,-0.648255,0.055354],\"uv\":[0.2624,0.0939,0.4713,0.0939,0.4713,0.1547,0.2624,0.1547]},{\"i\":[12,66,68,22],\"n\":[-0.099075,0,0.99508],\"f\":[\"sidehard\"],\"s\":[-1.409511,0.81,-0.751003,0.052146],\"uv\":[0.4961,0.3647,0.6715,0.3647,0.6715,0.4255,0.4961,0.4255]},{\"i\":[119,65,64,118],\"n\":[0.710664,0,0.703532],\"f\":[\"sidehard\"],\"s\":[-0.05618,0.81,-0.764045,0.051987],\"uv\":[0.2609,0.4255,0.1073,0.4255,0.1073,0.3647,0.2609,0.3647]},{\"i\":[13,119,118,14],\"n\":[0.230283,0,0.973124],\"f\":[\"sidehard\"],\"s\":[-0.075755,0.81,-0.751923,0.051151],\"uv\":[0.4707,0.4255,0.2609,0.4255,0.2609,0.3647,0.4707,0.3647]},{\"i\":[17,16,83,59],\"n\":[-0.999596,0,-0.028415],\"f\":[\"sidehard\"],\"s\":[1.500751,0.81,-0.648255,0.055354],\"uv\":[0.4991,0.2744,0.4991,0.2136,0.6713,0.2136,0.6713,0.2744]},{\"i\":[55,54,10,21],\"n\":[0.099075,0,0.99508],\"f\":[\"sidehard\"],\"s\":[1.409511,0.81,-0.751003,0.052146],\"uv\":[0.259,0.7041,0.259,0.6433,0.4717,0.6433,0.4717,0.7041]},{\"i\":[50,52,117,116],\"n\":[-0.710664,0,0.703532],\"f\":[\"sidehard\"],\"s\":[0.05618,0.81,-0.764045,0.051987],\"uv\":[0.8822,0.6433,0.8822,0.7041,0.6695,0.7041,0.6695,0.6433]},{\"i\":[116,117,9,11],\"n\":[-0.230283,0,0.973124],\"f\":[\"sidehard\"],\"s\":[0.075755,0.81,-0.751923,0.051151],\"uv\":[0.6695,0.6433,0.6695,0.7041,0.4934,0.7041,0.4934,0.6433]},{\"i\":[4,19,80,46],\"n\":[0.999596,0,0.028415],\"f\":[\"sidehard\"],\"s\":[-1.500751,0.81,0.648255,0.055354],\"uv\":[0.5006,0.1547,0.5006,0.0939,0.6734,0.0939,0.6734,0.1547]},{\"i\":[42,41,7,20],\"n\":[-0.099075,0,-0.99508],\"f\":[\"sidehard\"],\"s\":[-1.409511,0.81,0.751003,0.052146],\"uv\":[0.2597,0.5727,0.2597,0.5119,0.4719,0.5119,0.4719,0.5727]},{\"i\":[37,39,115,114],\"n\":[0.710664,0,-0.703532],\"f\":[\"sidehard\"],\"s\":[-0.05618,0.81,0.764045,0.051987],\"uv\":[0.8838,0.5119,0.8838,0.5727,0.6694,0.5727,0.6694,0.5119]},{\"i\":[114,115,6,8],\"n\":[0.230283,0,-0.973124],\"f\":[\"sidehard\"],\"s\":[-0.075755,0.81,0.751923,0.051151],\"uv\":[0.6694,0.5119,0.6694,0.5727,0.4955,0.5727,0.4955,0.5119]},{\"i\":[77,23,15,34],\"n\":[-0.999596,0,0.028415],\"f\":[\"sidehard\"],\"s\":[1.500751,0.81,0.648255,0.055354],\"uv\":[0.2618,0.2136,0.4709,0.2136,0.4709,0.2744,0.2618,0.2744]},{\"i\":[0,27,29,18],\"n\":[0.099075,0,-0.99508],\"f\":[\"sidehard\"],\"s\":[1.409511,0.81,0.751003,0.052146],\"uv\":[0.4925,0.7708,0.6675,0.7708,0.6675,0.8316,0.4925,0.8316]},{\"i\":[113,26,25,112],\"n\":[-0.710664,0,-0.703532],\"f\":[\"sidehard\"],\"s\":[0.05618,0.81,0.764045,0.051987],\"uv\":[0.2567,0.8316,0.0989,0.8316,0.0989,0.7708,0.2567,0.7708]},{\"i\":[1,113,112,2],\"n\":[-0.230283,0,-0.973124],\"f\":[\"sidehard\"],\"s\":[0.075755,0.81,0.751923,0.051151],\"uv\":[0.4721,0.8316,0.2567,0.8316,0.2567,0.7708,0.4721,0.7708]},{\"i\":[109,69,71,108],\"n\":[0.958174,0,-0.286185],\"f\":[\"pocket\"],\"s\":[-1.559394,0.81,-0.765048,0.053958],\"uv\":[0.0313,0.0939,0.0596,0.0939,0.0596,0.1547,0.0313,0.1547]},{\"i\":[107,109,108,106],\"n\":[0.708618,0,0.705593],\"f\":[\"pocket\"],\"s\":[-1.550086,0.81,-0.799284,0.054468],\"uv\":[0.0101,0.0939,0.0313,0.0939,0.0313,0.1547,0.0101,0.1547]},{\"i\":[74,107,106,87],\"n\":[-0.2408,0,0.970575],\"f\":[\"pocket\"],\"s\":[-1.516695,0.81,-0.809818,0.053582],\"uv\":[0.9653,0.3647,0.9948,0.3647,0.9948,0.4255,0.9653,0.4255]},{\"i\":[63,89,91,85],\"n\":[0.669927,0,0.742427],\"f\":[\"pocket\"],\"s\":[-0.027214,0.81,-0.832349,0.051402],\"uv\":[0.0592,0.4255,0.0328,0.4255,0.0328,0.3647,0.0592,0.3647]},{\"i\":[58,57,105,103],\"n\":[-0.958174,0,-0.286185],\"f\":[\"pocket\"],\"s\":[1.559394,0.81,-0.76504,0.053958],\"uv\":[0.9658,0.2744,0.9658,0.2136,0.9965,0.2136,0.9965,0.2744]},{\"i\":[103,105,104,102],\"n\":[-0.708618,0,0.705593],\"f\":[\"pocket\"],\"s\":[1.550086,0.81,-0.799284,0.054468],\"uv\":[0.0078,0.7041,0.0078,0.6433,0.0297,0.6433,0.0297,0.7041]},{\"i\":[102,104,61,84],\"n\":[0.2408,0,0.970575],\"f\":[\"pocket\"],\"s\":[1.516695,0.81,-0.809818,0.053582],\"uv\":[0.0297,0.7041,0.0297,0.6433,0.0606,0.6433,0.0606,0.7041]},{\"i\":[90,111,51,82],\"n\":[-0.669927,0,0.742427],\"f\":[\"pocket\"],\"s\":[0.027222,0.81,-0.832349,0.051402],\"uv\":[0.9911,0.6433,0.9911,0.7041,0.9641,0.7041,0.9641,0.6433]},{\"i\":[88,110,101,96],\"n\":[0,0,-1],\"f\":[\"pocket\"],\"s\":[0.000008,0.81,0.839957,0.053541],\"uv\":[0.0281,0.7708,0.0281,0.8316,0.007,0.8316,0.007,0.7708]},{\"i\":[45,44,100,98],\"n\":[0.958174,0,0.286185],\"f\":[\"pocket\"],\"s\":[-1.559394,0.81,0.765048,0.053958],\"uv\":[0.9659,0.1547,0.9659,0.0939,0.9975,0.0939,0.9975,0.1547]},{\"i\":[98,100,99,97],\"n\":[0.708618,0,-0.705593],\"f\":[\"pocket\"],\"s\":[-1.550086,0.81,0.799284,0.054468],\"uv\":[0.0082,0.5727,0.0082,0.5119,0.0314,0.5119,0.0314,0.5727]},{\"i\":[97,99,48,81],\"n\":[-0.2408,0,-0.970575],\"f\":[\"pocket\"],\"s\":[-1.516695,0.81,0.809818,0.053582],\"uv\":[0.0314,0.5727,0.0314,0.5119,0.0586,0.5119,0.0586,0.5727]},{\"i\":[96,101,38,79],\"n\":[0.669927,0,-0.742427],\"f\":[\"pocket\"],\"s\":[-0.027214,0.81,0.832349,0.051402],\"uv\":[0.9921,0.5119,0.9921,0.5727,0.9645,0.5727,0.9645,0.5119]},{\"i\":[95,30,32,94],\"n\":[-0.958174,0,0.286185],\"f\":[\"pocket\"],\"s\":[1.559394,0.81,0.765048,0.053958],\"uv\":[0.0319,0.2136,0.0593,0.2136,0.0593,0.2744,0.0319,0.2744]},{\"i\":[93,95,94,92],\"n\":[-0.708618,0,-0.705593],\"f\":[\"pocket\"],\"s\":[1.550086,0.81,0.799284,0.054468],\"uv\":[0.0074,0.2136,0.0319,0.2136,0.0319,0.2744,0.0074,0.2744]},{\"i\":[35,93,92,78],\"n\":[0.2408,0,-0.970575],\"f\":[\"pocket\"],\"s\":[1.516695,0.81,0.809818,0.053582],\"uv\":[0.9652,0.7708,0.9897,0.7708,0.9897,0.8316,0.9652,0.8316]},{\"i\":[89,111,90,91],\"n\":[0,0,1],\"f\":[\"pocket\"],\"s\":[0,0.81,-0.839948,0.053541],\"uv\":[0.0328,0.4255,0.008,0.4255,0.008,0.3647,0.0328,0.3647]},{\"i\":[24,110,88,76],\"n\":[-0.669927,0,-0.742427],\"f\":[\"pocket\"],\"s\":[0.027222,0.81,0.832349,0.051402],\"uv\":[0.0595,0.8316,0.0281,0.8316,0.0281,0.7708,0.0595,0.7708]},{\"i\":[74,87,67,75],\"n\":[-0.679991,0,0.733221],\"f\":[\"sidesoft\"],\"s\":[-1.479715,0.81,-0.787997,0.056189],\"uv\":[0.9653,0.3647,0.9653,0.4255,0.8834,0.4255,0.8834,0.3647]},{\"i\":[72,86,73,70],\"n\":[0.894696,0,-0.446676],\"f\":[\"sidesoft\"],\"s\":[-1.511144,0.81,-0.691227,0.054652],\"uv\":[0.109,0.0939,0.2624,0.0939,0.2624,0.1547,0.109,0.1547]},{\"i\":[69,72,70,71],\"n\":[0.731509,0,-0.681831],\"f\":[\"sidesoft\"],\"s\":[-1.537273,0.81,-0.728305,0.055604],\"uv\":[0.0596,0.0939,0.109,0.0939,0.109,0.1547,0.0596,0.1547]},{\"i\":[66,75,67,68],\"n\":[-0.440501,0,0.897752],\"f\":[\"sidesoft\"],\"s\":[-1.442443,0.81,-0.761579,0.054268],\"uv\":[0.6715,0.3647,0.8834,0.3647,0.8834,0.4255,0.6715,0.4255]},{\"i\":[63,85,64,65],\"n\":[0.978031,0,0.208461],\"f\":[\"sidesoft\"],\"s\":[-0.041071,0.81,-0.799284,0.056473],\"uv\":[0.0592,0.4255,0.0592,0.3647,0.1073,0.3647,0.1073,0.4255]},{\"i\":[53,84,61,62],\"n\":[0.679991,0,0.733221],\"f\":[\"sidesoft\"],\"s\":[1.479715,0.81,-0.787997,0.056189],\"uv\":[0.1,0.7041,0.0606,0.7041,0.0606,0.6433,0.1,0.6433]},{\"i\":[59,83,60,56],\"n\":[-0.894696,0,-0.446676],\"f\":[\"sidesoft\"],\"s\":[1.511144,0.81,-0.691227,0.054652],\"uv\":[0.6713,0.2744,0.6713,0.2136,0.8844,0.2136,0.8844,0.2744]},{\"i\":[56,60,57,58],\"n\":[-0.731509,0,-0.681831],\"f\":[\"sidesoft\"],\"s\":[1.537273,0.81,-0.728305,0.055604],\"uv\":[0.8844,0.2744,0.8844,0.2136,0.9658,0.2136,0.9658,0.2744]},{\"i\":[53,62,54,55],\"n\":[0.440501,0,0.897752],\"f\":[\"sidesoft\"],\"s\":[1.442443,0.81,-0.761579,0.054268],\"uv\":[0.1,0.7041,0.1,0.6433,0.259,0.6433,0.259,0.7041]},{\"i\":[50,82,51,52],\"n\":[-0.978031,0,0.208461],\"f\":[\"sidesoft\"],\"s\":[0.041071,0.81,-0.799284,0.056473],\"uv\":[0.8822,0.6433,0.9641,0.6433,0.9641,0.7041,0.8822,0.7041]},{\"i\":[40,81,48,49],\"n\":[-0.679991,0,-0.733221],\"f\":[\"sidesoft\"],\"s\":[-1.479715,0.81,0.787997,0.056189],\"uv\":[0.0992,0.5727,0.0586,0.5727,0.0586,0.5119,0.0992,0.5119]},{\"i\":[46,80,47,43],\"n\":[0.894696,0,0.446676],\"f\":[\"sidesoft\"],\"s\":[-1.511144,0.81,0.691227,0.054652],\"uv\":[0.6734,0.1547,0.6734,0.0939,0.8852,0.0939,0.8852,0.1547]},{\"i\":[43,47,44,45],\"n\":[0.731509,0,0.681831],\"f\":[\"sidesoft\"],\"s\":[-1.537273,0.81,0.728305,0.055604],\"uv\":[0.8852,0.1547,0.8852,0.0939,0.9659,0.0939,0.9659,0.1547]},{\"i\":[40,49,41,42],\"n\":[-0.440501,0,-0.897752],\"f\":[\"sidesoft\"],\"s\":[-1.442443,0.81,0.761579,0.054268],\"uv\":[0.0992,0.5727,0.0992,0.5119,0.2597,0.5119,0.2597,0.5727]},{\"i\":[37,79,38,39],\"n\":[0.978031,0,-0.208461],\"f\":[\"sidesoft\"],\"s\":[-0.041071,0.81,0.799284,0.056473],\"uv\":[0.8838,0.5119,0.9645,0.5119,0.9645,0.5727,0.8838,0.5727]},{\"i\":[35,78,28,36],\"n\":[0.679991,0,-0.733221],\"f\":[\"sidesoft\"],\"s\":[1.479715,0.81,0.787997,0.056189],\"uv\":[0.9652,0.7708,0.9652,0.8316,0.8814,0.8316,0.8814,0.7708]},{\"i\":[33,77,34,31],\"n\":[-0.894696,0,0.446676],\"f\":[\"sidesoft\"],\"s\":[1.511144,0.81,0.691227,0.054652],\"uv\":[0.1086,0.2136,0.2618,0.2136,0.2618,0.2744,0.1086,0.2744]},{\"i\":[30,33,31,32],\"n\":[-0.731509,0,0.681831],\"f\":[\"sidesoft\"],\"s\":[1.537273,0.81,0.728305,0.055604],\"uv\":[0.0593,0.2136,0.1086,0.2136,0.1086,0.2744,0.0593,0.2744]},{\"i\":[27,36,28,29],\"n\":[0.440501,0,-0.897752],\"f\":[\"sidesoft\"],\"s\":[1.442443,0.81,0.761579,0.054268],\"uv\":[0.6675,0.7708,0.8814,0.7708,0.8814,0.8316,0.6675,0.8316]},{\"i\":[24,76,25,26],\"n\":[-0.978031,0,-0.208461],\"f\":[\"sidesoft\"],\"s\":[0.041071,0.81,0.799284,0.056473],\"uv\":[0.0595,0.8316,0.0595,0.7708,0.0989,0.7708,0.0989,0.8316]},{\"i\":[15,23,16,17],\"n\":[-1,0,0],\"f\":[\"sidehard\"],\"uv\":[0.4709,0.2744,0.4709,0.2136,0.4991,0.2136,0.4991,0.2744]},{\"i\":[12,22,13,14],\"n\":[0,0,1],\"f\":[\"sidehard\"],\"uv\":[0.4961,0.3647,0.4961,0.4255,0.4707,0.4255,0.4707,0.3647]},{\"i\":[9,21,10,11],\"n\":[0,0,1],\"f\":[\"sidehard\"],\"uv\":[0.4934,0.7041,0.4717,0.7041,0.4717,0.6433,0.4934,0.6433]},{\"i\":[6,20,7,8],\"n\":[0,0,-1],\"f\":[\"sidehard\"],\"uv\":[0.4955,0.5727,0.4719,0.5727,0.4719,0.5119,0.4955,0.5119]},{\"i\":[3,19,4,5],\"n\":[1,0,0],\"f\":[\"sidehard\"],\"uv\":[0.4713,0.0939,0.5006,0.0939,0.5006,0.1547,0.4713,0.1547]},{\"i\":[0,18,1,2],\"n\":[0,0,-1],\"f\":[\"sidehard\"],\"uv\":[0.4925,0.7708,0.4925,0.8316,0.4721,0.8316,0.4721,0.7708]}],\"nt\":\"cushion-normal-map.png\"}"),
	tunnel: {
		p: [
			1.619456,
			.7543,
			-.869552,
			1.540653,
			.4733,
			.836027,
			1.540653,
			.4733,
			-.836027,
			-1.540653,
			.4733,
			.836027,
			-1.619456,
			.7543,
			-.869552,
			-1.540653,
			.4733,
			-.836027,
			-1.619456,
			.7543,
			.869552,
			1.619456,
			.7543,
			.869552
		],
		q: [
			{
				i: [
					3,
					5,
					2,
					1
				],
				n: [
					0,
					1,
					0
				],
				f: ["tunnel", "end"]
			},
			{
				i: [
					5,
					4,
					0,
					2
				],
				n: [
					0,
					.118464,
					.992958
				],
				f: ["tunnel"]
			},
			{
				i: [
					6,
					3,
					1,
					7
				],
				n: [
					0,
					.118464,
					-.992958
				],
				f: ["tunnel"]
			},
			{
				i: [
					3,
					6,
					4,
					5
				],
				n: [
					.962855,
					.270018,
					0
				],
				f: ["tunnel"]
			},
			{
				i: [
					0,
					7,
					1,
					2
				],
				n: [
					-.962855,
					.270018,
					0
				],
				f: ["tunnel"]
			}
		]
	},
	ground: {
		p: [
			1.473037,
			.75,
			-.75,
			1.473037,
			.75,
			.75,
			-1.473037,
			.75,
			.75,
			-1.5,
			.75,
			.722996,
			-1.5,
			.75,
			-.722996,
			-1.473037,
			.75,
			-.75,
			1.5,
			.75,
			-.722996,
			1.5,
			.75,
			.722996
		],
		q: [{
			i: [
				2,
				3,
				4,
				5,
				0,
				6,
				7,
				1
			],
			n: [
				0,
				1,
				0
			],
			f: ["ground"]
		}]
	}
}, Et = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAACXBIWXMAAAsTAAALEwEAmpwYAAAgAElEQVR4Ae3d244sS3oQ4OpetQ9jj3zgSXgFjDE+gngBLpExlrFBiNu+REKyjQU2DwFC4CODeSXssbbH+7S6iT86/1xR2Vld1b2qZ1dkfKnJjsjIyMiIL2pP/JXVq+tmt9s9lN1GgAABAgQIDCRwO9BYDZUAAQIECBCYBAQAXgoECBAgQGBAAQHAgJNuyAQIECBAQADgNUCAAAECBAYUEAAMOOmGTIAAAQIEBABeAwQIECBAYEABAcCAk27IBAgQIEBAAOA1QIAAAQIEBhQQAAw46YZMgAABAgQEAF4DBAgQIEBgQAEBwICTbsgECBAgQEAA4DVAgAABAgQGFBAADDjphkyAAAECBAQAXgMECBAgQGBAAQHAgJNuyAQIECBAQADgNUCAAAECBAYUEAAMOOmGTIAAAQIEBABeAwQIECBAYEABAcCAk27IBAgQIEBAAOA1QIAAAQIEBhQQAAw46YZMgAABAgQEAF4DBAgQIEBgQAEBwICTbsgECBAgQEAA4DVAgAABAgQGFBAADDjphkyAAAECBAQAXgMECBAgQGBAAQHAgJNuyAQIECBAQADgNUCAAAECBAYUEAAMOOmGTIAAAQIEBABeAwQIECBAYEABAcCAk27IBAgQIEBAAOA1QIAAAQIEBhQQAAw46YZMgAABAgQEAF4DBAgQIEBgQAEBwICTbsgECBAgQEAA4DVAgAABAgQGFBAADDjphkyAAAECBAQAXgMECBAgQGBAAQHAgJNuyAQIECBAQADgNUCAAAECBAYUEAAMOOmGTIAAAQIEBABeAwQIECBAYEABAcCAk27IBAgQIEBAAOA1QIAAAQIEBhQQAAw46YZMgAABAgQEAF4DBAgQIEBgQAEBwICTbsgECBAgQEAA4DVAgAABAgQGFBAADDjphkyAAAECBAQAXgMECBAgQGBAAQHAgJNuyAQIECBAQADgNUCAAAECBAYUEAAMOOmGTIAAAQIEBABeAwQIECBAYEABAcCAk27IBAgQIEBAAOA1QIAAAQIEBhQQAAw46YZMgAABAgQEAF4DBAgQIEBgQAEBwICTbsgECBAgQEAA4DVAgAABAgQGFBAADDjphkyAAAECBAQAXgMECBAgQGBAAQHAgJNuyAQIECBAQADgNUCAAAECBAYUEAAMOOmGTIAAAQIEBABeAwQIECBAYEABAcCAk27IBAgQIEBAAOA1QIAAAQIEBhQQAAw46YZMgAABAgT2S4L/9O3d7uFmt3tf9m9iLxW+Lnuk3zxM+Ujvd7uvSvrV+8f9y0i/3e2+LBW/Khd8XdKvS/rNtH9bjt9P+32pF/tDpOW6h9LWruw1LW3uYo9kSh+PHn/elD7VbZHW8iib9nq6/LiJECfLVtI8n9e3aZuPNuL4VFl7fs5HFxbXRleetLmsNx3Xeiv52n5eU9K23nPnatXoz+Ka6fBxjNFc1mnzU9nBtafama6fqh3et712mZ+uq/eK/JHj6bLHdtfqTBXq9ZEv25wvmcjHNpdlfjpx7Px8zUq9PLdM27bquRdcm221bUQ+9zh/ztZen/WzLI7PyR+r9+y15b/ntfNZlmnbdpZlOp9r2spzmc51SibLbqb/L5mPo9K0HZSd0+5KnWhqbue5ey3OrV13UBYHsTX3jMP5XtO5tuwg31yX19TzUz8O6paDdDqnvLa3Np61tpt+zG0/c+2zfV1c96TPLzyf6017z6V39Lnd2rHX8uni6dZt1Zqv5W2dks+ySGPNndPIl/1+2nM9juP3ZT2LtbnuJf9t2es6XdKvS3nsX077V6Xdr0uj35b9vuy/u78rJYdbuezDFou/jQABAgQIENiGQA0sylB+e2V9nwMAi/82JtsoCBAgQIBACMTiH1sGAb+1CAJqAGDxf0TykwABAgQIbEFgufhnEPCbTRBw+wfloHxkYCNAgAABAgQ2JJCL/jL9jSkIuM3FP9MNjd1QCBAgQIDA0ALLxT+Pf70EAfUjgFz8Mx1ay+AJECBAgMAGBGKxjy0X/WX65AmAIOARzE8CBAgQINCrwKnFP87XACAX/WXa68D1mwABAgQIjC6wfMffHsef35kDgOXin8ejAxo/AQIECBDoVaBd9DM//e293X650EeFZVmvA9dvAgQIECAwqkAu+G2ai3/8dcB9/BZgFLRbVLYRIECAAAECfQscW/xrABDv9pdBgCcAfU+43hMgQIAAgecW/zg3fwSwDALQESBAgAABAn0LxELfPvaPd/4ZGMx/ByCfBETqCUDfE673BAgQIEAgF/oaAJSDdvEPnRoARCYX/rkgCm0ECBAgQIBAtwIRBMTCv1z8Y0D7dlQZBLRlr83HTWPL9PFo+rksXB4fVHZAgAABAgQIvFbg2yNrrDf8rxV1HQECBAgQuGKBUx/nCwCuePJ0jQABAgQIvJWAAOCtZLVLgAABAgSuWEAAcMWTo2sECBAgQOCtBAQAbyWr3eMCpz6YOn6lMwQIECBwIQEBwIUgNfMCgSO/kfqCFlQlQIAAgY8UEAB8JKDLXyHgCcAr0FxCgACBlwmceq8lAHiZp9qXEDj1qrzEPbRBgACBwQVOvdcSAAz+AjF8AgQIEBhTQAAw5rwbNQECBAgMLiAAGPwF8J0M/9Rzqe+kU25KgACBsQQEAGPN93WM1u8AXMc86AUBAkMLCACGnn6DJ0CAAIFRBQQAo868cRMgQIDA0AICgKGn3+AJECBAYFQBAcCoM2/cBAgQIDC0gABg6Ok3eAIECBAYVUAAMOrMf5fj9s8Av0t99yZAYBCBU//gSgAwyAvhqoZ56lV5VZ3VGQIECPQpcOq9lgCgz3nVawIECBAg8KzAqfdaAoBn+ZwkQIAAAQLbFBAAbHNejYoAAQIEBhfwEcDgLwDDJ0CAAAECawKeAKypKCNAgAABAhsXEABsfIINjwABAgQIrAkIANZUlBEgQIAAgY0LCAA2PsFXObxTv5lylZ3WKQIECGxLQACwrfnsYzSn/nFqH6PQSwIECFy1wKn/qxUAXPX06RwBAgQIEHidwKmHrQKA17m6igABAgQIdC1wEADE44L7Cw0nI49MD5pdFi6PDyo7IECAAAECBF4rsC9rbCz2y6V2nw3G4n/JACDblRIgQIAAAQLfjUAs+rfTyn8//VLAlOxqANAu/pn/brrqrgQIECBAgMClBGoAEI2tBAH7XPDj0X/mL3Vj7RAgQIAAAQLfncAcAEQXFkFADQDaxV8Q8N1NlDsTIECAAIFLCcR6n/v8C39NELC3+F+KWjsECBAgQOC6BDIAiF4tg4D5I4D2nX/kbQQIECBAgEC/Arn4T2/660DaIOAgAIizufhn2u/Q9ZwAAQIECIwtkEFAq5BBwBwAxMlc9DNtL5AnQIAAAQIE+hHIxb99ApC9jyCgBgBRkIt+pllJSoAAAQIECPQlkIt+BgFrvZ//DkCctPivESkjQIAAAQL9CbRBwFrvnzwBWKukjAABAgQIEOhP4NgTgD/a3+1uf6v88M6/v0nVYwIECBAg8JxALv7L9A/3d/Wy+suA/3o6qCV+ECBAgAABAl0LtI//2wDgP+/v5nHlvwbYCQJmExkCBAgQINC9wDII+IP93cGY5gAgSgUBBzYOCBAgQIBA1wL57v/393dPxhHn/ArAExYFBAgQIEBg2wIHTwC2PVSjI0CAAAECBFKg/h2APIj07/383e6mfEPQu2/L/vVu98mXj/tnX+12n5fjun+z232v7D9R6nzvfUlL/Z8ozxG+F3tp4/PyXOGzaf+0pJ+WMOOTad9HWsrelXTey/FtOb4t6U27R4fiONJpq/mp4GHl2UVbVk+XHwdpaSfq1LIpH03ndWt16/npx3zdqeOpYtav1Rdlec+5/ZLJsryupsvrFveery/1Dq6LE2VbbbOeeFp/vj4zcX3ULducTpk8Pjg3HRw9l+2UCifrLNrK+pk+uW8UlK2eLz/Oqpf165Xr18xtTpm1dg/qlIO2zvLcxx63bbf5aPfUFvXbPern8Vr+SVn+tzdd9+T8Wnm5Ju8RaWx5XPPN+fbcw1S+LDt1fHCPZRvtvZp83Gtud5Gf25vq13pr+ams1l/Jx/+RzePOfEnzvvP5LGvSgzazPC4s+dpmlkW6VlaKZ8/pfK3X5rO9aKNsB/Wbsmw/r8+6ryo/0u5q21Pd+Vw5znlryw76E9csr4sKeW17biqPpF4znZvvkeW1wlQn8yXNOWqKnmRvaqWsPJ0uZbW8TuSUL2tqlMVaXPeyzt6U/Tb3svbexhpd1uF9Sfcl/aSsz5+WNPbPYi/ln5T676a2/uKLuyf9Kcvuh+1n/9HdPIi1fn6oKUeAAAECBAj0IBCxzC99/+5JV+cA4Gd+YbH4lysyCHhylQICBAgQIEDg6gWmBxn1ocYvL4KAGgD89C+WxT9q5aLfpFc/Oh0kQIAAAQIEngi0i3+cjONfaYKA25/65Wbxj7MW/3CyESBAgACBbgXWFv8YTJT/6hQE7OOdfxTE4/45jYyNAAECBAgQ6FYgl/InaVnw/8lP3u32+Y5/XvzLUA9+67Hboes4AQIECBAYW2Bt8Y+y+FcG608AyklBwNgvGqMnQIAAgW0IzEFAWfRz8Y+0BgAxxDiYPwaYasexjQABAgQIEOhTYFrOH/+uQBlC/fsCUzoHADG0OQgomVz8M43zNgIECBAgQKAPgecW/zi3f4h/CFj+UlBuGQTk7wZkuZQAAQIECBDoS6B9xx/rex7flnf3+4d302DaIKDU8s6/r0nWWwIECBAgcCAwLeS56Gcai3/kH58A5BVTEOAXABNESoAAAQIEOhQ4sfg/fgQQP+c/CFzyJQgQAHQ42bpMgAABAgRagUUQkO/8Y9mPbf47AAdBgI8AHnX8JECAAAECHQssH/vn4h9Devw64FzwpycBD+WrBOs2RQ/TkYQAAQIECBDoSCAW/OU7/+z+YwAQRxEExF6CgPp7gbn4ZzpdsTjMdqQECBAgQIDAFQpEALC2tZ/+r51XRoAAAQIECGxQQACwwUk1JAIECBAgcEpAAHBKyHkCBAgQILBBAQHABifVkAgQIECAwCkBAcApIecJECBAgMAGBQQAG5xUQyJAgAABAqcEBACnhJwnQIAAAQIbFBAAbHBSDYkAAQIECJwSEACcEnL+qED8hSkbAQIECPQpIADoc970mgABAgQIfJSAAOCj+FxMgAABAgT6FBAA9Dlvek2AAAECBD5KQADwUXwuJkCAAAECfQoIAPqcN70mQIAAAQIfJSAA+Cg+FxMgQIAAgT4FBAB9zpteEyBAgACBjxIQAHwUn4sJECBAgECfAgKAPuftKnr9cBW90AkCBAgQeI2AAOA1aq6pAv4SoBcCAQIE+hUQAPQ7d3pOgAABAgReLSAAeDWdC30E4DVAgACBfgUEAP3OnZ4TIECAAIFXCwgAXk3nQgIECBAg0K+AAKDfudNzAgQIECDwagEBwKvpXEiAAAECBPoVEAD0O3d6ToAAAQIEXi0gAHg1nQsJECBAgEC/AgKAfudOzwkQIECAwKsFBACvpnMhAQIECBDoV0AA0O/c6TkBAgQIEHi1gADg1XQuJECAAAEC/Qrs566Xv+t6E/v9VJLf9JLponi+ToYAAQIECBC4WoH7so7X9X3Rw8cnAM3if/O+VMxKcyYLpAQIECBAgEAvAvGdLREAPMS+6PRtlOQ7/7r4xxOAKFtUdEiAAAECBAj0JZAL/1oQcLtc/OvxMkzoa7x6S4AAAQIECEzv5I8FAbfxmX++88/FP1IbAQIECBAg0KnAYvFfCwL2q4u/jwA6nXHdJkCAAAECk0ATBNRfAIjjsr7HxwHxC4D7+gQgFvxpnz//FwR4DREgQIAAga4F6jv/sp7XX+xr0ggC9rnw18f+yyBguqbr0es8AQIECBAYUCDW+9giCGifAGQwMAcA9Z1/1M4goGTjGhsBAgQIECDQp0As63X9XwkC6r8CmBf9dvGPq2wECBAgQIBA1wK5nOcvAmY6/x2AtSCg6xHrPAECBAgQGFxgXvwnh1z8I11/ApBXDA5n+AQIECBAoFeBXMqfpGXx/19/e7e7/Zs/u6v/AuDgCUCMNq/odeT6TYAAAQIEBhXIJXwt/ZMv7qpK/S6AH/5FEwREcbkifl9AEBAINgIECBAg0J/A2uL/p9PiH6OZvw74r39QgoAoaRb/ehxlNgIECBAgQKA7gTYI+LNm8Y+BzAFAHPzV/1kEAaVMEBAyNgIECBAg0KdABAF/vlj8YySxvmeAEMc2AgQIECBAYACBgycAA4zXEAkQIECAAIEiIADwMiBAgAABAgMKCAAGnHRDJkCAAAEC+yXBF+UXAR9KWPD+3W73zaeP+1ef73Zff7bbfVmOvyp7pH9XrvzRJ2Uv9f627D8q1/yo/EbBj0qDf1d+q+DLsn8V+325tuzflPw3Jf222d+XfOz3sZfzsT80afQtjsv/6o+aRn6x5S8q3kyZNo18FB+UTcerZVPbx66L0/N1Td1aPh3XfHaqKWuzx05n27WN5oIsb69ry7K8LattlBPzuam9qHNQNh2fLCvXP7k2ypp2IzsfN/mD8qlC1js4FwfT9uT8M9fFJW395fFz556tu3LPZf2147WyZR/OqdNe81y+PRftntqifu5Rd5k/WVb+Y1xeE8dr19Xypv6y3rPnp+vadusXmD3e6rEPTdu13jPH9UvPSqW450E7x64p5bFl/TY/j2O6tp7L+ouy5RiX/9qqPZ/nln1dbT/vM6XzNW0/mny28eR+TZ35XFOW1x30rZxfrXtueVMv261p3Lc5V8cUZWXLfI6zrf/k/OKats3It/UPjuPEdD7T+X7tuWW+HB/Ui/PLrYBl0494pUIgRnnFnPJlPY11OJ7RRxr7fVlnH8oe6X1Zf2N/X/Zvyzqc+9clf7DH+djj2tL+r3x+Vxr9sMUt5u2L/31XapXD7GGmcw0ZAgQIECBA4NoFcvlu0z/58u6g23MA8MWflxNRs90PqjogQIAAAQIEehFoF//ocxz/cRME1ADgiz+9O1z486q4wkaAAAECBAh0KZDLeZv+zykI2H/xx3ePi/9yaFl7We6YAAECBAgQ6EYgl/NIc/8fJQjYxy8t5Ml5NFmQ6XxChgABAgQIEOhFIJfxSJf7Pkrilw+zUh1U1uplhPpJgAABAgQIHAjkup5L+jKdnwAcBAF51UFTDggQIECAAIEeBHIZXy767fHBEwBBQA/Tqo8ECBAgQOC0wKkg4Pam/BGe+jHAFBbUP2TQXnX6HmoQIECAAAECVyjQLufTMj//LsC+BgCl0/GXhvIJwEEQcIUD0iUCBAgQIEDgPIHlwp/H+5v3HxqYg4ByNoIBGwECBAgQINC3QC74bRoP/+cnADm8GgRkrSyUEiBAgAABAt0JxHIeWy7rkdZP/su7/MdfAoyjZosv4LERIECAAAEC/QusLf5RVgOAGF7+LkDNCwCCwUaAAAECBLoXyAAg3/nnEl++KLBs09EcBOTZ7odtAAQIECBAYGyBWNKXi3+IPAYAkYsaZZ+DgCizESBAgAABAt+dwLE35G15mz/S0/uV3+yfvw74yDWKCRAgQIAAgQ0KCAA2OKmGRIAAAQIETgkIAE4JOU+AAAECBDYoIADY4KQaEgECBAgQOCUgADgl5DwBAgQIENiggABgg5NqSAQIECBA4JSAAOCUkPMECBAgQGCDAgKADU6qIREgQIAAgVMCAoBTQs4TIECAAIENCggANjiphkSAAAECBE4JCABOCTlPgAABAgQ2KCAA2OCkGhKBngTO+DPmPQ1HXwl0IyAA6GaqdJQAAQIECFxOQABwOUstESBAgACBbgQEAN1MlY4SIECAAIHLCQgALmepJQIECBAg0I2AAKCbqdJRAgQIECBwOQEBwOUstUSAAAECBLoREAB0M1U6SoAAAQIELicgALicpZYIECBAgEA3AgKAbqZKRwkQIECAwOUEBACXs9QSAQIECBDoRkAA0M1U6SgBAgQIELicgADgcpZaIkCAAAEC3QgIALqZKh0lQIAAAQKXExAAXM5SSwQIECBAoBsBAUA3U6WjBLYpcLPNYRkVgasXEABc/RTpIAECBAgQuLyAAODyplokQIAAAQJXLyAAuPop0kECBAgQIHB5gf3cZHwQV/YHIcFMIkOAAAECBL5TgWO/JNOWt/kjnb19KOt7rPHN+cflPi6OE+Xo4d1jvqkjS4AAAQIECHQqEEt8LPY3ZfWPfG639ahZ/GsQ0NbImlICBAgQIECgO4FY0mNfBgE1AMh3/jWtNbobnw4TIECAAAECKwIZACyDgP3a4h+fExw8J1hpUBEBAgQIECBw3QKxnMeWaeTjff59+ThgH5/5t+/8c/Fvf1EgLrARIECAAAEC/QmsvaePIODxCcD02H9e/Ndq9zdmPSZAgAABAsMLHFvSawAQzwZWF/+4ykaAAAECBAh0KZDLeKbtIPYW/5ZDngABAgQIbEMgF/1IM9+ObP/knf+xmu1V8gQIECBAgMDVCuSCn0t6HrcdPngCUEOE52q3V8oTIECAAAECVyuQi34u68uOzk8AVhf/vHp5lWMCBAgQIEDg6gVyGc+07fDt93/t7vHDgQwRslambW15AgQIECBAoCuBXM7bZf6ffX5X/x7A7vu/crceBHQ1RJ0lQIAAAQIEWoF28Y/yOP6nZfGPLf4CQN2+/0t3goDJQkKAAAECBHoXWFv8f21a/GNscwAQB9//x3cfgoAoyKsjbyNAgAABAgS6EMjlu01/tVn8YxBxzl/97WI6dZIAAQIECFxO4OAJwOWa1RIBAgQIECBwzQICgGueHX0jQIAAAQJvJCAAeCNYzRIgQIAAgWsWEABc8+zoGwECBAgQeCMBAcAbwWqWAAECBAhcs4AA4JpnR98IECBAgMAbCQgA3ghWswQIECBA4JoFBADXPDv6RoAAAQIE3khAAPBGsJolQIAAAQLXLCAAuObZ0TcCBAgQIPBGAgKAN4LVLAECBAgQuGaB/bJzv7m/292Ubwe4Lfu7su/L/kmpFHtUrvnyDQKflv2TKf2shBGfvyt7qVD3Uunzsn/26eP+yWelbsnvy/6ulMd+W+rGflOuq3tp4ybCkdLmTdnrtxREvmQff0Tmw/ZQ+jVvmZ/Sei7y016Ly49afv9YnnVW01InytfOnSprzx/ko7NTmwflUbZ2Lqq3fZiOaxvtuSZ/0E4pP6ibx9P9ah/y2jz3eMnBdfXUdM1BPttpr60deBzP3H60+Uz5dOpxrNFW2aJsec1cb3luuqBeE/myPbl+Kps9aq3HerV+ueCg/eZ8249at/x4Undx/Vq9LHuSLq5t217Wbc+t5aP+uVtcn3tck+2dmz+n3pM263/MH+715PyRfmS9TOd7l/aybJnOdZo2a50jfXhy/TNtZ934/6XML9N6/yP3Wjt30N/puoOyOIht5Z5RXO9/7H7NNXPdyJTt4di9Fm0dq3u0/Mg91+7XjulYe0+uW/avud+aRXuPY+frveNHbk2bWdSmbTu1vBasLlf1dKyruUX38zjSOpxIp3ysv5Fv01iPb8valGvzu5LPNXpf8p+U85+U9NOSxl6W3d1nUxpr9b7ssbb+2/d32Y3DbwP8V/sPJ+YaMgQIECBAgEC3AjXAKL2P9Hff3c3jmD8C+I39Y2EJGGwECBAgQIDABgTaxT+GE8e/NwUBNQD4l/u7UvT0cVYt9IMAAQIECBDoVmAtCPj9EgTc/vr+rg4q3/kv025HrOMECBAgQIBAFVgLAuoTgOWivzzmR4AAAQIECPQt0AYBkY9fKKzbsXQ6LSFAgAABAgQ6FVgu/nMAYPHvdEZ1mwABAgQInBBYW/wPAoBlEHCiPacJECBAgACBTgRiwV/u8Xd+DraosCw7qOCAAAECBAgQ6EpgufjH8ZMAIEYkCOhqXnWWAAECBAgcFYg1PbZlELAaAHgC8IjlJwECBAgQ2ILAcvGPfwK4GgBsYbDGQIAAAQIECHwQyCAgFv+jAYAnAB/A5AgQIECAQO8Cy8X/thTEF/z5pb/eZ1b/CRAgQIDAMwIRAOQ7/1j847gGAHFN+66/zce5s7dXX3j2HVQkQIAAAQIEXigwBwDT4h+XzwFAHMT6/dFr+Ec3ED2xESBAgAABAi8VyCU40/b6dxEFNFs8EbARIECAAAECgwkIAAabcMN9/OyLAwECBEYXEACM/gowfgIECBAYUkAAMOS0GzQBAgQIjC4gABj9FWD8BAgQIDCkgABgyGk3aAIECBAYXUAAMPorwPgJECBAYEgBAcCQ027QBAgQIDC6gABg9FeA8RMgQIDAkAICgCGn3aAJECBAYHQBAcDorwDjJ0CAAIEhBQQAQ067QRMgQIDA6AICgNFfAcZPgAABAkMKCACGnHaDJkCAAIHRBQQAo78CjJ8AAQIEhhQQAAw57QZNgAABAqMLCABGfwUYPwECBAgMKSAAGHLaDZoAAQIERhcQAIz+CjB+AgQIEBhSQAAw5LQbNAECBAiMLiAAGP0VYPwECBAgMKSAAGDIaTdoAgQIEBhdQAAw+ivA+AkQIEBgSAEBwJDTbtAECBAgMLqAAGD0V4DxEyBAgMCQAgKAIafdoAkQIEBgdAEBwOivAOMnQIAAgSEFBABDTrtBEyBAgMDoAgKA0V8Bxk+AAAECQwoIAIacdoMmQIAAgdEFDgKAm6JxUPAanWjERoAAAQIECPzYBXIJzrTtwPuH3a78b97m9T4qt/tc4yWZtTu+5Hp1CRAgQIAAgYsLxMJ/H3sTBOzjLu3Cbw0PERsBAgQIENiOQAYAdUTl4LYs9vvl4p/H2xm2kRAgQIAAgbEFIgBYBgGrAcDYTEZPgAABAgS2JxABQGzxUUBsqwGAjwEecfwkQIAAAQJbEMgnADmWCAJWA4CoIAhIJikBAgQIEOhXIN/5Z5ojeRIAxAmLf/JICRAgQIBA/wLLJwAxotB6xgEAABCcSURBVIMAIAos/qFgI0CAAAEC2xF4NgCIYebin+l2hm4kBAgQIEBgTIF89J9pKtQnAHGQi/4yzYpSAgQIECBAoE+BWPxjfW+DgPqXAJeL/vK4z+HqNQECBAgQIJACufhHGvvtf/32rp5bLvp5XE/6QYAAAQIECHQr0C7+MYgaAETmj44EAXHORoAAAQIECPQrsLb4//b7uw9f/veHiyCg36HqOQECBAgQIBACa4v/75TFP7b52wDj4L9MQUDkbQQIECBAgED/Am0Q8G+mxT9GFR/157n+R2kEBAgQIECAwFkCB08AzrpCJQIECBAgQKB7AQFA91NoAAQIECBA4OUCAoCXm7mCAAECBAh0LyAA6H4KDYAAAQIECLxcQADwcjNXECBAgACB7gUEAN1PoQEQIECAAIGXCwgAXm7mCgIECBAg0L2AAKD7KTQAAgQIECDwcgEBwMvNXEGAAAECBLoXEAB0P4UGQIAAAQIEXi4gAHi5mSsIECBAgED3AgKA7qfQAAgQIECAwMsFBAAvN3MFAQIECBDoXkAA0P0UGgABAgQIEHi5wH55yT/44d3uvnxB8Pv3u93X3+x2X8X+dcl/Ne1f7nbfxP53u923Pyr1yn7/t2Uv6UPZd6X8JvZS56Zcc1uuvS1t3JQ90ttvy17ajv0m0/tyXPab3Mv9b+JLiqe05sthpie/wLh8yXFcXr/sOJqJLz2eyuZ8U1bPxfmVsrU2atnU3sH55T3jOLZod2Vr+7hy+uC62reolG2t3b89F/npOMcVxy/N70qI2F6zbKPeY7rXQR+b+891sv9tv7KsTdv8VDeKajs1M/1oz51T3tb5ceSP9e+cez937fLc8vic9tfqHGvnWPlaG1H20vrH2jlVvrxPHj+XTuduIs097pP5TKey5+rN5xbXRxMH7cVhtltPPp6vZW3drJdlU3pQrzn3pPzI9fMlzb2PldXyrDdXKplSNhfPmWlcUS+2E+X1dFPnJW0eXFsO5mbmzGFfljYH10dXm+uO9mMxpjict3J928Rcvsg81P+TbwrL8VyU+UijcDqe82U9jPxDm0a+7Pdl7XyIPfJlTa35ktZ8WWcfYi9r70NZgyPdxV7O38Re2rz/D3eloKy79ef04+fK4h9bDizTWugHAQIECBAg0JdABBexNentv7+rRXMA8A8t/hXEDwIECBAgsCmBZvGv4yrHt//u7vEJwM9b/Dc11wZDgAABAgQOBNogIPIRBPxCWfzjUX8+7s/04EIHBAgQIECAQN8C08JfPw4o+f1ywY/zy7K+R6z3BAgQIEBgcIHF4h9BwL7+NmScaDZBQIMhS4AAAQIEehbINT7SZn98AhBv+bNCyXoC0PNM6zsBAgQIEFgI5Bp/EADk4p9puUYAsIBzSIAAAQIEehdoFv/HjwBiQLn4ZzoV9T5W/SdAgAABAgQmgUUAcHtbFv1Y9+N3AdoUGAECBAgQILARgbWPACIAiC3+/O/Bk4Ba6gcBAgQIECCwCYHFE4B9BgAxuAwC6t/cnwKDTQzaIAgQIECAwMgCi8V/V75HoP4zwPnvARecCAIOvihhZDBjJ0CAAAECWxHIIKAs/jUAiHHFgt8GAfO37m1l0MZBgAABAgRGFlgs/vHtu/PXAS+DgJGdjJ0AAQIECGxOIIKAsvDH4h//DLB941+fBLw7KDlv+NHm/IeE6sHiurWyRRWHBAgQIECAwNsK3Lwv7U9r8iuW+7ftnNYJECBAgACBtxcQALy9sTsQIECAAIGrExAAXN2U6BABAgQIEHh7AQHA2xu7AwECBAgQuDoBAcDVTYkOESBAgACBtxcQALy9sTsQIECAAIGrExAAXN2U6BABAgQIEHh7AQHA2xu7AwECBAgQuDoBAcDVTYkOESBAgACBtxcQALy9sTsQIECAAIGrExAAXN2U6BABAgQIEHh7AQHA2xu7AwECBAgQuDoBAcDVTYkOESBAgACBtxcQALy9sTsQIECAAIGrExAAXN2U6BABAgQIEHh7AQHA2xu7AwECBAgQuDoBAcDVTYkOESBAgACBtxcQALy9sTsQIECAAIGrExAAXN2U6BABAgQIEHh7AQHA2xu7AwECBAgQuDoBAcDVTYkOESBAgACBtxcQALy9sTsQIECAAIGrExAAXN2U6BABAgQIEHh7AQHA2xu7AwECBAgQuDoBAcDVTYkOESBAgACBtxcQALy9sTsQIECAAIGrExAAXN2U6BABAgQIEHh7AQHA2xu7AwECBAgQuDoBAcDVTYkOESBAgACBtxcQALy9sTsQIECAAIGrEzgIAB4edrv39y/v401cUn80adtMnmvL5AkQIECAAIEfq8DDu3K7aU2eA4BY/O+n/cfaGzcjQIAAAQIE3l4gFv6y6j/Eyl/y+7hju/hHEFD+ZyNAgAABAgS2IhCL/xQAxJBind+vLf5RZiNAgAABAgQ2JLAIAvb52D/f+cfiX9d/QcCGZt1QCBAgQGBogVz8I42tfAwwBwCx3lv8K4sfBAgQIEBgewIZBEwjqwFAu/jPQcD2hm5EBAgQIEBgTIF8559pUdgfW/x9AjDma8SoCRAgQGCjAssnAPmOf07LuC3+G518wyJAgACBcQWeBACFYrn4CwDGfX0YOQECBAhsUCAf/Wdahlj/GWD9GKAcZBpDFwSEgo0AAQIECHQukIv+6hOAMjaLf+cTrPsECBAgQOCYQC7+GQyUerc/+Ok7i/8xMOUECBAgQGArAm0QUPL1uwD+sgQBseVj/0xroR8ECBAgQIBA3wL5zr8JAmoAEKP6v4KAvidX7wkQIECAwJpAu/iX8//8J8qX//3Hu/rVAAdv+H/vX9zt/v5/L48GygX78rWBn5avC/rsk7J/WvbPyv55KfvebvdJaWAf+0/udu/KfhN7Od6Vcw+xl7qx35frYn8o7dyXdu5Lm/clH19JWPMljW8miv0+0nLf/Kaimp+ildrJOJeDi/Jj21TpZiWtZaX84FweRxptnnFc60x1I8n2soPzcVMnsu2W92rLDvKlH7nN7S3L8jj6HJXjOPJt+VS2Wh5f/5z1l/Wm49pW5I/ULWdW28jy7NN83Naf8vVcm4/7tcfTYW1rLZ9la9e0535c+ez/a+536tpT519yz2Vby+O2refOtfUy/9L6ed1r0rV7tWVr+SxbpPGvoubXWebbOk3Zsbpz+fTfzHw8Xdsez/kYdzk/H2d+Kq/nmnzNZl+m8jic+97ka5txHFutNGWb/PLcY42Vn9M1y0uf1FypsNaPZ8tKG7WZbGtxPF/blM/1m7LoW9bNtPWcy5p68/kcWG04D06kzfpUs9PxQT4Oyp5lN5HPsil/U9bEWh7pYr8ta+fNtNd8WVdvyn5b1tmb3Mvae1PW4d20P8RaPK25MYJS/cP2lz97t7v5b4/gsfjaCBAgQIAAgQ0I5JrepHMA8IOfufsQaUWFjJ42MG5DIECAAAECwws0i39Y1ADgL8rn//Njk1z8Mx1eDAABAgQIENiIQBME7P/sp54u/vGhRHwmMgcFGxm3YRAgQIAAgeEFpiCg/iXAijG946+/kRCLfx7HyRoJDE8GgAABAgQI9C0wLf6x1n8IAGJIuehP6cETAEFA35Ou9wQIECAwtkCz+NcA4L4s7OVfF3zYcvHPNM5Y/D/4yBEgQIAAgV4FYm2f9n0EALEtgwC/A/Do4icBAgQIENiMwFoAEINrg4CD3wHYzMgNhAABAgQIDCoQi39syycAj6UfgoD5CUCekBIgQIAAAQJ9C7RPAGKhj79W2W7xJCDKffbfqsgTIECAAIENCOQTgPorACtBQA0AYpy1wgYGbAgECBAgQGB0gXwCUN7p178EuBYEZNnoVsZPgAABAgQ2IxABQDzmzwAgBpYLfn4cMD8BiJM2AgQIECBAoH+BKQCIb92NOGDeIgiIfxb4bUYB85mVTI0YVsoVESBAgAABAlcrEF8JHP8S4CAAuNre6hgBAgQIECBwUQEBwEU5NUaAAAECBPoQEAD0MU96SYAAAQIELiogALgop8YIECBAgEAfAgKAPuZJLwkQIECAwEUFBAAX5dQYAQIECBDoQ0AA0Mc86SUBAgQIELiogADgopwaI0CAAAECfQgIAPqYJ70kQIAAAQIXFRAAXJRTYwQIECBAoA8BAUAf86SXBAgQIEDgogICgItyaowAAQIECPQhIADoY570kgABAgQIXFRAAHBRTo0RIECAAIE+BAQAfcyTXhIgQIAAgYsKCAAuyqkxAgQIECDQh4AAoI950ksCBAgQIHBRAQHARTk1RoAAAQIE+hAQAPQxT3pJgAABAgQuKiAAuCinxggQIECAQB8CAoA+5kkvCRAgQIDARQUEABfl1BgBAgQIEOhDQADQxzzpJQECBAgQuKiAAOCinB02dtNhn3WZAAECBD5aQADw0YQaIECAAAEC/QkIAPqbMz0mQIAAAQIfLSAA+GhCDRAgQIAAgf4EBAD9zZkeEyBAgACBjxYQAHw0oQYIECBAgEB/AgKA/uZMjwkQIECAwEcL7NsW4l+E3ZQft+f807Bz6rSNyxMgQIAAAQLfucDN+93uobz9nwOAdvGPACACARsBAgQIECCwIYGHMpb7ssaXpAYAy8W/BgAxXkFAKNgIECBAgMA2BKYAIAZTn/bnY/84yH1+AiAI2MakGwUBAgQIEIgAYAoC9scW/xoAWPy9WAgQIECAwLYEIgAo2z7f8WcaC/+8P9bxkwABAgQIENiCQD4BKGM5CADmhT+CgBioJwBbmG5jIECAAAECj4/+w2H5BGC5+NfjqCgICAUbAQIECBDoX2D5BOC5xd+TgP7n2wgIECBAgEAVaAOAsxd/TwK8eggQIECAQL8C06P//Ajgdg4AypDysX+m8+N/i3+/E67nBAgQIEAgBZog4PaX/+aurvO56C/TOQjIi6UECBAgQIBAvwJTEFC/DOgXf7geBMTi781/v3Os5wQIECBA4ECgfQKQJ37hrw+DAIt/ykgJECBAgMAGBJrFP0Zz8HXAP/9XiyBgA+M1BAIECBAgMLzAYvGPXwQ8CAAC6Of+nyBg+BcKAAIECBDYnkATBOx/53Gtz6LtDdaICBAgQIAAgVWBJ08AVmspJECAAAECBDYlIADY1HQaDAECBAgQOE9AAHCek1oECBAgQGBTAgKATU2nwRAgQIAAgfMEBADnOalFgAABAgQ2JSAA2NR0GgwBAgQIEDhPQABwnpNaBAgQIEBgUwICgE1Np8EQIECAAIHzBAQA5zmpRYAAAQIENiUgANjUdBoMAQIECBA4T0AAcJ6TWgQIECBAYFMCAoBNTafBECBAgACB8wQEAOc5qUWAAAECBDYlIADY1HQaDAECBAgQOE9AAHCek1oECBAgQGBTAgKATU2nwRAgQIAAgfMEBADnOalFgAABAgQ2JSAA2NR0GgwBAgQIEDhPQABwnpNaBAgQIEBgUwICgE1Np8EQIECAAIHzBAQA5zmpRYAAAQIENiUgANjUdBoMAQIECBA4T0AAcJ6TWgQIECBAYFMCAoBNTafBECBAgACB8wQEAOc5qUWAAAECBDYlIADY1HQaDAECBAgQOE9AAHCek1oECBAgQGBTAgKATU2nwRAgQIAAgfMEBADnOalFgAABAgQ2JSAA2NR0GgwBAgQIEDhPQABwnpNaBAgQIEBgUwL/H/IQV9FpBt9FAAAAAElFTkSuQmCC", Dt = 2e3, Ot = 1 / 120, kt = .004379, At = .6, jt = Object.freeze({
	x: 0,
	y: .75,
	z: 0,
	width: 3.1,
	height: 1.61,
	pockets: [
		[
			-1.536,
			-.782,
			1,
			1,
			.065,
			0
		],
		[
			-1.536,
			.782,
			1,
			-1,
			.065,
			0
		],
		[
			0,
			-.816,
			0,
			1,
			.065,
			-Math.cos(65 * Math.PI / 180)
		],
		[
			0,
			.816,
			0,
			-1,
			.065,
			-Math.cos(65 * Math.PI / 180)
		],
		[
			1.536,
			-.782,
			-1,
			1,
			.065,
			0
		],
		[
			1.536,
			.782,
			-1,
			-1,
			.065,
			0
		]
	]
}), Z = Object.freeze({
	BALL_POTTED: "ball-potted",
	GAME_OVER: "game-over",
	RESET: "reset",
	SHOT_ENDED: "shot-ended",
	SHOT_STARTED: "shot-started",
	STATE_CHANGED: "state-changed"
}), Mt = Et, Nt = Object.freeze({
	rookie: Object.freeze({
		range: 1.9,
		abf: 1.2,
		bcf: 1.6,
		chaoticSeed: 3,
		mpm: .8,
		bpm: 1.2
	}),
	steady: Object.freeze({
		range: 2.5,
		abf: 1,
		bcf: 1,
		chaoticSeed: 3,
		mpm: .7,
		bpm: 1
	}),
	ace: Object.freeze({
		range: 3.3,
		abf: .72,
		bcf: .82,
		chaoticSeed: 2,
		mpm: .45,
		bpm: .8
	})
});
function Pt(e, t, n) {
	return Math.min(n, Math.max(t, e));
}
function Ft(e) {
	if (e <= 0 || !Number.isFinite(e)) return null;
	let t = Math.log2(e);
	return Number.isInteger(t) ? t : null;
}
function It() {
	let e = new C();
	return e.reset(jt.x, jt.y, jt.z, jt.width, jt.height, jt.pockets), e;
}
var Lt = class extends k {
	players;
	simulator;
	meshBody;
	context;
	refereeResult;
	referee;
	playArea;
	aiPlanner;
	accumulator = 0;
	currentPlayerIndex = 0;
	foulDescription = "";
	phase = "ready";
	winnerIndex = null;
	constructor(e = [{
		id: "player",
		name: "Ryo"
	}, {
		id: "opponent",
		name: "MJQ Regular",
		isAI: !0
	}]) {
		if (super(), e.length < 1) throw Error("A nine-ball game requires at least one player.");
		this.players = e.map((e) => Object.freeze({ ...e })), this.context = A.makeGContext(), this.refereeResult = A.makeRefResult(), this.referee = new ue(), this.playArea = It(), this.aiPlanner = new S();
		let t = new ge(Tt);
		t.id = "shenmue-pool-table-collision.json", this.meshBody = t, this.simulator = new wt("shenmue-nine-ball", new bt(), { getCache: () => t }), this.simulator.on(J.POTTED, (e) => {
			let t = this.simulator.getBallAtIndex(e);
			this.emit(Z.BALL_POTTED, {
				index: e,
				number: t.number
			});
		}), this.reset();
	}
	applyCushionNormalMap(e) {
		let t = Ce.createNTableWithImgData(e);
		for (let e of this.meshBody.groups) Tt[e.name]?.nt && Ce.extendPolyGroup(e, t);
	}
	reset(e = 0) {
		let t = ee.default;
		this.simulator.sync(t), this.simulator.reset(!0, !0), this.settle(), this.referee.syncAreaWithSimulator(this.simulator), this.context.nRounds = 0, this.context.playerIndex = Math.abs(Math.trunc(e)) % this.players.length, this.currentPlayerIndex = this.context.playerIndex, this.referee.resetGContext(this.context), this.foulDescription = "", this.winnerIndex = null, this.accumulator = 0, this.setPhase("ready"), this.simulator.save();
		let n = this.snapshot();
		return this.emit(Z.RESET, n), n;
	}
	shoot(e) {
		if (this.phase !== "ready") return !1;
		let t = this.prepareShot(e);
		if (!t) return !1;
		let { directionX: n, directionZ: r, power: i, sideSpin: a, topSpin: o, tipData: s } = t;
		return this.foulDescription = "", this.simulator.stroke(s), this.setPhase("simulating"), this.emit(Z.SHOT_STARTED, {
			playerIndex: this.currentPlayerIndex,
			shot: {
				directionX: n,
				directionZ: r,
				power: i,
				sideSpin: a,
				topSpin: o
			}
		}), !0;
	}
	predictShot(e, t = 1.6) {
		if (this.phase !== "ready") return null;
		let n = this.prepareShot(e);
		return n ? this.simulator.predict(n.tipData, Pt(Number(t) || 1.6, .1, 10)) : null;
	}
	prepareShot(t) {
		let n = Number(t.directionX), r = Number(t.directionZ), i = Math.hypot(n, r);
		if (!Number.isFinite(i) || i < e.EPSILON) return null;
		n /= i, r /= i;
		let a = this.simulator.getBallAtIndex(0), o = Pt(Number(t.power) || 0, .02, 1), s = Pt(Number(t.sideSpin) || 0, -1, 1), c = Pt(Number(t.topSpin) || 0, -1, 1), l = a.radius + kt, u = a.radius * At, d = /* @__PURE__ */ new Float32Array(8);
		return d[0] = a.position.x - n * l - r * s * u, d[1] = a.position.y + c * u, d[2] = a.position.z - r * l + n * s * u, d[3] = n, d[4] = 0, d[5] = r, d[6] = (.5 + 11 * o) * (3.2 + 6 * o), d[7] = kt, {
			directionX: n,
			directionZ: r,
			power: o,
			sideSpin: s,
			topSpin: c,
			tipData: d
		};
	}
	step(e) {
		if (this.phase !== "simulating") return this.snapshot();
		for (this.accumulator += Pt(Number(e) || 0, 0, .1); this.accumulator >= Ot && this.simulator.nAwakened !== 0;) this.simulator.step(Ot), this.accumulator -= Ot;
		return this.simulator.nAwakened === 0 && this.finishShot(), this.snapshot();
	}
	placeCueBall(t, n) {
		if (this.phase !== "ready" || this.context.inHand <= 0) return !1;
		let r = new e(t, this.simulator.spotY, n);
		return !this.referee.projectionInSideValidRegion(r.x, r.y, r.z) || this.simulator.touchBalls(0, r) ? !1 : (this.simulator.respotIndexXYZ(0, r.x, r.y, r.z), this.settle(), this.simulator.save(), this.emit(Z.STATE_CHANGED, this.snapshot()), !0);
	}
	planAIShot(e = "steady") {
		if (this.phase !== "ready") return null;
		this.aiPlanner.setFactors(Nt[e] || Nt.steady), this.aiPlanner.checkRestart(this.simulator, this);
		for (let e = 0; e < 1e4; e++) {
			let e = this.aiPlanner.step({ playArea: this.playArea }, this.simulator, this);
			if (e) return {
				directionX: e.dx,
				directionZ: e.dz,
				power: Pt(.3 + e.powerFactor, .05, 1),
				topSpin: e.fbSpin
			};
		}
		return null;
	}
	getContext(e) {
		return this.context[e];
	}
	pointProjectionOnTable(e, t, n) {
		return this.referee.projectionOnTable(e, t, n);
	}
	snapshot() {
		return {
			balls: this.simulator.getBalls().map((e) => {
				let t = e.states.position, n = e.states.orientation;
				return {
					active: e.active,
					index: e.index,
					number: e.number,
					position: {
						x: t.x,
						y: t.y,
						z: t.z
					},
					orientation: {
						x: n.x,
						y: n.y,
						z: n.z,
						w: n.w
					}
				};
			}),
			currentPlayerIndex: this.currentPlayerIndex,
			foul: this.foulDescription,
			inHand: this.context.inHand > 0,
			openingBreak: this.referee.inHandPlacementRegion !== null,
			phase: this.phase,
			targetBallNumber: Ft(this.context.ballOn),
			winnerIndex: this.winnerIndex
		};
	}
	finishShot() {
		let e = this.currentPlayerIndex, t = this.simulator.result.pottedIndices.map((e) => this.simulator.getBallAtIndex(e).number);
		this.referee.checkResult(this.context, this.simulator, this.refereeResult), this.context.nRounds++, this.foulDescription = ne(this.refereeResult.foulCode), this.context.ballOn === 0 && this.refereeResult.foulCode === 0 ? (this.winnerIndex = e, this.setPhase("complete")) : (this.refereeResult.score <= 0 && (this.currentPlayerIndex = (e + 1) % this.players.length), this.context.playerIndex = this.currentPlayerIndex, this.settle(), this.simulator.save(), this.setPhase("ready"));
		let n = {
			foulCode: this.refereeResult.foulCode,
			foulDescription: this.foulDescription,
			nextPlayerIndex: this.currentPlayerIndex,
			pottedBallNumbers: t,
			score: this.refereeResult.score,
			winnerIndex: this.winnerIndex
		};
		this.emit(Z.SHOT_ENDED, n), this.winnerIndex !== null && this.emit(Z.GAME_OVER, n);
	}
	settle() {
		let e = 0;
		for (; this.simulator.nAwakened !== 0;) {
			if (++e > Dt) throw Error("Nine-ball simulation did not settle.");
			this.simulator.step(Ot);
		}
	}
	setPhase(e) {
		this.phase !== e && (this.phase = e, this.emit(Z.STATE_CHANGED, this.snapshot()));
	}
}, Rt = class {
	static PLAYER_TYPE_USER = 0;
	static PLAYER_TYPE_AI = 1;
	static PLAYER_TYPE_REMOTE = 2;
	_userInfo;
	_userId;
	_type;
	pts;
	penalty;
	_brk;
	_maxBrk;
	shootingCount;
	scoreCount;
	get id() {
		return this._userId;
	}
	get type() {
		return this._type;
	}
	get displayName() {
		return this._userInfo.displayName;
	}
	constructor(e, t) {
		this._userInfo = e, this._userId = e.userId, this._type = t, this.pts = 0, this.penalty = 0, this._brk = 0, this._maxBrk = 0, this.shootingCount = 0, this.scoreCount = 0;
	}
	get maxbrk() {
		return this._maxBrk;
	}
	get brk() {
		return this._brk;
	}
	set brk(e) {
		this._brk = e, this._maxBrk < e && (this._maxBrk = e);
	}
	get accuracy() {
		return this.shootingCount === 0 ? 0 : this.scoreCount / this.shootingCount;
	}
	clearScores() {
		this.pts = 0, this.penalty = 0, this._brk = 0, this._maxBrk = 0, this.shootingCount = 0, this.scoreCount = 0;
	}
	getInfoData(e) {
		return this._userInfo[e];
	}
	dispose() {
		this._userInfo = null;
	}
}, Q = Object.create(null);
Q.ERROR = 0, Q.NO_GAME = 1, Q.PENDING = 2, Q.READY = 4, Q.SIMULATING = 8, Q.JUDGING = 16;
//#endregion
//#region src/physics/geometry/CircularPlanarRegion.ts
var zt = class extends M {
	get radius() {
		return this._radius;
	}
	get center() {
		return this._center;
	}
	get arcDir() {
		return this._arcDir;
	}
	get geoCenter() {
		return this._geoCenter ||= this._center.clone().addScaled(this._arcDir, .5 * this._radius), this._geoCenter;
	}
	get diameterDir() {
		return this._diameterDir;
	}
	get diameterA() {
		return this._diameterA;
	}
	get diameterB() {
		return this._diameterB;
	}
	_center;
	_radius;
	_arcDir;
	_diameterA;
	_diameterB;
	_diameterDir;
	_geoCenter;
	constructor() {
		super(), this._center = new e(), this._radius = 0, this._arcDir = new e(), this._diameterA = new e(), this._diameterB = new e(), this._diameterDir = new e(), this._geoCenter = null;
	}
	resetWithCenterTopNormal(e, t, n, r, i, a, o) {
		this._center.set(e, t, n), this.setWithPointNormal(this._center, o), this._arcDir.set(r, i, a).sub(this._center), this._radius = this._arcDir.length(), this._arcDir.normalize(), this._diameterDir.crossVectors(o, this._arcDir).normalize(), this._diameterA.interpolate(this._center, this._diameterDir, -this._radius), this._diameterB.interpolate(this._center, this._diameterDir, this._radius), this._geoCenter = null;
	}
	projectionInside(e, t, n) {
		let r = M.TmpV;
		if (r.set(e, t, n).sub(this._center).dot(this._arcDir) < 0) return !1;
		r.set(e, t, n);
		let i = this.signedDistance(r);
		return r.addScaled(this.normal, -i), r.distanceToSq(this._center) <= this._radius * this._radius;
	}
	toString() {
		return "{c: " + this._center.toString() + ", n: " + this.normal.toString() + ", radius: " + this._radius + "}";
	}
}, $ = {
	RED: 2,
	YELLOW: 4,
	BLACK: 128,
	COLOR_ALL: 252
}, Bt = class extends oe {
	get validRegionGeoCenter() {
		return this._dArea.geoCenter;
	}
	_dArea;
	_tmpArray;
	_tmpOccupiedSpots;
	_tmpSections;
	_tmpA;
	_tmpB;
	_respotColorBallsSortHandler;
	constructor() {
		super(), this._dArea = new zt(), this._tmpArray = [], this._tmpOccupiedSpots = [], this._tmpSections = [], this._tmpA = new e(), this._tmpB = new e(), this._respotColorBallsSortHandler = (e, t) => e.number - t.number;
	}
	syncAreaWithSimulator(e) {
		if (this._sceneId === e.sceneId) return;
		this._sceneId = e.sceneId;
		let t = Ct[this._sceneId].dArea, n = e.ground;
		this._playArea.resetWithAtomPolygon(n), this._dArea.resetWithCenterTopNormal(t.cx, n.centerPosition.y, t.cz, t.sx, n.centerPosition.y, t.sz, n.normal);
	}
	intersectionRayValidRegionPlane(e, t, n) {
		return this._dArea.intersectionWithRay(e, t, n, 10);
	}
	projectionInSideValidRegion(e, t, n) {
		return this._dArea.projectionInside(e, t, n);
	}
	resetGContext(e) {
		e.inHand = 2, e.ballOn = $.RED, e.winnerIndex = -1;
	}
	checkResult(e, t, n) {
		let r = t.result;
		n.score = 0, n.foulCode = 0;
		let i = 0, a = t.getBallAtIndex(r.firstKissIndex).number;
		if (e.ballOn === this.sysReservedBallOn) {
			this._liveRespot(r.pottedIndices, r.outOfBoundsIndices, t), e.inHand = 1;
			return;
		}
		let o = 0, s = 0;
		e.ballOn === $.COLOR_ALL ? a <= 1 ? (n.foulCode |= a === 0 ? j.MISS_TARGET : j.ILLEGAL_FIRST_HIT, o = -7) : s = a : 2 ** a === e.ballOn ? s = a : (n.foulCode |= a === 0 ? j.MISS_TARGET : j.ILLEGAL_FIRST_HIT, o = Math.min(-a, -Math.log2(e.ballOn), -4));
		let c = 0;
		for (let e of r.outOfBoundsIndices) {
			let r = t.getBallAtIndex(e).number;
			c = Math.min(c, -r, -s, -4), n.foulCode |= j.OFF_TABLE;
		}
		let l = 0;
		for (let e of r.pottedIndices) {
			let r = t.getBallAtIndex(e).number;
			r !== 0 && r === s ? i += r : (l = Math.min(l, -r, -s, -4), n.foulCode |= r === 0 ? j.POTTING_CUE_BALL : j.ILLEGAL_POTTING);
		}
		let u = Math.min(o, c, l);
		if (n.score = u === 0 ? i : u, e.inHand = 0, e.ballOn === $.BLACK && n.score !== 0) {
			e.ballOn = 0;
			return;
		}
		(n.score <= 0 || e.ballOn === $.RED || e.ballOn === $.COLOR_ALL) && (t.getBallAtIndex(0).active || (e.inHand = 2), this._liveRespot(r.pottedIndices, r.outOfBoundsIndices, t)), n.score > 0 ? e.ballOn === $.RED ? e.ballOn = $.COLOR_ALL : e.ballOn === $.COLOR_ALL ? e.ballOn = this._nActiveReds(t) === 0 ? $.YELLOW : $.RED : e.ballOn <<= 1 : (e.ballOn === $.RED || e.ballOn === $.COLOR_ALL) && (e.ballOn = this._nActiveReds(t) === 0 ? $.YELLOW : $.RED);
	}
	_liveRespot(e, t, n) {
		let r = this._tmpArray, i, a = !1;
		for (let t of e) i = n.getBallAtIndex(t), i.number > 1 ? r.push(i) : i.number === 0 && (a = !0);
		for (let e of t) i = n.getBallAtIndex(e), i.number > 1 ? r.push(i) : i.number === 0 && (a = !0);
		r.length !== 0 && (this._liveRespotColorBalls(r, n), r.length = 0), a && this._liveRespotCueBall(n);
	}
	_nActiveReds(e) {
		let t = 0;
		for (let n of e.getBalls()) n.number === 1 && n.active && t++;
		return t;
	}
	_liveRespotColorBalls(n, r) {
		let i = 1.05 * r.ballRadius, a = this._tmpOccupiedSpots, o;
		a.length = 0;
		for (let e = n.length - 1; e >= 0; e--) o = n[e], r.touchBalls(o.index, o.spot, i) || (n.splice(e, 1), r.respotIndexDefault(o.index)), a[o.number] = 1;
		if (n.length === 0) return;
		n.sort(this._respotColorBallsSortHandler);
		let s = r.getBalls();
		for (let e = s.length - 1; e >= 0 && (o = s[e]).number >= 2; e--) {
			let e = n[n.length - 1].index;
			if (!a[o.number] && !r.touchBalls(e, o.spot, i) && (r.resetBallPosition(n.pop(), o.spot), n.length === 0)) return;
		}
		let c = r.ground, l = this._tmpA, u = this._tmpB, d = this._tmpSections, f = e.UNIT_Z;
		for (let e = n.length - 1; e >= 0; e--) {
			o = n[e];
			let a = o.spot;
			l.set(c.centerPosition.x - c.size.x / 2 + i, a.y, a.z), u.set(c.centerPosition.x + c.size.x / 2 - i, a.y, a.z);
			let p = 10;
			for (; p > 0 && !t.sectionsBallsAB(s, o, i, l, u, d, f);) l.addScaled(f, d[0]), u.addScaled(f, d[0]), p--;
			if (p > 0) {
				let e = t.findClosestTInSections(a.x - l.x, d);
				r.resetBallXYZ(o, l.x + e, l.y, l.z);
			} else r.resetBallPosition(o, o.spot);
		}
	}
	_liveRespotCueBall(e) {
		let n = 1.05 * e.ballRadius, r = e.getBallAtIndex(0);
		if (!e.touchBalls(0, r.spot, n)) {
			e.respotIndexDefault(0);
			return;
		}
		let i = e.getBalls(), a = this._dArea, o = this._tmpA.copy(a.diameterA), s = this._tmpB.copy(a.diameterB), c = this._tmpSections, l = 0, u = a.radius;
		for (o.y = r.spot.y, s.y = r.spot.y; !t.sectionsBallsAB(i, r, n, o, s, c, a.arcDir);) {
			if (l += c[0], l > u) {
				e.respotIndexDefault(0);
				return;
			}
			let t = u - Math.sqrt(u * u - l * l);
			o.addScaled(a.arcDir, c[0]).addScaled(a.diameterDir, t), s.addScaled(a.arcDir, c[0]).addScaled(a.diameterDir, -t);
		}
		let d = t.findCenterOfLongestInSections(c);
		e.resetBallPosition(r, o.addScaled(a.diameterDir, d));
	}
}, Vt = Object.create(null);
Vt["std-sno"] = Bt, Vt["std-nine"] = ue;
var Ht = Object.create(null), Ut = { getInstance(e) {
	let t = Ht[e];
	if (t !== void 0) return t;
	let n = Vt[e];
	if (n !== void 0) return t = new n(), Ht[e] = t, t;
	throw Error(`No ruleset is registered as "${e}".`);
} };
//#endregion
export { S as AIShotPlanner, St as BilliardBallBody, wt as BilliardsSimulator, ee as DefaultGameDefinition, k as EventEmitter, j as FoulCode, A as GameDataFactories, Rt as GamePlayer, Q as GameStateFlags, ge as MeshBody, Nt as NineBallAIDifficulties, Z as NineBallGameEvents, ue as NineBallReferee, bt as PhysicsWorldClient, C as PlayArea, yt as PredictionContext, oe as RefereeBase, Ut as RefereeRegistry, Mt as ShenmueCushionNormalMapUrl, Lt as ShenmueNineBallGame, i as ShotRoute, J as SimulationResultEvents, Y as SimulatorEvents, X as SimulatorState, e as Vec3, ne as getFoulDescription };
